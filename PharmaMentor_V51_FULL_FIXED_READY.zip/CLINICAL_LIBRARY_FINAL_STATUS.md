# Pharma Mentor — 632 Clinical Library Final Gate

- Catalog: 632 unique drug records.
- Profile relation: 1:1 by stable drugId.
- Room schema: 20; migration 19→20 included.
- Clinical schema: mechanism, indications, adult/pediatric dose, renal/hepatic considerations, adverse effects, contraindications, interactions, monitoring, pregnancy, lactation, toxicity, antidote, counseling, on-label/off-label, reference and review date.
- Audit matrix: `AUDIT/CLINICAL_VERIFICATION_MATRIX.csv`.

## Important
This project does not claim that all 632 profiles have been externally verified field-by-field. Fields that originate from class-level educational guidance are not equivalent to current product labeling. Use the audit matrix to prevent unsafe interpretation.

## Sources
- FDA prescribing information resources / Drugs@FDA / DailyMed.
- WHO Model List of Essential Medicines 2025 and EMLc 2025.
- Applicable current specialty guidelines.
