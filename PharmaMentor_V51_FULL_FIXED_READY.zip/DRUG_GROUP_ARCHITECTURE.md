# Pharma Mentor — Drug group architecture (next-step implementation)

## Browse hierarchy
**Pharmacological group → subclass / drug class → canonical drug record → clinical profile**

The existing Room column `therapeuticGroup` is retained to avoid a database migration in this step, but its value now represents the primary pharmacological group used for browsing. The display label is updated to “Pharmacological group • المجموعة الدوائية”. The legacy seed argument remains for source compatibility; it is not used as the primary browse group.

## Rules
- Do not use organ systems (for example, “Cardiovascular”) as the primary pharmacological group.
- A medicine should have one canonical `drugId`; its uses in multiple diseases belong in disease-treatment plans, not duplicate drug rows.
- Drug class/subclass remains in `drugClass`.
- Uncertain classifications are placed in `Other pharmacological groups — review required` instead of silently guessing.
- Clinical dose and safety fields remain educational and require agent-, indication-, formulation-, patient- and jurisdiction-specific verification against current official labeling and guidelines.

## Important limitation of this step
This change implements the grouping behavior for seed records and updates the profile label. It does **not** certify that the library contains 632 unique medicines, nor does it replace a per-drug clinical audit or add the disease-treatment-plan module. Those require separate data validation and implementation.
