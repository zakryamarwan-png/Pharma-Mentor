package com.pharmamentor.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.content.Context
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import com.pharmamentor.app.data.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var repo: PharmaRepository
    private var due = listOf<ReviewCardEntity>()
    private var pos = 0
    private val prefs by lazy { getSharedPreferences("pharma_mentor_settings", Context.MODE_PRIVATE) }
    private var isArabic: Boolean = true

    private fun ar(ar: String, en: String): String = if (isArabic) ar else en
    private val uiTranslations: Map<String, String> = mapOf(
        "تعلّم بذكاء" to "Learn smarter", "راجع في الوقت المناسب" to "Review at the right time", "قِس تقدمك" to "Track progress", "طوّر نقاط ضعفك" to "Improve weak areas",
        "الاستمرارية" to "Streak", "الدقة" to "Accuracy", "مستحقة" to "Due", "بطاقات مستحقة" to "cards due", "موضوع" to "topics", "سؤال" to "questions",
        "البحث الشامل عن أي شيء" to "Search Everything", "قاعدة المعرفة بدون إنترنت" to "Offline Knowledge", "ابدأ جلسة اليوم" to "Start Today’s Session",
        "جلسة الدراسة التكيفية" to "Adaptive Study Session", "مهام وأهداف اليوم" to "Today’s Missions & Goals", "المراجعة الذكية" to "Smart Review",
        "ماذا أدرس الآن؟" to "What Should I Study Now?", "خطة اليوم الذكية" to "Smart Plan", "موضوع اليوم" to "Topic of the Day",
        "سؤال اليوم / بنك الأسئلة" to "Question of the Day / Question Bank", "الأدوات السريرية" to "Clinical Tools", "مكتبة الأدوية + الملفات الرئيسية" to "Drug Library + Master Profiles",
        "التداخلات الدوائية" to "Drug Interactions", "الحالات السريرية" to "Clinical Cases", "المدرّب السريري الذكي" to "AI-like Clinical Tutor",
        "الذكاء التعليمي" to "Learning Intelligence", "لوحة الذكاء التحليلي" to "Analytics Dashboard", "مستوى إتقان المواضيع" to "Topic Mastery",
        "خارطة التعلم الشخصية" to "Personal Learning Roadmap", "جاهزية الإصدار" to "Release Readiness", "مركز QA والإصدار" to "QA & Release Center",
        "فحص ما قبل الإصدار" to "Release Preflight", "اختبار الجهاز قبل APK" to "Device Smoke Test", "فحص تكامل النظام" to "System Integration Audit",
        "نقاط الضعف" to "Weaknesses", "التقرير الأسبوعي" to "Weekly Report", "اختبار تحديد المستوى" to "Placement Test", "المسارات الدراسية" to "Study Paths",
        "التحفيز والتذكيرات" to "Motivation & Reminders", "التحدي اليومي" to "Daily Challenge", "الإنجازات" to "Achievements", "التذكيرات" to "Reminders",
        "المحتوى الدوائي تعليمي" to "Medication content is educational", "تحقق دائمًا من المرجع الرسمي الحالي قبل الاستخدام السريري" to "Always verify the current official reference before clinical use",
        "أهداف يومية قصيرة وواضحة" to "Short, clear daily goals", "أكملها تدريجيًا" to "Complete them gradually", "ويمكنك فتح النشاط المناسب مباشرة من كل مهمة" to "You can open the relevant activity directly from each mission",
        "التقدم اليومي:" to "Daily progress:", "التقدم:" to "Progress:", "مكتملة" to "Completed", "تنفيذ المهمة" to "Run mission", "المهمة اليومية" to "The daily mission",
        "طبقة تحفيزية تعليمية" to "an educational motivation layer", "إكمال زر المهمة يسجل تقدم المهمة ولا يثبت وحده إتقان المحتوى" to "completing the mission button records progress but does not by itself prove content mastery",
        "خارطة التعلم" to "Learning Roadmap", "الرئيسية" to "Home", "فحص نهائي محلي قبل مرحلة بناء APK" to "Final local check before the APK build stage",
        "لا يتم إرسال أي بيانات خارج الجهاز" to "No data is sent outside the device", "قاعدة المحتوى" to "Content database", "التعلم التكيفي" to "Adaptive learning",
        "التحليلات والإتقان" to "Analytics & mastery", "الوحدات السريرية" to "Clinical modules", "المهام اليومية" to "Daily missions", "حالة المشروع" to "Project status",
        "لقطة البيانات" to "Data snapshot", "الإصدار:" to "Version:", "نعم" to "Yes", "التوقيعات والنشر:" to "Signing & publishing:",
        "تحتاج بيئة Android/Gradle كاملة" to "Requires a complete Android/Gradle environment", "اجتياز هذا الفحص يعني أن البنية والبيانات الأساسية متصلة محليًا" to "Passing this check means the core structure and data are connected locally",
        "لكنه لا يستبدل build/test على Android ولا اختبار APK على جهاز حقيقي" to "but it does not replace Android build/testing or APK testing on a real device",
        "إعادة الفحص" to "Recheck", "فحص التكامل التفصيلي" to "Detailed integration audit", "فحص جودة محلي قبل تسليم Release Candidate" to "Local quality check before the Release Candidate",
        "لا يثبت هذا الفحص نجاح build أو سلامة الاستخدام السريري" to "This check does not prove build success or clinical safety",
        "إعادة فحص QA" to "Recheck QA", "فحص محلي أخير لإعدادات التطبيق والـManifest والوحدات الأساسية" to "Final local check of app settings, Manifest, and core modules",
        "فحص APK/signing يبقى خارجيًا" to "APK/signing verification remains external", "النتيجة:" to "Result:", "فحوص ناجحة" to "checks passed",
        "إذا ظهر فحص الإشعارات" to "If the notification check", "امنح إذن الإشعارات من إعدادات Android ثم أعد الفحص" to "grant notification permission in Android settings and recheck",
        "فحص APK لا يمكن اعتباره ناجحًا قبل بناء وتوقيع التطبيق فعليًا" to "APK verification cannot be considered successful before the app is actually built and signed",
        "هذه قائمة الاختبار التي يجب تنفيذها على Emulator أو هاتف Android حقيقي قبل إنشاء APK النهائي" to "Run this checklist on an emulator or real Android phone before creating the final APK",
"هذا الاختبار لا يدّعي نجاح APK" to "This test does not claim APK success", "هو تجهيز منظم للاختبار الخارجي الفعلي" to "it is an organized preparation for actual external testing",
        "جاهزية الوحدات:" to "Module readiness:", "أنظمة التعلم" to "Learning systems", "حالة التكامل" to "Integration status",
        "هذا فحص بنيوي محلي وليس اختبارًا سريريًا أو ضمانًا لسلامة المحتوى الدوائي" to "This is a local structural check, not a clinical test or a guarantee of medication-content safety",
        "نظام الإتقان يبني خريطة إتقان لكل موضوع" to "The mastery system builds a mastery map for each topic", "لا توجد بيانات إتقان بعد" to "No mastery data yet",
        "ابدأ بحل MCQs أو جلسة الدراسة التكيفية" to "Start by solving MCQs or an adaptive study session", "إتقان:" to "Mastery:", "ثقة:" to "Confidence:", "الحالة:" to "Status:", "محاولات:" to "Attempts:",
        "جلسة تكيفية" to "Adaptive Session", "اختبار لرفع الإتقان" to "Quiz to improve mastery", "التحليلات" to "Analytics",
        "مسار شخصي يحدد ماذا تدرس الآن" to "A personal path that determines what to study now", "ماذا تراجع بعده" to "what to review next", "الخطوة التالية للوصول إلى Mastered" to "the next step toward Mastered",
        "الأولوية مبنية على مستوى الإتقان الحالي" to "Priority is based on the current mastery level", "لا توجد بيانات كافية لبناء خارطة شخصية بعد" to "There is not enough data to build a personal roadmap yet",
        "تحليل محلي لأدائك الدراسي" to "Local analysis of your study performance", "مع تحويل الأخطاء إلى أولويات قابلة للتنفيذ" to "with mistakes converted into actionable priorities",
        "الدقة الكلية" to "Overall accuracy", "هذا الأسبوع" to "This week", "الإجابات" to "Answers", "أخطاء" to "Errors", "أولويات التحسين" to "Improvement priorities",
        "ابدأ بالإجابة عن أسئلة أو مراجعة بطاقات حتى تتكوّن بيانات تحليلية" to "Answer questions or review cards to build analytics data",
        "تفسير سريع" to "Quick explanation", "لا توجد بيانات هذا الأسبوع بعد" to "No data for this week yet", "أجبت عن" to "You answered", "سؤالًا هذا الأسبوع" to "questions this week",
        "إجابة خاطئة" to "incorrect answers", "استخدم المراجعة المتباعدة للموضوعات ذات الأولوية HIGH" to "Use spaced review for HIGH-priority topics",
        "ابدأ المراجعة" to "Start Review", "ابدأ اختبارًا" to "Start Quiz", "المحرك يختار الأولويات من أخطائك" to "The engine selects priorities from your mistakes",
        "بطاقات المراجعة المستحقة" to "due review cards", "مستواك" to "your level", "والتوازن بين التعلم الجديد والتطبيق السريري" to "and the balance between new learning and clinical application",
        "لا توجد توصيات بعد" to "No recommendations yet", "ابدأ بجلسة مراجعة أو اختبار" to "Start a review session or quiz", "إعادة حساب الأولويات" to "Recalculate priorities",
        "محتوى أساسي مخزّن داخل التطبيق ويمكن الرجوع إليه دون اتصال بالإنترنت" to "Core content stored inside the app and available offline",
        "بحث داخل قاعدة المعرفة" to "Search the knowledge base", "بحث Offline" to "Offline Search", "اكتب اسم دواء أو موضوع أو كلمة مفتاحية" to "Enter a drug, topic, or keyword",
        tr("اكتب حرفين على الأقل") to "Enter at least two characters", "نتائج:" to "Results:", "القسم:" to "Category:", "المحتوى تعليمي" to "Content is educational",
        "شبكة تربط الدواء بالمستقبل أو الهدف" to "A network connecting a drug with its receptor or target", "المرض" to "disease", "الأعراض الجانبية" to "adverse effects",
        "ابدأ باسم دواء أو مفهوم" to "Start with a drug or concept", "مثال:" to "Example:", "استكشف الشبكة" to "Explore Graph", "أمثلة سريعة" to "Quick Examples",
        "نتائج الشبكة" to "Graph Results", "لا توجد نتائج" to "No results", "لا توجد روابط إضافية محفوظة" to "No additional saved links",
        "العودة للشبكة" to "Back to Graph", "بحث شامل" to "Global Search", "ابحث من مكان واحد في الأدوية" to "Search from one place across drugs",
        "ملفات الأدوية" to "drug profiles", "الحالات" to "cases", "الأسئلة" to "questions", "المواضيع" to "topics", "التداخلات" to "interactions",
        "بحث" to "Search", "عرض مكتبة الأدوية" to "View Drug Library", "عرض التداخلات" to "View Interactions", "نتائج البحث" to "Search Results",
        "أدوية" to "drugs", "ملفات" to "profiles", "أسئلة" to "questions", "مواضيع" to "topics", "تداخلات" to "interactions",
        "لا توجد نتائج مطابقة" to "No matching results", "جرّب الاسم العلمي أو اسم الفئة الدوائية" to "Try the generic name or drug class",
        "الأدوية" to "Drugs", "إظهار الإجابة" to "Show Answer", "الأدوية المرتبطة" to "Related Drugs", "رجوع للبحث" to "Back to Search",
        "لا توجد عناصر كافية لبناء جلسة الآن" to "Not enough items to build a session right now", "اكتملت جلسة اليوم" to "Today’s session is complete",
        "أحسنت! مررت عبر" to "Great job! You completed", "مراحل تعليمية مترابطة" to "connected learning stages", "تم تسجيل الأنشطة محليًا لتغذية التحليل والمراجعة التكيفية" to "Activities were logged locally to support analytics and adaptive review",
        "تحليل تقدمي" to "Progress Analysis", "جلسة أخرى" to "Another Session", "المرحلة" to "Stage", "لماذا هذه الخطوة؟" to "Why this step?", "التركيز:" to "Focus:",
        "موضوع اليوم" to "Today’s Topic", "لا يوجد محتوى" to "No content", "المرجع:" to "Reference:", "تمت القراءة" to "Mark as Read", "التالي" to "Next",
        "إظهار الإجابة" to "Show Answer", "حاول تذكر الإجابة قبل كشفها" to "Try to recall the answer before revealing it", "الإجابة:" to "Answer:", "قيّم مدى سهولة تذكرك" to "Rate how easy it was to recall",
        "المستوى المستهدف:" to "Target level:", "إجابتك صحيحة" to "Your answer is correct", "تحتاج مراجعة" to "Needs review", "إجابتك:" to "Your answer:", "الإجابة الصحيحة:" to "Correct answer:", "الشرح" to "Explanation",
        "السؤال التالي" to "Next Question", "إظهار القرار والتفسير" to "Show Decision & Rationale", "حاول بناء القرار الدوائي بنفسك قبل الكشف" to "Try to build the medication decision yourself before revealing it",
        "القرار التعليمي" to "Educational Decision", "إكمال الجلسة" to "Complete Session", "إنهاء الجلسة" to "End Session", "لا توجد بطاقات مستحقة الآن" to "No cards are due now",
        "تقييم تذكرك" to "Rate your recall", "تمت القراءة" to "Mark as Read", "سُجلت جلسة التعلم" to "Learning session recorded", "اختر الدواء لفتح Drug Master Profile الكامل" to "Choose a drug to open its full Drug Master Profile",
        "عدد الأدوية:" to "Drug count:", "نتائج البحث" to "Search Results", "عدد النتائج:" to "Result count:", "رجوع للمكتبة" to "Back to Library",
        "لا يوجد Master Profile لهذا الدواء بعد" to "No Master Profile exists for this drug yet", "دراسة هذا الدواء" to "Study this drug", "تم تسجيل جلسة دراسة" to "Study session recorded",
        "التداخلات المرتبطة" to "Related Interactions", "لا توجد نتيجة في قاعدة التداخلات الحالية" to "No result in the current interaction database",
        "تعلّم الحالة خطوة بخطوة" to "Learn the case step by step", "لن تظهر الإجابة مباشرة" to "The answer will not appear immediately",
        "سيطلب منك المحرك تحديد المشكلة" to "The engine will ask you to identify the problem", "اختيار القرار" to "choose the decision", "ثم يشرح سبب صحة أو خطأ إجابتك" to "then explain why your answer is right or wrong",
        "لا توجد حالات مهيأة للمحرك بعد" to "No cases are configured for the engine yet", "النتيجة" to "Result", "صحيحة" to "correct", "التقييم:" to "Assessment:",
        "الأخطاء التي حدثت في هذه الجلسة تُسجل للتعلم التكيفي" to "Mistakes from this session are logged for adaptive learning", "إعادة الحالة" to "Restart Case", "حالات أخرى" to "Other Cases",
        "الخطوة" to "Step", "إجابتك تحتاج مراجعة" to "Your answer needs review", "الإجابة الأفضل:" to "Best answer:", "لماذا؟" to "Why?", "نقطة الحفظ" to "Key takeaway",
        "الخطوة التالية" to "Next Step", "عرض النتيجة" to "View Result", "إيقاف الجلسة" to "Stop Session", "اقرأ الحالة أولًا" to "Read the case first",
        "ثم حاول بناء القرار الدوائي قبل إظهار الإجابة" to "then try to build the medication decision before showing the answer",
        "ابحث عن اسم أحد الدواءين" to "Search for either drug name", "هذه معلومات تعليمية وليست بديلًا عن مراجعة وصفة أو مرجع دوائي محدث" to "This is educational information and not a substitute for reviewing a prescription or an up-to-date drug reference",
        "التداخلات المحفوظة:" to "Saved interactions:", "نتائج التداخلات" to "Interaction Results", "رجوع للتداخلات" to "Back to Interactions",
        "اختبار متكيف: اختر عدد الأسئلة، الصعوبة، والمؤقت الاختياري" to "Adaptive quiz: choose the number of questions, difficulty, and optional timer",
        "بعد كل إجابة ستحصل على تفسير" to "You will receive an explanation after each answer", "وفي النهاية ستظهر الدقة والتوصية التالية" to "and accuracy and the next recommendation will appear at the end",
        "عدد الأسئلة" to "Number of questions", "مؤقت اختياري" to "Optional timer", "بدء الاختبار" to "Start Quiz", "دقة المحاولات حسب الصعوبة" to "Attempt accuracy by difficulty",
        "الصعوبة تُقدّر تلقائيًا من محتوى السؤال" to "Difficulty is estimated automatically from question content", "يمكن توسيع بنك الأسئلة لاحقًا لإضافة مستويات أدق" to "The question bank can be expanded later for finer levels",
        "لا توجد أسئلة كافية" to "Not enough questions", "نتيجة الاختبار" to "Quiz Result", "الأخطاء سُجلت في التحليل التكيفي لتوجيه المراجعة القادمة" to "Mistakes were logged in adaptive analytics to guide the next review",
        "اختبار جديد" to "New Quiz", "إجابات مسجلة:" to "Recorded answers:", "إجابات خاطئة:" to "Incorrect answers:", "لا توجد بيانات كافية بعد" to "Not enough data yet",
        "ابدأ بحل بعض الأسئلة" to "Start by answering some questions", "أولوية مراجعة عالية" to "High review priority", "تحتاج مراجعة إضافية" to "Needs additional review", "أداء جيد" to "Good performance",
        "الخطة القادمة ستعطي الأولوية للمجالات ذات معدل الخطأ الأعلى" to "The next plan will prioritize areas with the highest error rate",
        "اختر مسارًا لبناء خطة تعلم مناسبة لمستواك" to "Choose a path to build a learning plan suited to your level", "المسار مصمم تدريجيًا من الأساسيات إلى التطبيق السريري" to "The path progresses from fundamentals to clinical application",
        "آخر 7 أيام" to "Last 7 days", "صحيحة:" to "Correct:", "خاطئة:" to "Incorrect:", "توزيع الأداء" to "Performance distribution", "أكثر المجالات احتياجًا للمراجعة" to "Areas most in need of review",
        "حل بعض الأسئلة أولًا لإنشاء تقرير مفصل" to "Answer some questions first to create a detailed report", "المراجعة التكيفية ستزيد أولوية المجالات الضعيفة تلقائيًا في الخطط القادمة" to "Adaptive review will automatically increase the priority of weak areas in future plans",
        "خطة اليوم الذكية" to "Smart Plan", "المستوى:" to "Level:", "التركيز:" to "Focus:", "المهام المقترحة اليوم" to "Suggested tasks today",
        "مراجعة ذكية:" to "Smart review:", "مواضيع:" to "Topics:", "الخطة تتكيف مع مستوى الاختبار وعدد البطاقات المستحقة" to "The plan adapts to quiz level and the number of due cards",
        "إذا أخطأت في موضوع، ستزداد أولوية مراجعته" to "If you make mistakes in a topic, its review priority increases", "ابدأ المراجعة الآن" to "Start review now",
        "بنك الأسئلة" to "Question Bank", "تم إنجاز الخطة اليوم" to "Today’s plan completed", "أحسنت! تم تسجيل إنجاز اليوم" to "Great job! Today’s achievement was recorded",
        "أكمل أول مراجعة ذكية" to "Complete your first smart review", "أجب عن 10 أسئلة" to "Answer 10 questions", "تعلم 7 أيام متتالية" to "Study for 7 consecutive days", "اجمع 500 نقطة خبرة" to "Earn 500 XP",
        "الإنجازات" to "Achievements", "افتح التحدي اليومي" to "Open Daily Challenge", "أجب عن" to "Answer", "أسئلة اليوم" to "questions today", "التقدم:" to "Progress:",
        "مكتمل" to "Complete", "اكتمل التحدي! ستحصل على XP إضافي" to "Challenge completed! You will earn bonus XP", "حل سؤال الآن" to "Answer a question now",
        "إعادة جدولة" to "Reschedule", "تمت جدولة التذكيرات" to "Reminders scheduled",
        "أجب عن 10 أسئلة." to "Answer 10 questions.", "اجمع 500 نقطة خبرة." to "Earn 500 XP.",
        "الخطوة التالية →" to "Next Step →", "عدد الأسئلة (مثال: 10)" to "Number of questions (e.g. 10)",
        "مستواك المبدئي: " to "Initial level: ", "🎯 النتيجة" to "🎯 Result"
    )

    private val extraTranslations: Map<String, String> = mapOf(
        "🔎 بحث" to "🔎 Search",
        "ارتفاع" to "Increase", "انخفاض" to "Decrease",
        "نتائج: " to "Results: ", "🎯 النتيجة" to "🎯 Result", "💊 الأدوية" to "💊 Drugs",
        "🔔 التذكيرات" to "🔔 Reminders", "💡 تفسير سريع" to "💡 Quick explanation", "📊 نقاط الضعف" to "📊 Weaknesses",
        "لا يوجد موضوع" to "No topic", "📚 أمثلة سريعة" to "📚 Quick Examples", "📚 موضوع اليوم" to "📚 Topic of the Day",
        "لا يوجد محتوى." to "No content.", "✅ إجابتك صحيحة" to "✅ Your answer is correct", "❌ تحتاج مراجعة" to "❌ Needs review",
        "🔎 التركيز: " to "🔎 Focus: ", "🔧 حالة التكامل" to "🔧 Integration Status", "🧠 أنظمة التعلم" to "🧠 Learning Systems",
        "التقييم: " to "Assessment: ", "السؤال التالي →" to "Next Question →", "📚 قاعدة المحتوى" to "📚 Content Database",
        "🔥 التحدي اليومي" to "🔥 Daily Challenge", "🎯 أولويات التحسين" to "🎯 Improvement Priorities", "📊 الذكاء التعليمي" to "📊 Learning Intelligence",
        "🔎 نتائج البحث: " to "🔎 Search Results: ", "🚀 ابدأ جلسة اليوم" to "🚀 Start Today’s Session", "🧠 ماذا أدرس الآن؟" to "🧠 What Should I Study Now?",
        "سُجلت جلسة التعلم." to "Study session recorded.", "❌ إجابتك غير صحيحة" to "❌ Your answer is incorrect", "💊 الأدوات السريرية" to "💊 Clinical Tools",
        "📈 التقرير الأسبوعي" to "📈 Weekly Report", "🩺 الحالات السريرية" to "🩺 Clinical Cases", "🎯 مهام وأهداف اليوم" to "🎯 Today’s Missions & Goals",
        "📚 المسارات الدراسية" to "📚 Study Paths", "🗓️ خطة اليوم الذكية" to "🗓️ Smart Plan", "اكتب حرفين على الأقل" to "Enter at least two characters",
        "القسم: " to "Category: ", "تعلم 7 أيام متتالية." to "Study for 7 consecutive days.", "تمت جدولة التذكيرات." to "Reminders scheduled.",
        "🏆 الإنجازات و Streak" to "🏆 Achievements & Streak", "🏆 التحفيز والتذكيرات" to "🏆 Motivation & Reminders", "أكمل أول مراجعة ذكية." to "Complete your first smart review.",
        "الإجابة:" to "Answer:", "الحالة" to "Case", "❌ إجابتك تحتاج مراجعة" to "❌ Your answer needs review",
        "التقييم:" to "Assessment:", "المستوى: " to "Level: ", "🎓 مستوى إتقان المواضيع" to "🎓 Topic Mastery",
        "🎯 اختبار تحديد المستوى" to "🎯 Placement Test", "📊 لوحة الذكاء التحليلي" to "📊 Analytics Dashboard", "🗺️ خارطة التعلم الشخصية" to "🗺️ Personal Learning Roadmap",
        "🚀 جلسة الدراسة التكيفية" to "🚀 Adaptive Study Session", "🧠 المدرّب السريري الذكي" to "🧠 Clinical Tutor", "🔎 البحث الشامل عن أي شيء" to "🔎 Search Everything",
        "💡 الشرح" to "💡 Explanation", "النتيجة: " to "Result: ", "عدد الأدوية: " to "Number of drugs: ", "عدد النتائج: " to "Number of results:",
        "📝 سؤال اليوم / بنك الأسئلة" to "📝 Question of the Day / Question Bank", "اكتب حرفين على الأقل للبحث." to "Enter at least two characters to search.",
        "📊 دقة المحاولات حسب الصعوبة" to "📊 Attempt Accuracy by Difficulty", "📖 قاعدة المعرفة بدون إنترنت" to "📖 Offline Knowledge Base",
        "🌐 اللغة: العربية  |  English" to "🌐 Language: العربية  |  English", "🌐 Language: English  |  العربية" to "🌐 Language: English  |  العربية",
        "📚 مواضيع: " to "📚 Topics: ", "التقدم اليومي: " to "Daily progress: ", "💡 لماذا؟" to "💡 Why?",
        "💡 القرار التعليمي" to "💡 Educational Decision", "📝 أسئلة: " to "📝 Questions: ", "التداخلات المحفوظة: " to "Saved interactions: ",
        "لا توجد بيانات هذا الأسبوع بعد." to "No data for this week yet.", "🎯 لماذا هذه الخطوة؟ " to "🎯 Why this step? ", "🧠 المراجعة الذكية (" to "🧠 Smart Review (",
        "الحالة: " to "Status: ", "🔥 Streak: " to "🔥 Streak: ", " يوم\n⭐ XP: " to " days\n⭐ XP: ",
        "المرحلة " to "Stage ", "💊 مكتبة الأدوية + الملفات الرئيسية" to "💊 Drug Library + Master Profiles",
        "⏱️ مؤقت اختياري (60 ثانية لكل سؤال)" to "⏱️ Optional timer (60 seconds per question)", "📌 نقطة الحفظ" to "📌 Key Takeaway",
        "📝 سؤال " to "📝 Question ", "🧠 مراجعة ذكية: " to "🧠 Smart Review: ", "📊 الإتقان: " to "📊 Mastery: ",
        "إجابات مسجلة: " to "Recorded answers: ", "إجابات خاطئة: " to "Incorrect answers: ", "التقدم: " to "Progress: ",
        "XP: " to "XP: ", "بطاقات مستحقة: " to "cards due: ", "أحسنت! مررت عبر " to "Great job! You completed ",
        "ما التأثير المتوقع لمنبه β2 على البوتاسيوم المصلي؟" to "What effect is expected from a β2 agonist on serum potassium?",
        "أي مستقبل يرتبط أساسًا بزيادة معدل وقوة انقباض القلب؟" to "Which receptor is primarily associated with increased heart rate and contractility?",
        "ما الهدف العام لضغط الدم المذكور في إرشاد AHA/ACC 2025؟" to "What is the general blood pressure target stated in the AHA/ACC 2025 guideline?",
        "جاهزية الوحدات: " to "Module readiness: ",
        "الإصدار: V51.0\nRoom schema: V17\nOffline-first: نعم\nالتوقيعات والنشر: تحتاج بيئة Android/Gradle كاملة" to "Version: V51.0\nRoom schema: V17\nOffline-first: Yes\nSigning & publishing: Requires a complete Android/Gradle environment",
        "🎚️ المستوى المستهدف: " to "🎚️ Target level: ", "أجب عن " to "Answer ", " أسئلة اليوم." to " questions today.",
        "الأخطاء التي حدثت في هذه الجلسة تُسجل للتعلم التكيفي، ويمكن تحويلها إلى مراجعة لاحقة." to "Mistakes from this session are logged for adaptive learning and can be converted into later review.",
        "ℹ️ المحتوى الدوائي تعليمي؛ تحقق دائمًا من المرجع الرسمي الحالي قبل الاستخدام السريري." to "ℹ️ Medication content is educational; always verify the current official reference before clinical use.",
        "أهداف يومية قصيرة وواضحة. أكملها تدريجيًا، ويمكنك فتح النشاط المناسب مباشرة من كل مهمة." to "Short, clear daily goals. Complete them gradually, and open the relevant activity directly from each mission.",
        "التقدم اليومي:" to "Daily progress:", "التقدم:" to "Progress:",
        "ℹ️ المهمة اليومية هي طبقة تحفيزية تعليمية؛ إكمال زر المهمة يسجل تقدم المهمة ولا يثبت وحده إتقان المحتوى." to "ℹ️ The daily mission is an educational motivation layer; completing the mission records progress but does not by itself prove mastery.",
        "فحص نهائي محلي قبل مرحلة بناء APK. لا يتم إرسال أي بيانات خارج الجهاز." to "Final local check before the APK build stage. No data is sent outside the device.",
        "الإصدار:" to "Version:", "نعم" to "Yes", "التوقيعات والنشر:" to "Signing & publishing:", "تحتاج بيئة Android/Gradle كاملة" to "Requires a complete Android/Gradle environment",
        "ℹ️ اجتياز هذا الفحص يعني أن البنية والبيانات الأساسية متصلة محليًا، لكنه لا يستبدل build/test على Android ولا اختبار APK على جهاز حقيقي." to "ℹ️ Passing this check means the core structure and data are connected locally, but it does not replace Android build/testing or APK testing on a real device.",
        "فحص جودة محلي قبل تسليم Release Candidate. لا يثبت هذا الفحص نجاح build أو سلامة الاستخدام السريري." to "Local quality check before the Release Candidate. This check does not prove build success or clinical safety.",
        "فحص محلي أخير لإعدادات التطبيق والـManifest والوحدات الأساسية. فحص APK/signing يبقى خارجيًا." to "Final local check of app settings, Manifest, and core modules. APK/signing verification remains external.",
        "النتيجة:" to "Result:", "فحوص ناجحة" to "checks passed",
        "ℹ️ إذا ظهر فحص الإشعارات ⚠️، امنح إذن الإشعارات من إعدادات Android ثم أعد الفحص. فحص APK لا يمكن اعتباره ناجحًا قبل بناء وتوقيع التطبيق فعليًا." to "ℹ️ If the notification check shows ⚠️, grant notification permission in Android settings and recheck. APK verification cannot be considered successful before the app is actually built and signed.",
        "هذه قائمة الاختبار التي يجب تنفيذها على Emulator أو هاتف Android حقيقي قبل إنشاء APK النهائي." to "Run this checklist on an emulator or real Android phone before creating the final APK.",
        "الحالة:" to "Status:", "ℹ️ هذا الاختبار لا يدّعي نجاح APK؛ هو تجهيز منظم للاختبار الخارجي الفعلي." to "ℹ️ This test does not claim APK success; it is an organized preparation for actual external testing.",
        "V51 يراجع جاهزية الوحدات الأساسية محليًا، مع فحص إعدادات التطبيق والتذكيرات دون إرسال بيانات خارج الجهاز." to "V51 checks core module readiness locally, including app settings and reminders, without sending data outside the device.",
        "جاهزية الوحدات:" to "Module readiness:", "ℹ️ هذا فحص بنيوي محلي وليس اختبارًا سريريًا أو ضمانًا لسلامة المحتوى الدوائي." to "ℹ️ This is a local structural check, not a clinical test or a guarantee of medication-content safety.",
        "نظام الإتقان يبني خريطة إتقان لكل موضوع ويحوّل النتيجة إلى أهداف 70% و80% و90% وMastered. كل الحسابات محلية." to "The mastery system builds a mastery map for each topic and converts results into 70%, 80%, 90%, and Mastered goals. All calculations are local.",
        "لا توجد بيانات إتقان بعد. ابدأ بحل MCQs أو جلسة الدراسة التكيفية." to "No mastery data yet. Start solving MCQs or begin an adaptive study session.",
        "إتقان:" to "Mastery:", "ثقة:" to "Confidence:", "الحالة:" to "Status:", "محاولات:" to "Attempts:",
        "مسار شخصي يحدد ماذا تدرس الآن، ماذا تراجع بعده، وما الخطوة التالية للوصول إلى Mastered. الأولوية مبنية على مستوى الإتقان الحالي." to "A personal path that determines what to study now, what to review next, and the next step toward Mastered. Priority is based on current mastery.",
        "لا توجد بيانات كافية لبناء خارطة شخصية بعد. ابدأ بحل MCQs أو جلسة الدراسة التكيفية." to "There is not enough data to build a personal roadmap yet. Start solving MCQs or begin an adaptive study session.",
        "تحليل محلي لأدائك الدراسي، مع تحويل الأخطاء إلى أولويات قابلة للتنفيذ." to "Local analysis of your study performance, converting mistakes into actionable priorities.",
        "ابدأ بالإجابة عن أسئلة أو مراجعة بطاقات حتى تتكوّن بيانات تحليلية." to "Answer questions or review cards to build analytics data.",
        "المحرك يختار الأولويات من أخطائك، بطاقات المراجعة المستحقة، مستواك، والتوازن بين التعلم الجديد والتطبيق السريري." to "The engine selects priorities from your mistakes, due review cards, your level, and the balance between new learning and clinical application.",
        "لا توجد توصيات بعد. ابدأ بجلسة مراجعة أو اختبار." to "No recommendations yet. Start a review session or quiz.",
        "محتوى أساسي مخزّن داخل التطبيق ويمكن الرجوع إليه دون اتصال بالإنترنت." to "Core content stored inside the app and available offline.",
        "🔎 بحث Offline" to "🔎 Offline Search", "نتائج:" to "Results:", "القسم:" to "Category:",
        "⚠️ المحتوى تعليمي. تحقق من المرجع الرسمي الحالي قبل اتخاذ قرار سريري." to "⚠️ Content is educational. Verify the current official reference before making a clinical decision.",
        "شبكة تربط الدواء بالمستقبل أو الهدف، المرض، الأعراض الجانبية، التداخلات والحالات السريرية. ابدأ باسم دواء أو مفهوم." to "A network connecting drugs with receptors or targets, diseases, adverse effects, interactions, and clinical cases. Start with a drug or concept.",
        "🕸️ نتائج الشبكة" to "🕸️ Graph Results", "لا توجد نتائج." to "No results.", "لا توجد روابط إضافية محفوظة." to "No additional saved links.",
        "🔎 البحث الشامل" to "🔎 Global Search", "ابحث من مكان واحد في الأدوية، ملفات الأدوية، الحالات، الأسئلة، المواضيع والتداخلات." to "Search from one place across drugs, drug profiles, cases, questions, topics, and interactions.",
        "لا توجد نتائج مطابقة. جرّب الاسم العلمي أو اسم الفئة الدوائية." to "No matching results. Try the generic name or drug class.",
        "🔗 الأدوية المرتبطة" to "🔗 Related Drugs", "🎉 اكتملت جلسة اليوم" to "🎉 Today’s session completed", "أحسنت! مررت عبر" to "Great job! You completed", "مراحل تعليمية مترابطة." to "connected learning stages.",
        "تم تسجيل الأنشطة محليًا لتغذية التحليل والمراجعة التكيفية." to "Activities were recorded locally to support analytics and adaptive review.",
        "حاول تذكر الإجابة قبل كشفها." to "Try to recall the answer before revealing it.", "الإجابة:" to "Answer:", "قيّم مدى سهولة تذكرك:" to "Rate how easily you recalled it:",
        "حاول بناء القرار الدوائي بنفسك قبل الكشف." to "Try to build the medication decision yourself before revealing the answer.", "قيّم تذكرك:" to "Rate your recall:",
        "اختر الدواء لفتح Drug Master Profile الكامل." to "Select a drug to open its full Drug Master Profile.", "عدد الأدوية:" to "Number of drugs:", "💊 نتائج البحث" to "💊 Search Results", "عدد النتائج:" to "Number of results:", "لا يوجد Master Profile لهذا الدواء بعد." to "No Master Profile exists for this drug yet.", "لا توجد نتيجة في قاعدة التداخلات الحالية." to "No result in the current interaction database.",
        "تعلّم الحالة خطوة بخطوة. لن تظهر الإجابة مباشرة؛ سيطلب منك المحرك تحديد المشكلة، اختيار القرار، ثم يشرح سبب صحة أو خطأ إجابتك." to "Learn the case step by step. The answer will not appear immediately; the engine will ask you to identify the problem, choose a decision, and explain why it is correct or incorrect.",
        "لا توجد حالات مهيأة للمحرك بعد." to "No cases are configured for the engine yet.", "اقرأ الحالة أولًا، ثم حاول بناء القرار الدوائي قبل إظهار الإجابة." to "Read the case first, then try to build the medication decision before revealing the answer.",
        "🔗 الأدوية المرتبطة بالحالة" to "🔗 Drugs related to the case", "ابحث عن اسم أحد الدواءين. هذه معلومات تعليمية وليست بديلًا عن مراجعة وصفة أو مرجع دوائي محدث." to "Search for either drug name. This is educational information and not a substitute for prescription review or an up-to-date drug reference.",
        "التداخلات المحفوظة:" to "Saved interactions:", "🔎 نتائج التداخلات" to "🔎 Interaction Results",
        "اختبار متكيف: اختر عدد الأسئلة، الصعوبة، والمؤقت الاختياري. بعد كل إجابة ستحصل على تفسير، وفي النهاية ستظهر الدقة والتوصية التالية." to "Adaptive quiz: choose the number of questions, difficulty, and optional timer. You will get an explanation after each answer, followed by accuracy and the next recommendation.",
        "💡 الصعوبة تُقدّر تلقائيًا من محتوى السؤال. يمكن توسيع بنك الأسئلة لاحقًا لإضافة مستويات أدق." to "💡 Difficulty is estimated automatically from question content. The question bank can be expanded later for finer levels.",
        "🏁 نتيجة الاختبار" to "🏁 Quiz Result", "صحيحة" to "correct", "الأخطاء سُجلت في التحليل التكيفي لتوجيه المراجعة القادمة." to "Mistakes were recorded in adaptive analytics to guide the next review.",
        "الصعوبة:" to "Difficulty:", "💡 الشرح" to "💡 Explanation", "📊 تحليل نقاط الضعف" to "📊 Weakness Analysis", "إجابات مسجلة:" to "Recorded answers:", "إجابات خاطئة:" to "Incorrect answers:",
        "لا توجد بيانات كافية بعد. ابدأ بحل بعض الأسئلة." to "Not enough data yet. Start by answering some questions.", "أخطاء:" to "Errors:", "⚠️ أولوية مراجعة عالية" to "⚠️ High review priority", "🔄 تحتاج مراجعة إضافية" to "🔄 Needs additional review", "✅ أداء جيد" to "✅ Good performance", "الخطة القادمة ستعطي الأولوية للمجالات ذات معدل الخطأ الأعلى." to "The next plan will prioritize areas with the highest error rate.",
        "اختر مسارًا لبناء خطة تعلم مناسبة لمستواك." to "Choose a path to build a learning plan suited to your level.", "المسار مصمم تدريجيًا من الأساسيات إلى التطبيق السريري." to "The path progresses from fundamentals to clinical application.",
        "آخر 7 أيام" to "Last 7 days", "صحيحة:" to "Correct:", "خاطئة:" to "Incorrect:", "الدقة:" to "Accuracy:", "توزيع الأداء" to "Performance Distribution", "أكثر المجالات احتياجًا للمراجعة" to "Areas most in need of review", "حل بعض الأسئلة أولًا لإنشاء تقرير مفصل." to "Answer some questions first to generate a detailed report.", "أخطاء" to "errors", "⚙️ المراجعة التكيفية ستزيد أولوية المجالات الضعيفة تلقائيًا في الخطط القادمة." to "⚙️ Adaptive review will automatically increase the priority of weak areas in future plans.",
        "3 أسئلة قصيرة لتقدير المستوى. لا يوجد خصم على الخطأ." to "3 short questions to estimate your level. There is no penalty for mistakes.", "النتيجة:" to "Result:", "مستواك المبدئي:" to "Initial level:", "سيُستخدم هذا المستوى لتوجيه المراجعة والخطة الدراسية." to "This level will guide your review and study plan.", "السؤال" to "Question", "من" to "of",
        "المستوى:" to "Level:", "التركيز:" to "Focus:", "📌 المهام المقترحة اليوم" to "📌 Suggested tasks today", "🧠 مراجعة ذكية:" to "🧠 Smart review:", "📚 مواضيع:" to "📚 Topics:", "📝 أسئلة:" to "📝 Questions:", "الخطة تتكيف مع مستوى الاختبار وعدد البطاقات المستحقة. إذا أخطأت في موضوع، ستزداد أولوية مراجعته." to "The plan adapts to quiz level and due cards. If you make mistakes in a topic, its review priority increases.",
        "🏆 الإنجازات" to "🏆 Achievements", "يوم" to "days", "أجب عن" to "Answer", "أسئلة اليوم." to "questions today.", "🎉 اكتمل التحدي! ستحصل على XP إضافي." to "🎉 Challenge completed! You will earn bonus XP.",
        "08:00 — موضوع اليوم\n19:00 — المراجعة الذكية" to "08:00 — Topic of the Day\n19:00 — Smart Review",
        "🚀 جاهزية الإصدار V51" to "🚀 Release Readiness V51", "🧪 مركز QA والإصدار" to "🧪 QA & Release Center", "🧰 فحص ما قبل الإصدار V51" to "🧰 Release Preflight V51", "📱 اختبار الجهاز قبل APK" to "📱 Device Smoke Test", "🛠️ فحص تكامل النظام" to "🛠️ System Integration Audit", "🗺️ خارطة التعلم" to "🗺️ Learning Roadmap", "🏠 الرئيسية" to "🏠 Home", "🔄 إعادة الفحص" to "🔄 Recheck", "🛠️ فحص التكامل التفصيلي" to "🛠️ Detailed Integration Audit", "🔄 إعادة فحص QA" to "🔄 Recheck QA", "🧪 مركز QA" to "🧪 QA Center", "🚀 جلسة تكيفية" to "🚀 Adaptive Session", "📝 اختبار لرفع الإتقان" to "📝 Quiz to Improve Mastery", "📊 التحليلات" to "📊 Analytics", "🚀 ابدأ جلسة تكيفية" to "🚀 Start Adaptive Session", "🎓 لوحة الإتقان" to "🎓 Mastery Dashboard", "🧠 ابدأ المراجعة" to "🧠 Start Review", "📝 ابدأ اختبارًا" to "📝 Start Quiz", "🔄 إعادة حساب الأولويات" to "🔄 Recalculate Priorities",
        "🔎 بحث داخل قاعدة المعرفة" to "🔎 Search Knowledge Base", "رجوع" to "Back", "بحث" to "Search", "🔎 استكشف الشبكة" to "🔎 Explore Graph", "🕸️ العودة للشبكة" to "🕸️ Back to Graph", "📚 عرض مكتبة الأدوية" to "📚 View Drug Library", "⚕️ عرض التداخلات" to "⚕️ View Interactions", "🔄 بحث جديد" to "🔄 New Search", "إظهار الإجابة" to "Show Answer", "رجوع للبحث" to "Back to Search", "📊 تحليل تقدمي" to "📊 Progress Analysis", "🔄 جلسة أخرى" to "🔄 Another Session", "✅ تمت القراءة — التالي" to "✅ Read — Next", "التالي →" to "Next →", "👁️ إظهار الإجابة" to "👁️ Show Answer", "🔍 إظهار القرار والتفسير" to "🔍 Show Decision & Explanation", "إكمال الجلسة →" to "Complete Session →", "⏹️ إنهاء الجلسة" to "⏹️ End Session", "تمت القراءة" to "Read", "رجوع للمكتبة" to "Back to Library", "🧠 دراسة هذا الدواء" to "🧠 Study this Drug", "⚕️ التداخلات المرتبطة" to "⚕️ Related Interactions", "🔄 إعادة الحالة" to "🔄 Restart Case", "🧠 حالات أخرى" to "🧠 More Cases", "إيقاف الجلسة" to "Stop Session", "⚕️ التداخلات الدوائية" to "⚕️ Drug Interactions", "رجوع للتداخلات" to "Back to Interactions", "🚀 بدء الاختبار" to "🚀 Start Quiz", "🔄 اختبار جديد" to "🔄 New Quiz", "⏹️ إنهاء الاختبار" to "⏹️ End Quiz", "اختبار تحديد المستوى" to "Placement Test", "العودة للرئيسية" to "Back to Home", "إلغاء" to "Cancel", "ابدأ المراجعة الآن" to "Start Review Now", "موضوع اليوم" to "Topic of the Day", "بنك الأسئلة" to "Question Bank", "تم إنجاز الخطة اليوم" to "Complete Today’s Plan", "🔥 افتح التحدي اليومي" to "🔥 Open Daily Challenge", "حل سؤال الآن" to "Answer a Question Now", "إعادة جدولة" to "Reschedule", "تم تسجيل جلسة دراسة" to "Study session recorded", "مثال: warfarin / digoxin" to "Example: warfarin / digoxin",
        "Daily Missions • Current" to "Daily Missions • Current", "مكتملة" to "Completed", "▶ تنفيذ المهمة" to "▶ Run Mission",
        "📦 حالة المشروع" to "📦 Project Status", "📊 لقطة البيانات" to "📊 Data Snapshot",
        "مثال: metoprolol / β2 / hypertension" to "Example: metoprolol / β2 / hypertension",
        "مثال: warfarin أو beta blocker" to "Example: warfarin or beta blocker",
        "لا توجد عناصر كافية لبناء جلسة الآن." to "There are not enough items to build a session now.",
        "لا توجد أسئلة كافية." to "Not enough questions.", "لا توجد بطاقات مستحقة الآن 🎉" to "No cards are due right now 🎉",
        "أحسنت! تم تسجيل إنجاز اليوم 🏆" to "Great job! Today’s achievement was recorded 🏆",
        "إجابتك صحيحة" to "Your answer is correct", "إجابتك غير صحيحة" to "Your answer is incorrect",
        "إجابتك:" to "Your answer:", "الإجابة الصحيحة:" to "Correct answer:", "عرض النتيجة" to "Show Result",
        "اختر أفضل إجابة." to "Choose the best answer.", "إلغاء" to "Cancel",
        "⏱️ لديك 60 ثانية تقريبًا لهذا السؤال." to "⏱️ You have about 60 seconds for this question.",
        "Severity:" to "Severity:", "Mechanism:" to "Mechanism:", "Management:" to "Management:", "Reference:" to "Reference:",
        "Last reviewed:" to "Last reviewed:", "Keywords:" to "Keywords:", "Type:" to "Type:",
        "Search drug / class" to "Search drug / class"

    )

    private fun tr(s: String): String {
        if (isArabic || s.isBlank()) return s
        var out = s
        (uiTranslations + extraTranslations).keys.sortedByDescending { it.length }.forEach { key ->
            out = out.replace(key, (uiTranslations + extraTranslations)[key]!!)
        }
        return out
    }

    private fun setLanguage(arabic: Boolean) {
        isArabic = arabic
        prefs.edit().putBoolean("arabic", arabic).apply()
        applyDirection()
        home()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        isArabic = prefs.getBoolean("arabic", true)
        applyDirection()
        repo = PharmaRepository(this)
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9)
        ReminderScheduler.scheduleAll(this)
        lifecycleScope.launch { repo.seedIfNeeded(); due = repo.dueCards(); home() }
    }

    private fun applyDirection() {
        window.decorView.layoutDirection = if (isArabic) android.view.View.LAYOUT_DIRECTION_RTL else android.view.View.LAYOUT_DIRECTION_LTR
    }

    private fun t(s: String, z: Float = 16f, b: Boolean = false)=TextView(this).apply {
        text=tr(s); textSize=z; setTextColor(Color.rgb(35,45,55)); setPadding(18,12,18,12)
        includeFontPadding=true; setHorizontallyScrolling(false); setLineSpacing(0f,1.08f)
        if(b)setTypeface(null,Typeface.BOLD)
    }
    private fun base()=LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(16,18,16,14); setBackgroundColor(Color.rgb(248,250,252))
    }
    private fun button(s: String, f: () -> Unit)=Button(this).apply {
        text=tr(s); textSize=15f; isAllCaps=false; setTextColor(Color.rgb(30,55,70));
        gravity=Gravity.CENTER; includeFontPadding=true; maxLines=3; ellipsize=null; setHorizontallyScrolling(false)
        setLineSpacing(0f, 1.08f)
        background=GradientDrawable().apply { setColor(Color.WHITE); cornerRadius=22f; setStroke(1,Color.rgb(220,226,232)) }
        setPadding(20,14,20,14); minimumHeight=56
        val lp=LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT); lp.setMargins(0,5,0,5); layoutParams=lp
        elevation=2f; setOnClickListener { f() }
    }
    private fun section(title:String)=TextView(this).apply {
        text=tr(title); textSize=19f; setTypeface(null,Typeface.BOLD); setTextColor(Color.rgb(25,70,90));
        includeFontPadding=true; maxLines=3; setLineSpacing(0f,1.08f);
        setPadding(8,18,8,8)
    }
    private fun statCard(label: String, value: String)=LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(10,12,10,12);
        background=GradientDrawable().apply { setColor(Color.WHITE); cornerRadius=20f; setStroke(1,Color.rgb(225,230,235)) }; elevation=3f
        addView(TextView(this@MainActivity).apply { text=value; textSize=21f; setTypeface(null,Typeface.BOLD); gravity=Gravity.CENTER })
        addView(TextView(this@MainActivity).apply { text=tr(label); textSize=12f; gravity=Gravity.CENTER })
    }
    private fun setScreen(content: LinearLayout, showNav: Boolean = true){
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(248,250,252)) }
        val scroll=ScrollView(this); scroll.addView(content, ViewGroup.LayoutParams(-1,-1)); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        if(showNav){
            val nav=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setPadding(6,6,6,6); setBackgroundColor(Color.WHITE); elevation=8f }
            fun navBtn(label:String, action:()->Unit)=TextView(this).apply { text=label; textSize=12f; gravity=Gravity.CENTER; setPadding(4,10,4,10); setOnClickListener{action()} }
            listOf(
                navBtn("⌂\n${ar("الرئيسية", "Home")}"){home()},
                navBtn("🧠\n${ar("مراجعة", "Review")}"){review()},
                navBtn("💊\n${ar("الأدوية", "Drugs")}"){drugLibrary()},
                navBtn("📊\n${ar("تحليلي", "Analytics")}"){weaknesses()}
            ).forEach { nav.addView(it,LinearLayout.LayoutParams(0,60,1f)) }
            root.addView(nav)
        }
        setContentView(root)
    }

    private fun home(){
        lifecycleScope.launch {
            val answered = repo.weeklyAnswered()
            val wrong = repo.weeklyWrong()
            val accuracy = if(answered == 0) 0 else ((answered - wrong) * 100 / answered)
            val xp = repo.xp()
            val streak = repo.streakDays()
            val plan = SmartPlanner(repo).today()
            val l = base()
            l.addView(t("Pharma Mentor 💊", 30f, true))
            l.addView(t("V51 • ${ar("تحضير إصدار APK", "APK Build Preparation")}", 16f, true))
            l.addView(t(ar("تعلّم بذكاء • راجع في الوقت المناسب • قِس تقدمك • طوّر نقاط ضعفك", "Learn smarter • Review at the right time • Track progress • Improve weak areas"), 16f))
            l.addView(button(ar("🌐 اللغة: العربية  |  English", "🌐 Language: English  |  العربية")) { setLanguage(!isArabic) })
            val stats=LinearLayout(this@MainActivity).apply { orientation=LinearLayout.HORIZONTAL; setPadding(0,8,0,8) }
            listOf(statCard("XP",xp.toString()),statCard(ar("الاستمرارية", "Streak"),streak.toString()),statCard(ar("الدقة", "Accuracy"),accuracy.toString()+"%"),statCard(ar("مستحقة", "Due"),due.size.toString())).forEach { stats.addView(it,LinearLayout.LayoutParams(0,92,1f).apply{setMargins(3,3,3,3)}) }
            l.addView(stats)
            l.addView(t(ar("🧠 ${due.size} بطاقات مستحقة • 📚 ${plan.topicCount} موضوع • 📝 ${plan.questionCount} سؤال • 🎯 ${plan.focus}", "🧠 ${due.size} cards due • 📚 ${plan.topicCount} topics • 📝 ${plan.questionCount} questions • 🎯 ${plan.focus}"), 15f, true))

            l.addView(button(ar("🔎 البحث الشامل عن أي شيء", "🔎 Search Everything")){globalSearch()})
            l.addView(button(ar("🕸️ Knowledge Graph", "🕸️ Knowledge Graph")){knowledgeGraph()})
            l.addView(button(ar("📖 قاعدة المعرفة بدون إنترنت", "📖 Offline Knowledge")){offlineKnowledge()})
            l.addView(section(ar("🚀 ابدأ جلسة اليوم", "🚀 Start Today’s Session")))
            l.addView(button(ar("🚀 جلسة الدراسة التكيفية", "🚀 Adaptive Study Session")){unifiedStudySession()})
            l.addView(button(ar("🎯 مهام وأهداف اليوم", "🎯 Today’s Missions & Goals")){dailyMissions()})
            l.addView(button(ar("🧠 المراجعة الذكية (${due.size})", "🧠 Smart Review (${due.size})")){review()})
            l.addView(button(ar("🧠 ماذا أدرس الآن؟", "🧠 What Should I Study Now?")){personalStudy()})
            l.addView(button(ar("🗓️ خطة اليوم الذكية", "🗓️ Smart Plan")){smartPlan()})
            l.addView(button(ar("📚 موضوع اليوم", "📚 Topic of the Day")){topic()})
            l.addView(button(ar("📝 سؤال اليوم / بنك الأسئلة", "📝 Question of the Day / Question Bank")){mcqs()})

            l.addView(section(ar("💊 الأدوات السريرية", "💊 Clinical Tools")))
            l.addView(button(ar("💊 مكتبة الأدوية + الملفات الرئيسية", "💊 Drug Library + Master Profiles")){drugLibrary()})
            l.addView(button(ar("⚕️ التداخلات الدوائية", "⚕️ Drug Interactions")){interactions()})
            l.addView(button(ar("🩺 الحالات السريرية", "🩺 Clinical Cases")){cases()})
            l.addView(button(ar("🧠 المدرّب السريري الذكي", "🧠 AI-like Clinical Tutor")){clinicalTutor()})

            l.addView(section(ar("📊 الذكاء التعليمي", "📊 Learning Intelligence")))
            l.addView(button(ar("📊 لوحة الذكاء التحليلي", "📊 Analytics Dashboard")){analyticsDashboard()})
            l.addView(button(ar("🎓 مستوى إتقان المواضيع", "🎓 Topic Mastery")){masteryDashboard()})
            l.addView(button(ar("🗺️ خارطة التعلم الشخصية", "🗺️ Personal Learning Roadmap")){learningRoadmap()})
            l.addView(button("🚀 جاهزية الإصدار V51"){releaseReadiness()})
            l.addView(button("🧪 مركز QA والإصدار"){qaCenter()})
            l.addView(button("🧰 فحص ما قبل الإصدار V51"){releasePreflight()})
            l.addView(button("📱 اختبار الجهاز قبل APK"){deviceSmokeTest()})
            l.addView(button("🛠️ فحص تكامل النظام"){systemAudit()})
            l.addView(button(ar("📊 نقاط الضعف", "📊 Weaknesses")){weaknesses()})
            l.addView(button(ar("📈 التقرير الأسبوعي", "📈 Weekly Report")){weeklyReport()})
            l.addView(button(ar("🎯 اختبار تحديد المستوى", "🎯 Placement Test")){placement()})
            l.addView(button(ar("📚 المسارات الدراسية", "📚 Study Paths")){paths()})

            l.addView(section(ar("🏆 التحفيز والتذكيرات", "🏆 Motivation & Reminders")))
            l.addView(button(ar("🔥 التحدي اليومي", "🔥 Daily Challenge")){dailyChallenge()})
            l.addView(button(ar("🏆 الإنجازات و Streak", "🏆 Achievements & Streak")){achievements()})
            l.addView(button(ar("🔔 التذكيرات", "🔔 Reminders")){reminders()})
            l.addView(t("ℹ️ المحتوى الدوائي تعليمي؛ تحقق دائمًا من المرجع الرسمي الحالي قبل الاستخدام السريري.", 13f))
            setScreen(l)
        }
    }

    private fun dailyMissions(){ lifecycleScope.launch {
        repo.seedIfNeeded()
        val missions = repo.todayMissions()
        val l = base()
        l.addView(t("🎯 Daily Missions • Current",27f,true))
        l.addView(t("أهداف يومية قصيرة وواضحة. أكملها تدريجيًا، ويمكنك فتح النشاط المناسب مباشرة من كل مهمة."))
        val done = missions.sumOf { minOf(it.completed, it.target) }
        val total = missions.sumOf { it.target }
        l.addView(t("التقدم اليومي: $done / $total",21f,true))
        missions.forEach { m ->
            val progress = minOf(m.completed, m.target)
            val icon = if(progress >= m.target) "✅" else "🎯"
            l.addView(section("$icon ${m.title}"))
            l.addView(t("التقدم: $progress / ${m.target}\n💡 ${m.reason}",14f))
            l.addView(button(if(progress >= m.target) "✅ مكتملة" else "▶ تنفيذ المهمة") {
                lifecycleScope.launch {
                    repo.completeMission(m.id)
                    when(m.type) {
                        "review" -> review()
                        "quiz" -> mcqs()
                        "weakness" -> unifiedStudySession()
                        else -> home()
                    }
                }
            })
        }
        l.addView(t("ℹ️ المهمة اليومية هي طبقة تحفيزية تعليمية؛ إكمال زر المهمة يسجل تقدم المهمة ولا يثبت وحده إتقان المحتوى.",13f))
        l.addView(button(ar("🚀 جلسة الدراسة التكيفية", "🚀 Adaptive Study Session")){unifiedStudySession()})
        l.addView(button("🗺️ خارطة التعلم"){learningRoadmap()})
        l.addView(button("🏠 الرئيسية"){home()})
        setScreen(l)
    } }

    private fun releaseReadiness(){ lifecycleScope.launch {
        repo.seedIfNeeded()
        val a = repo.systemAudit()
        val l = base()
        l.addView(t("🚀 Pharma Mentor V51 • Release Readiness",27f,true))
        l.addView(t("فحص نهائي محلي قبل مرحلة بناء APK. لا يتم إرسال أي بيانات خارج الجهاز.",15f))
        val checks = listOf(
            "قاعدة المحتوى" to (a.drugs > 0 && a.drugProfiles > 0 && a.mcqs > 0 && a.cases > 0),
            "التعلم التكيفي" to (a.reviewCards > 0 && a.srsStates >= 0 && a.recommendations >= 0),
            "التحليلات والإتقان" to (a.learningEvents >= 0),
            "الوحدات السريرية" to (a.interactions > 0 && a.tutorCases > 0),
            "Knowledge Graph" to (a.graphNodes > 0 && a.graphEdges > 0),
            "Offline Knowledge" to (a.offlineArticles > 0),
            "المهام اليومية" to (repo.todayMissions().isNotEmpty())
        )
        checks.forEach { (name, ok) -> l.addView(t("${if(ok) "✅" else "⚠️"} $name",17f, !ok)) }
        l.addView(section("📦 حالة المشروع"))
        l.addView(t("الإصدار: V51.0\nRoom schema: V17\nOffline-first: نعم\nالتوقيعات والنشر: تحتاج بيئة Android/Gradle كاملة",15f))
        l.addView(section("📊 لقطة البيانات"))
        l.addView(t("Drugs: ${a.drugs}\nProfiles: ${a.drugProfiles}\nMCQs: ${a.mcqs}\nCases: ${a.cases}\nInteractions: ${a.interactions}\nReview cards: ${a.reviewCards}\nDue cards: ${a.dueCards}\nSRS states: ${a.srsStates}\nLearning events: ${a.learningEvents}",14f))
        l.addView(t("ℹ️ اجتياز هذا الفحص يعني أن البنية والبيانات الأساسية متصلة محليًا، لكنه لا يستبدل build/test على Android ولا اختبار APK على جهاز حقيقي.",13f))
        l.addView(button("🔄 إعادة الفحص"){releaseReadiness()})
        l.addView(button("🛠️ فحص التكامل التفصيلي"){systemAudit()})
        l.addView(button("🏠 الرئيسية"){home()})
        setScreen(l)
    } }


    private fun qaCenter(){ lifecycleScope.launch {
        repo.seedIfNeeded()
        val a = repo.systemAudit()
        val l = base()
        l.addView(t("🧪 Pharma Mentor V51 • QA Center",27f,true))
        l.addView(t("فحص جودة محلي قبل تسليم Release Candidate. لا يثبت هذا الفحص نجاح build أو سلامة الاستخدام السريري.",15f))
        val checks = listOf(
            "Seed/content integrity" to (a.drugs > 0 && a.drugProfiles > 0 && a.mcqs > 0 && a.cases > 0),
            "Clinical module integrity" to (a.interactions > 0 && a.tutorCases > 0),
            "Learning engine integrity" to (a.reviewCards > 0 && a.srsStates >= 0 && a.recommendations >= 0),
            "Analytics/mastery storage" to (a.learningEvents >= 0),
            "Knowledge graph integrity" to (a.graphNodes > 0 && a.graphEdges > 0),
            "Offline knowledge integrity" to (a.offlineArticles > 0),
            "Daily mission storage" to repo.todayMissions().isNotEmpty()
        )
        checks.forEach { (name, ok) -> l.addView(t("${if(ok) "✅" else "⚠️"} $name",16f,!ok)) }
        l.addView(section("📦 Release Candidate"))
        l.addView(t("App version: 51.0\nRoom schema: 17\nArchitecture: Offline-first\nNetwork dependency: None for core learning\nAPK signing/build: Pending Android SDK + Gradle environment",15f))
        l.addView(section("🔍 Recommended external QA"))
        l.addView(t("1. Build debug APK\n2. Run on Android emulator/device\n3. Verify notification permission and reminders\n4. Test Room migration from previous release\n5. Walk through Home → Review → Quiz → Case → Analytics\n6. Build signed release and perform final smoke test",14f))
        l.addView(button("🔄 إعادة فحص QA"){qaCenter()})
        l.addView(button("🚀 Release Readiness"){releaseReadiness()})
        l.addView(button("🏠 الرئيسية"){home()})
        setScreen(l)
    } }

    private fun releasePreflight(){ lifecycleScope.launch {
        repo.seedIfNeeded()
        val audit = repo.systemAudit()
        val missions = repo.todayMissions()
        val result = ReleaseChecklist.run(this@MainActivity, audit, missions.size)
        val l = base()
        l.addView(t("🧰 Pharma Mentor V51 • Release Preflight",27f,true))
        l.addView(t("فحص محلي أخير لإعدادات التطبيق والـManifest والوحدات الأساسية. فحص APK/signing يبقى خارجيًا.",15f))
        l.addView(t("النتيجة: ${result.passed}/${result.total} فحوص ناجحة",22f,true))
        result.checks.forEach { c ->
            l.addView(section("${if(c.ok) "✅" else "⚠️"} ${c.name}"))
            l.addView(t(c.detail,14f))
        }
        l.addView(t("ℹ️ إذا ظهر فحص الإشعارات ⚠️، امنح إذن الإشعارات من إعدادات Android ثم أعد الفحص. فحص APK لا يمكن اعتباره ناجحًا قبل بناء وتوقيع التطبيق فعليًا.",13f))
        l.addView(button("🔄 إعادة الفحص"){releasePreflight()})
        l.addView(button("🧪 مركز QA"){qaCenter()})
        l.addView(button("🏠 الرئيسية"){home()})
        setScreen(l)
    } }

    private fun deviceSmokeTest(){
        val l=base()
        l.addView(t("📱 Pharma Mentor V51 • Device Smoke Test",27f,true))
        l.addView(t("هذه قائمة الاختبار التي يجب تنفيذها على Emulator أو هاتف Android حقيقي قبل إنشاء APK النهائي.",15f))
        DeviceSmokeTest.checklist().forEach { c ->
            val icon = when(c.status){ "PENDING" -> "🟡"; "EXTERNAL" -> "🔵"; else -> "✅" }
            l.addView(section("$icon ${c.name}"))
            l.addView(t("الحالة: ${c.status}\n${c.detail}",14f))
        }
        l.addView(section("📦 Release target"))
        l.addView(t("Version: ${ReleaseInfo.VERSION_NAME} (code ${ReleaseInfo.VERSION_CODE})\nRoom schema: ${ReleaseInfo.ROOM_SCHEMA}\nTarget SDK: 35\nMinimum SDK: 26",15f))
        l.addView(t("ℹ️ هذا الاختبار لا يدّعي نجاح APK؛ هو تجهيز منظم للاختبار الخارجي الفعلي.",13f))
        l.addView(button("🧰 Release Preflight"){releasePreflight()})
        l.addView(button("🏠 الرئيسية"){home()})
        setScreen(l)
    }

    private fun systemAudit(){ lifecycleScope.launch {
        repo.seedIfNeeded()
        val a = repo.systemAudit()
        val l = base()
        l.addView(t("🛠️ Pharma Mentor System Audit",27f,true))
        l.addView(t("V51 يراجع جاهزية الوحدات الأساسية محليًا، مع فحص إعدادات التطبيق والتذكيرات دون إرسال بيانات خارج الجهاز.",15f))
        l.addView(t("جاهزية الوحدات: ${a.healthyModules}/13",22f,true))
        l.addView(section("📚 قاعدة المحتوى"))
        listOf(
            "💊 Drug Library" to a.drugs, "📋 Drug Master Profiles" to a.drugProfiles,
            ar("🩺 الحالات السريرية", "🩺 Clinical Cases") to a.cases, "📝 MCQ Bank" to a.mcqs,
            "⚕️ Interactions" to a.interactions, "🧠 Clinical Tutor Cases" to a.tutorCases,
            "🕸️ Knowledge Graph Nodes" to a.graphNodes, "🔗 Knowledge Graph Edges" to a.graphEdges,
            "📖 Offline Knowledge" to a.offlineArticles
        ).forEach { (name,count) -> l.addView(t("${if(count>0) "✅" else "⚠️"} $name: $count",15f)) }
        l.addView(section("🧠 أنظمة التعلم"))
        listOf(
            "Review Cards" to a.reviewCards, "Due Cards" to a.dueCards,
            "SRS States" to a.srsStates, "Learning Events" to a.learningEvents,
            "Today's Recommendations" to a.recommendations
        ).forEach { (name,count) -> l.addView(t("$name: $count",15f)) }
        l.addView(section("🔧 حالة التكامل"))
        l.addView(t("Room DB: connected\nSeed data: initialized\nOffline mode: available\nAdaptive review: connected\nAnalytics: connected\nClinical modules: connected",15f))
        l.addView(t("ℹ️ هذا فحص بنيوي محلي وليس اختبارًا سريريًا أو ضمانًا لسلامة المحتوى الدوائي.",13f))
        l.addView(button("🔄 إعادة الفحص"){systemAudit()})
        l.addView(button("🏠 الرئيسية"){home()})
        setScreen(l)
    } }

    private fun masteryDashboard(){ lifecycleScope.launch {
        val items = repo.topicMastery()
        val l=base(); l.addView(t("🎓 Topic Mastery • Current",27f,true))
        l.addView(t("نظام الإتقان يبني خريطة إتقان لكل موضوع ويحوّل النتيجة إلى أهداف 70% و80% و90% وMastered. كل الحسابات محلية."))
        if(items.isEmpty()) l.addView(t("لا توجد بيانات إتقان بعد. ابدأ بحل MCQs أو جلسة الدراسة التكيفية."))
        items.take(12).forEach { m ->
            l.addView(t("${m.topic}\nإتقان: ${m.masteryPercent}% • ثقة: ${m.confidencePercent}%\nالحالة: ${MasteryEngine.status(m.masteryPercent)} • محاولات: ${m.attempts} • Streak: ${m.streak}",17f,m.masteryPercent<50))
            l.addView(t("📍 ${MasteryEngine.nextMilestone(m.masteryPercent)}",14f))
            l.addView(t("➡️ ${MasteryEngine.nextAction(m.masteryPercent)}",14f))
        }
        l.addView(button("🚀 جلسة تكيفية"){unifiedStudySession()})
        l.addView(button("📝 اختبار لرفع الإتقان"){mcqs()})
        l.addView(button("📊 التحليلات"){analyticsDashboard()})
        l.addView(button("🏠 الرئيسية"){home()}); setScreen(l)
    } }

    private fun learningRoadmap(){ lifecycleScope.launch {
        val roadmap = LearningRoadmapEngine.build(repo.topicMastery())
        val l = base()
        l.addView(t("🗺️ Personalized Learning Roadmap • Current",27f,true))
        l.addView(t("مسار شخصي يحدد ماذا تدرس الآن، ماذا تراجع بعده، وما الخطوة التالية للوصول إلى Mastered. الأولوية مبنية على مستوى الإتقان الحالي."))
        if(roadmap.isEmpty()) {
            l.addView(t("لا توجد بيانات كافية لبناء خارطة شخصية بعد. ابدأ بحل MCQs أو جلسة الدراسة التكيفية."))
        } else {
            roadmap.forEach { item ->
                l.addView(section("${item.rank}. ${item.topic}"))
                l.addView(t("📊 الإتقان: ${item.mastery}% • ${item.status}",17f,item.mastery < 50))
                l.addView(t("💡 ${item.reason}",14f))
                l.addView(t("➡️ ${item.action}",14f,true))
            }
        }
        l.addView(button("🚀 ابدأ جلسة تكيفية"){unifiedStudySession()})
        l.addView(button("🎓 لوحة الإتقان"){masteryDashboard()})
        l.addView(button("🏠 الرئيسية"){home()})
        setScreen(l)
    } }

    private fun analyticsDashboard(){ lifecycleScope.launch {
        val x=repo.progressIntelligence()
        val l=base(); l.addView(t("📊 Analytics & Progress Intelligence",27f,true))
        l.addView(t("تحليل محلي لأدائك الدراسي، مع تحويل الأخطاء إلى أولويات قابلة للتنفيذ."))
        val stats=LinearLayout(this@MainActivity).apply{orientation=LinearLayout.HORIZONTAL}
        listOf(statCard("الدقة الكلية", "${x.accuracyPercent}%"),statCard("هذا الأسبوع", "${x.weeklyAccuracyPercent}%"),statCard("الإجابات", x.totalAnswered.toString()),statCard("Streak", x.currentStreak.toString())).forEach{stats.addView(it,LinearLayout.LayoutParams(0,92,1f).apply{setMargins(3,3,3,3)})}
        l.addView(stats)
        l.addView(t("XP: ${x.xp}   •   بطاقات مستحقة: ${x.dueCards}",15f,true))
        l.addView(section("🎯 أولويات التحسين"))
        if(x.weakTopics.isEmpty()) l.addView(t("ابدأ بالإجابة عن أسئلة أو مراجعة بطاقات حتى تتكوّن بيانات تحليلية."))
        x.weakTopics.forEach{ w -> l.addView(t("${w.priority}  •  ${w.topic}  •  أخطاء ${w.wrong}/${w.total} (${w.errorPercent}%)",15f,w.priority=="HIGH")) }
        l.addView(section("💡 تفسير سريع"))
        l.addView(t(if(x.weeklyAnswered==0) "لا توجد بيانات هذا الأسبوع بعد." else "أجبت عن ${x.weeklyAnswered} سؤالًا هذا الأسبوع، منها ${x.weeklyWrong} إجابة خاطئة. استخدم المراجعة المتباعدة للموضوعات ذات الأولوية HIGH."))
        l.addView(button("🧠 ابدأ المراجعة"){review()}); l.addView(button("📝 ابدأ اختبارًا"){mcqs()}); l.addView(button("🏠 الرئيسية"){home()}); setScreen(l)
    } }

    private fun personalStudy(){ lifecycleScope.launch {
        val items=PersonalStudyEngine(repo).recommendations()
        val l=base(); l.addView(t(ar("🧠 ماذا أدرس الآن؟", "🧠 What Should I Study Now?"),27f,true)); l.addView(t("المحرك يختار الأولويات من أخطائك، بطاقات المراجعة المستحقة، مستواك، والتوازن بين التعلم الجديد والتطبيق السريري."))
        if(items.isEmpty()) l.addView(t("لا توجد توصيات بعد. ابدأ بجلسة مراجعة أو اختبار."))
        items.forEachIndexed { i,x ->
            val prefix=if(x.completed) "✅" else "${i+1}."
            l.addView(button("$prefix ${x.title}"){
                lifecycleScope.launch { repo.completeStudyRecommendation(x.id); when(x.type){
                    "review" -> review(); "quiz" -> mcqs(); "topic" -> topic(); "case" -> cases(); "weakness" -> weaknesses(); else -> home()
                }}
            })
            l.addView(t("${x.reason}\nالأولوية: ${x.priority}",14f))
        }
        l.addView(button("🔄 إعادة حساب الأولويات"){ lifecycleScope.launch { val key=java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date()); repo.studyRecommendations(key).forEach { repo.completeStudyRecommendation(it.id) }; personalStudy() } })
        l.addView(button("الرئيسية"){home()}); setScreen(l)
    } }

    private fun offlineKnowledge(){
        lifecycleScope.launch {
            val items=repo.offlineAll()
            val categories=items.map{it.category}.distinct()
            val l=base(); l.addView(t("📖 Offline Knowledge Base",27f,true)); l.addView(t("محتوى أساسي مخزّن داخل التطبيق ويمكن الرجوع إليه دون اتصال بالإنترنت."))
            l.addView(button("🔎 بحث داخل قاعدة المعرفة"){ offlineSearch() })
            categories.forEach { c -> l.addView(button("📚 $c"){ offlineCategory(c) }) }
            l.addView(button("الرئيسية"){home()}); setScreen(l)
        }
    }
    private fun offlineCategory(category:String){ lifecycleScope.launch { val l=base(); l.addView(t("📚 ${tr(category)}",25f,true)); repo.offlineByCategory(category).forEach { x -> l.addView(button(x.title){ offlineDetail(x.id) }) }; l.addView(button("رجوع"){offlineKnowledge()}); setScreen(l) } }
    private fun offlineSearch(){ val l=base(); l.addView(t("🔎 بحث Offline",25f,true)); val input=EditText(this).apply{hint=tr("اكتب اسم دواء أو موضوع أو كلمة مفتاحية")}; l.addView(input); l.addView(button("بحث"){ val q=input.text.toString().trim(); if(q.length<2) Toast.makeText(this@MainActivity,tr("اكتب حرفين على الأقل"),Toast.LENGTH_SHORT).show() else lifecycleScope.launch { val r=repo.searchOffline(q); val out=base(); out.addView(t("نتائج: $q",24f,true)); r.forEach{x->out.addView(button("${tr(x.category)} • ${x.title}"){offlineDetail(x.id)})}; out.addView(button("رجوع"){offlineKnowledge()}); setScreen(out) } }); l.addView(button("رجوع"){offlineKnowledge()}); setScreen(l) }
    private fun offlineDetail(id:String){ lifecycleScope.launch { val x=repo.offlineAll().firstOrNull{it.id==id} ?: return@launch; val l=base(); l.addView(t(x.title,26f,true)); l.addView(t("القسم: ${x.category}",15f,true)); l.addView(t(x.content,17f)); l.addView(t(ar("الكلمات المفتاحية: ${x.keywords}", "Keywords: ${x.keywords}"),13f)); l.addView(section(ar("📚 المرجع", "📚 Reference"))); l.addView(t(x.reference,14f)); l.addView(t(ar("آخر مراجعة: ${x.reviewed}", "Last reviewed: ${x.reviewed}"),12f)); l.addView(t("⚠️ المحتوى تعليمي. تحقق من المرجع الرسمي الحالي قبل اتخاذ قرار سريري." ,13f)); l.addView(button("رجوع"){offlineKnowledge()}); setScreen(l) } }

    private fun knowledgeGraph(){ lifecycleScope.launch {
        val nodes=repo.graphNodes(); val l=base(); l.addView(t(ar("🕸️ Knowledge Graph", "🕸️ Knowledge Graph"),27f,true));
        l.addView(t("شبكة تربط الدواء بالمستقبل أو الهدف، المرض، الأعراض الجانبية، التداخلات والحالات السريرية. ابدأ باسم دواء أو مفهوم."))
        val input=EditText(this@MainActivity).apply { hint=tr("مثال: metoprolol / β2 / hypertension"); setSingleLine(true) }; l.addView(input)
        l.addView(button("🔎 استكشف الشبكة"){ lifecycleScope.launch { val q=input.text.toString().trim(); val found=if(q.isEmpty()) nodes else repo.searchGraph(q); showGraphNodes(found) } })
        l.addView(section("📚 أمثلة سريعة")); nodes.filter{it.type=="Drug"}.take(10).forEach{ n -> l.addView(button("💊 ${n.label}"){ showGraphNode(n.id) }) }
        l.addView(button("الرئيسية"){home()}); setScreen(l)
    } }

    private fun showGraphNodes(nodes:List<KnowledgeGraphNodeEntity>){ val l=base(); l.addView(t("🕸️ نتائج الشبكة",26f,true)); if(nodes.isEmpty()) l.addView(t("لا توجد نتائج.")); nodes.forEach{ n -> l.addView(button("${typeIcon(n.type)} ${n.label}"){showGraphNode(n.id)}); if(n.description.isNotBlank()) l.addView(t(n.description,14f)) }; l.addView(button("رجوع"){knowledgeGraph()}); setScreen(l) }

    private fun showGraphNode(nodeId:String){ lifecycleScope.launch {
        val nodes=repo.graphNodes(); val n=nodes.firstOrNull{it.id==nodeId} ?: return@launch; val edges=repo.graphEdges(nodeId); val map=nodes.associateBy{it.id}; val l=base();
        l.addView(t("${typeIcon(n.type)} ${n.label}",27f,true)); l.addView(t(ar("النوع: ${n.type}", "Type: ${n.type}"),14f,true)); if(n.description.isNotBlank()) l.addView(t(n.description));
        l.addView(section("🔗 Connections (${edges.size})"));
        if(edges.isEmpty()) l.addView(t("لا توجد روابط إضافية محفوظة."));
        edges.forEach{ e -> val other=map[if(e.fromId==nodeId)e.toId else e.fromId]; if(other!=null){ val rel=if(e.fromId==nodeId)e.relation else "← ${e.relation}"; l.addView(button("${typeIcon(other.type)} ${other.label}\n$rel"){showGraphNode(other.id)}); if(e.reference.isNotBlank()) l.addView(t(ar("المرجع: ${e.reference}", "Reference: ${e.reference}"),12f)) } }
        l.addView(button("🕸️ العودة للشبكة"){knowledgeGraph()}); l.addView(button("الرئيسية"){home()}); setScreen(l)
    } }

    private fun typeIcon(type:String)=when(type){"Drug"->"💊";"Disease"->"🩺";"Receptor"->"⚙️";"Target"->"🎯";"Adverse effect"->"⚠️";"Interaction"->"⚕️";"Clinical case"->"📋";else->"🔗"}

    private fun globalSearch(){
        val l=base()
        l.addView(t("🔎 البحث الشامل",27f,true))
        l.addView(t("ابحث من مكان واحد في الأدوية، ملفات الأدوية، الحالات، الأسئلة، المواضيع والتداخلات."))
        val input=EditText(this).apply { hint=tr("مثال: warfarin أو beta blocker"); setSingleLine(true) }
        l.addView(input)
        l.addView(button("🔎 بحث"){ val q=input.text.toString().trim(); if(q.length<2){ Toast.makeText(this,tr("اكتب حرفين على الأقل للبحث."),Toast.LENGTH_SHORT).show() } else { runGlobalSearch(q) } })
        l.addView(button("📚 عرض مكتبة الأدوية"){drugLibrary()})
        l.addView(button("⚕️ عرض التداخلات"){interactions()})
        l.addView(button("الرئيسية"){home()})
        setScreen(l)
    }

    private fun runGlobalSearch(q:String){
        lifecycleScope.launch {
            val term=q.lowercase()
            val drugs=repo.allDrugs().filter { listOf(it.name,it.className,it.mechanism,it.uses,it.adverseEffects).any { v -> v.lowercase().contains(term) } }
            val profiles=repo.allDrugProfiles().filter { listOf(it.genericName,it.brandExamples,it.dosageForms,it.route,it.adultDose,it.renalConsiderations,it.hepaticConsiderations,it.monitoring,it.onLabel,it.offLabel,it.counseling).any { v -> v.lowercase().contains(term) } }
            val cases=repo.allCases().filter { listOf(it.title,it.scenario,it.answer).any { v -> v.lowercase().contains(term) } }
            val mcqs=repo.allMcqs().filter { listOf(it.question,it.options,it.explanation,it.topic).any { v -> v.lowercase().contains(term) } }
            val topics=repo.allTopics().filter { listOf(it.title,it.body,it.reference).any { v -> v.lowercase().contains(term) } }
            val interactions=repo.allInteractions().filter { listOf(it.drugA,it.drugB,it.mechanism,it.management).any { v -> v.lowercase().contains(term) } }

            val l=base()
            l.addView(t("🔎 نتائج البحث: $q",25f,true))
            l.addView(t("${drugs.size} أدوية • ${profiles.size} ملفات • ${cases.size} حالات • ${mcqs.size} أسئلة • ${topics.size} مواضيع • ${interactions.size} تداخلات",14f))
            if(drugs.isEmpty() && profiles.isEmpty() && cases.isEmpty() && mcqs.isEmpty() && topics.isEmpty() && interactions.isEmpty()) l.addView(t("لا توجد نتائج مطابقة. جرّب الاسم العلمي أو اسم الفئة الدوائية."))

            if(drugs.isNotEmpty()){
                l.addView(section("💊 الأدوية"))
                drugs.take(10).forEach { d ->
                    l.addView(button("${d.name} — ${d.className}"){showDrugMasterProfile(d.id,"search")})
                }
            }
            if(profiles.isNotEmpty()){
                l.addView(section("📋 Drug Master Profiles"))
                profiles.take(10).forEach { p ->
                    l.addView(button("${p.genericName} — Master Profile"){showDrugMasterProfile(p.drugId,"search")})
                }
            }
            if(cases.isNotEmpty()){
                l.addView(section(ar("🩺 الحالات السريرية", "🩺 Clinical Cases")))
                cases.take(10).forEach { c -> l.addView(button(c.title){showCaseFromSearch(c.id)}) }
            }
            if(mcqs.isNotEmpty()){
                l.addView(section("📝 Questions"))
                mcqs.take(10).forEach { qx -> l.addView(button(qx.question){mcqs()}) }
            }
            if(topics.isNotEmpty()){
                l.addView(section("📚 Daily Topics"))
                topics.take(10).forEach { tp -> l.addView(button(tp.title){topic()}) }
            }
            if(interactions.isNotEmpty()){
                l.addView(section(ar("⚕️ التداخلات الدوائية", "⚕️ Drug Interactions")))
                interactions.take(10).forEach { i -> l.addView(button("${i.drugA} + ${i.drugB}"){showInteractions(listOf(i))}) }
            }
            l.addView(button("🔄 بحث جديد"){globalSearch()})
            l.addView(button("الرئيسية"){home()})
            setScreen(l)
        }
    }

    private fun showCaseFromSearch(caseId:String){
        lifecycleScope.launch {
            val c=repo.allCases().firstOrNull { it.id==caseId } ?: return@launch
            val links=repo.caseLinks(c.id)
            val x=base(); x.addView(t(c.title,24f,true)); x.addView(t(c.scenario));
            x.addView(button("إظهار الإجابة"){Toast.makeText(this@MainActivity,c.answer,Toast.LENGTH_LONG).show()})
            if(links.isNotEmpty()){ x.addView(t("🔗 الأدوية المرتبطة",19f,true)); links.forEach { x.addView(t("${it.drugId}: ${it.rationale}")) } }
            x.addView(t(ar("المرجع: ${c.reference}", "Reference: ${c.reference}"),14f)); x.addView(button("رجوع للبحث"){globalSearch()}); setScreen(x)
        }
    }

    private fun unifiedStudySession(){
        lifecycleScope.launch {
            due = repo.dueCards()
            val topic = repo.latestTopic()
            val mcqs = repo.allMcqs()
            val cases = repo.allCases()
            val intelligence = repo.progressIntelligence()
            val recommendations = AdaptiveStudyCoach.buildPlan(
                intelligence = intelligence,
                hasTopic = topic != null,
                dueCards = due.size,
                hasQuiz = mcqs.isNotEmpty(),
                hasCase = cases.isNotEmpty()
            )
            val stages = recommendations.map { it.stage }.toMutableList()
            if(stages.isEmpty()){
                Toast.makeText(this@MainActivity, tr("لا توجد عناصر كافية لبناء جلسة الآن."), Toast.LENGTH_SHORT).show()
                home(); return@launch
            }
            var stageIndex = 0
            var adaptiveInserted = 0
            var reviewCard: ReviewCardEntity? = null
            var quiz: McqEntity? = null
            var clinicalCase: ClinicalCaseEntity? = null
            var topicDone = false
            var revealed = false
            var selected = ""
            var quizCorrect = false
            var caseDone = false
            var adaptiveDifficulty = AdaptiveDifficultyEngine.initialLevel(intelligence)
            var consecutiveCorrect = 0
            var consecutiveWrong = 0
            val usedQuizIds = mutableSetOf<String>()

            fun render(){
                val l=base()
                val total=stages.size
                if(stageIndex >= total){
                    l.addView(t("🎉 اكتملت جلسة اليوم",28f,true))
                    l.addView(t("أحسنت! مررت عبر ${total} مراحل تعليمية مترابطة.",18f,true))
                    l.addView(t("تم تسجيل الأنشطة محليًا لتغذية التحليل والمراجعة التكيفية."))
                    lifecycleScope.launch { repo.logSession("unified_study", "session-${System.currentTimeMillis()}", total) }
                    l.addView(button("📊 تحليل تقدمي"){analyticsDashboard()})
                    l.addView(button("🔄 جلسة أخرى"){unifiedStudySession()})
                    l.addView(button("🏠 الرئيسية"){home()})
                    setScreen(l); return
                }
                val stage=stages[stageIndex]
                l.addView(t("🧠 Adaptive Study Coach",27f,true))
                l.addView(t(ar("المرحلة ${stageIndex+1} من $total", "Stage ${stageIndex+1} of $total"),14f,true))
                l.addView(t(UnifiedStudySession.label(stage),21f,true))
                recommendations.getOrNull(stageIndex)?.let { r ->
                    l.addView(t("🎯 لماذا هذه الخطوة؟ ${r.reason}",14f,true))
                    r.focusTopic?.let { l.addView(t("🔎 التركيز: $it",14f)) }
                }
                when(stage){
                    UnifiedStudySession.Stage.TOPIC -> {
                        l.addView(t(topic?.title ?: "موضوع اليوم",20f,true))
                        l.addView(t(topic?.body ?: "لا يوجد محتوى."))
                        l.addView(t("📖 المرجع: ${topic?.reference ?: "—"}",14f))
                        if(!topicDone) l.addView(button("✅ تمت القراءة — التالي"){ topicDone=true; lifecycleScope.launch { topic?.let { repo.logSession("topic",it.id) }; stageIndex++; render() } })
                        else l.addView(button("التالي →"){stageIndex++;render()})
                    }
                    UnifiedStudySession.Stage.REVIEW -> {
                        if(reviewCard==null) reviewCard=due.firstOrNull()
                        val c=reviewCard
                        if(c==null){ stageIndex++; render(); return }
                        l.addView(t(c.question,19f,true))
                        if(!revealed){
                            l.addView(button("👁️ إظهار الإجابة"){revealed=true;render()})
                            l.addView(t("حاول تذكر الإجابة قبل كشفها."))
                        } else {
                            l.addView(t("الإجابة:\n${c.answer}",17f))
                            l.addView(t("قيّم مدى سهولة تذكرك:"))
                            listOf(Rating.AGAIN,Rating.HARD,Rating.GOOD,Rating.EASY).forEach { r ->
                                l.addView(button(r.name){
                                    lifecycleScope.launch {
                                        val current=repo.srsState(c.id) ?: AdvancedSpacedRepetitionEngine.initial(c.id,c.dueAt)
                                        val result=AdvancedSpacedRepetitionEngine.schedule(current,r)
                                        repo.save(c.copy(dueAt=result.state.dueAt,intervalDays=result.intervalDays,reps=result.state.repetitions,lapses=result.state.lapses,ease=when(r){Rating.EASY->c.ease+0.15;Rating.AGAIN->maxOf(1.3,c.ease-0.2);Rating.HARD->maxOf(1.3,c.ease-0.15);Rating.GOOD->c.ease}))
                                        repo.saveSrsState(result.state)
                                        repo.logLearningEvent(c.id,"unified_review",c.category,r!=Rating.AGAIN)
                                        val decision = AdaptiveSessionEngine.afterReview(r, c.category)
                                        if (decision.action == "QUIZ" && mcqs.isNotEmpty() && adaptiveInserted < 2) {
                                            AdaptiveSessionEngine.insertPriorityStage(stages, stageIndex, UnifiedStudySession.Stage.QUIZ)
                                            adaptiveInserted++
                                        }
                                        stageIndex++; render()
                                    }
                                })
                            }
                        }
                    }
                    UnifiedStudySession.Stage.QUIZ -> {
                        if(quiz==null) {
                            val focus = recommendations.getOrNull(stageIndex)?.focusTopic
                            val unused = mcqs.filterNot { usedQuizIds.contains(it.id) }
                            val focused = if(focus.isNullOrBlank()) unused else unused.filter { it.topic.contains(focus, true) }
                            val difficultyPool = focused.filter { AdvancedQuizEngine.difficultyOf(it) == adaptiveDifficulty }
                            val fallbackDifficulty = unused.filter { AdvancedQuizEngine.difficultyOf(it) == adaptiveDifficulty }
                            quiz = (difficultyPool.ifEmpty { fallbackDifficulty }.ifEmpty { focused }.ifEmpty { unused }.ifEmpty { mcqs }).randomOrNull()
                            quiz?.let { usedQuizIds += it.id }
                        }
                        val q=quiz
                        if(q==null){stageIndex++;render();return}
                        l.addView(t("🎚️ المستوى المستهدف: ${AdvancedQuizEngine.difficultyLabel(adaptiveDifficulty)}",13f,true))
                        l.addView(t(q.question,20f,true))
                        if(selected.isEmpty()){
                            q.options.split("|").forEach { opt -> l.addView(button(opt){
                                selected=opt; quizCorrect=opt.startsWith(q.correct.substringBefore('.')); render()
                            }) }
                        } else {
                            l.addView(t(if(quizCorrect) "✅ إجابتك صحيحة" else "❌ تحتاج مراجعة",19f,true))
                            l.addView(t("إجابتك: $selected\nالإجابة الصحيحة: ${q.correct}\n\n💡 ${q.explanation}",16f))
                            l.addView(t("📚 ${q.reference}",13f))
                            l.addView(button("التالي →"){
                                lifecycleScope.launch {
                                    if (quizCorrect) { consecutiveCorrect++; consecutiveWrong = 0 } else { consecutiveWrong++; consecutiveCorrect = 0 }
                                    val decision = AdaptiveDifficultyEngine.afterAnswer(adaptiveDifficulty, quizCorrect, consecutiveCorrect, consecutiveWrong)
                                    adaptiveDifficulty = decision.nextLevel
                                    Toast.makeText(this@MainActivity, tr("🎯 ${decision.label}: ${decision.reason}"), Toast.LENGTH_SHORT).show()
                                    repo.logLearningEvent(q.id,"unified_quiz",q.topic,quizCorrect)
                                    repo.logSession("unified_quiz",q.id,if(quizCorrect)1 else 0)
                                    val sessionDecision = AdaptiveSessionEngine.afterQuiz(quizCorrect, q.topic)
                                    if (sessionDecision.action == "REVIEW" && due.isNotEmpty() && adaptiveInserted < 2) {
                                        AdaptiveSessionEngine.insertPriorityStage(stages, stageIndex, UnifiedStudySession.Stage.REVIEW)
                                        adaptiveInserted++
                                    }
                                    stageIndex++; render()
                                }
                            })
                        }
                    }
                    UnifiedStudySession.Stage.CASE -> {
                        if(clinicalCase==null) clinicalCase=cases.randomOrNull()
                        val c=clinicalCase
                        if(c==null){stageIndex++;render();return}
                        l.addView(t(c.title,20f,true)); l.addView(t(c.scenario))
                        if(!caseDone){
                            l.addView(button("🔍 إظهار القرار والتفسير"){caseDone=true;render()})
                            l.addView(t("حاول بناء القرار الدوائي بنفسك قبل الكشف."))
                        } else {
                            l.addView(t("💡 القرار التعليمي\n${c.answer}",17f))
                            l.addView(t("📚 ${c.reference}",13f))
                            l.addView(button("إكمال الجلسة →"){ lifecycleScope.launch { repo.logSession("unified_case",c.id); stageIndex++; render() } })
                        }
                    }
                }
                l.addView(button("⏹️ إنهاء الجلسة"){home()})
                setScreen(l)
            }
            render()
        }
    }

    private fun review(){
        lifecycleScope.launch { due = repo.dueCards(); if(due.isEmpty()){ Toast.makeText(this@MainActivity,tr("لا توجد بطاقات مستحقة الآن 🎉"),Toast.LENGTH_SHORT).show(); home(); return@launch }
            val c=due[pos%due.size]; val l=base(); l.addView(t("🧠 Smart Review",26f,true)); l.addView(t(c.question,19f,true));
            l.addView(button("إظهار الإجابة"){ Toast.makeText(this@MainActivity,c.answer,Toast.LENGTH_LONG).show() })
            l.addView(t("قيّم تذكرك:")); listOf(Rating.AGAIN,Rating.HARD,Rating.GOOD,Rating.EASY).forEach { r -> l.addView(button(r.name){ saveReview(c,r) }) }
            l.addView(button("رجوع"){home()}); setScreen(l)
        }
    }

    private fun saveReview(c:ReviewCardEntity,r:Rating){
        lifecycleScope.launch {
            val current = repo.srsState(c.id) ?: AdvancedSpacedRepetitionEngine.initial(c.id, c.dueAt)
            val result = AdvancedSpacedRepetitionEngine.schedule(current, r)
            val updated = c.copy(
                dueAt = result.state.dueAt,
                intervalDays = result.intervalDays,
                ease = when (r) { Rating.EASY -> c.ease + 0.15; Rating.AGAIN -> maxOf(1.3, c.ease - 0.2); Rating.HARD -> maxOf(1.3, c.ease - 0.15); Rating.GOOD -> c.ease },
                reps = result.state.repetitions,
                lapses = result.state.lapses
            )
            repo.save(updated)
            repo.saveSrsState(result.state)
            repo.logLearningEvent(c.id,"review",c.category,r != Rating.AGAIN)
            due=repo.dueCards(); pos=0; review()
        }
    }

    private fun topic(){
        lifecycleScope.launch { val x=repo.latestTopic(); val l=base(); l.addView(t(ar("📚 موضوع اليوم", "📚 Topic of the Day"),26f,true)); l.addView(t(if (x?.title != null) x.title else ar("لا يوجد موضوع", "No topic"),20f,true)); l.addView(t(x?.body ?: "")); l.addView(t(ar("📖 المرجع: ${x?.reference ?: "—"}", "📖 Reference: ${x?.reference ?: "—"}"),14f)); l.addView(button("تمت القراءة"){ lifecycleScope.launch { repo.logSession("topic", x?.id ?: "daily-topic"); Toast.makeText(this@MainActivity,tr("سُجلت جلسة التعلم."),Toast.LENGTH_SHORT).show(); home() } }); l.addView(button("رجوع"){home()}); setScreen(l) }
    }
    private fun drugLibrary(){ lifecycleScope.launch {
        val items=repo.allDrugs(); val l=base(); l.addView(t(ar("💊 مكتبة الأدوية + الملفات الرئيسية", "💊 Drug Library + Master Profiles"),26f,true))
        l.addView(t("اختر الدواء لفتح Drug Master Profile الكامل."))
        val input=EditText(this@MainActivity).apply { hint=ar("ابحث عن دواء / فئة دوائية", "Search drug / class"); setSingleLine(true) }; l.addView(input)
        l.addView(button("🔎 Search"){ lifecycleScope.launch { val q=input.text.toString().trim(); showDrugResults(if(q.isEmpty()) repo.allDrugs() else repo.searchDrugs(q)) } })
        l.addView(t("عدد الأدوية: ${items.size}")); items.forEach { d -> l.addView(button(d.name+" — "+d.className){showDrugMasterProfile(d.id, "library")}) }
        l.addView(button("رجوع"){home()}); setScreen(l)
    } }

    private fun showDrugResults(items: List<DrugEntity>){
        val l=base(); l.addView(t("💊 نتائج البحث",26f,true)); l.addView(t("عدد النتائج: ${items.size}"))
        items.forEach { d -> l.addView(button(d.name+" — "+d.className){showDrugMasterProfile(d.id, "results")}) }
        l.addView(button("رجوع للمكتبة"){drugLibrary()}); l.addView(button("الرئيسية"){home()}); setScreen(l)
    }

    private fun showDrugMasterProfile(drugId:String, back:String){ lifecycleScope.launch {
        val d=repo.allDrugs().firstOrNull { it.id==drugId }; val p=repo.drugProfile(drugId)
        val l=base(); l.addView(t(ar("💊 الملف الدوائي الرئيسي", "💊 Drug Master Profile"),26f,true)); l.addView(t(d?.name ?: p?.genericName ?: drugId,22f,true))
        if(d!=null) { l.addView(t(ar("الفئة: ${d.className}", "Class: ${d.className}"),18f,true)); l.addView(t(ar("آلية العمل\n${d.mechanism}", "Mechanism\n${d.mechanism}"))); l.addView(t(ar("الاستخدامات الأساسية\n${d.uses}", "Core uses\n${d.uses}"))); l.addView(t(ar("الآثار الجانبية\n${d.adverseEffects}", "Adverse effects\n${d.adverseEffects}"))); l.addView(t(ar("موانع الاستعمال / التحذيرات\n${d.contraindications}", "Contraindications / cautions\n${d.contraindications}"))) }
        if(p==null) l.addView(t("لا يوجد Master Profile لهذا الدواء بعد.")) else {
            val sections=listOf(
                ar("الاسم العلمي", "Generic name") to p.genericName, ar("أمثلة تجارية", "Brand examples") to p.brandExamples, ar("الأشكال الدوائية", "Dosage forms") to p.dosageForms, ar("طريق الإعطاء", "Route") to p.route,
                ar("جرعة البالغين", "Adult dose") to p.adultDose, ar("جرعة الأطفال", "Pediatric dose") to p.pediatricDose, ar("اعتبارات الكلى", "Renal considerations") to p.renalConsiderations,
                ar("اعتبارات الكبد", "Hepatic considerations") to p.hepaticConsiderations, ar("المتابعة", "Monitoring") to p.monitoring, ar("الحمل", "Pregnancy") to p.pregnancy,
                ar("الرضاعة", "Lactation") to p.lactation, ar("معتمد", "On-label") to p.onLabel, ar("خارج النشرة", "Off-label") to p.offLabel, ar("إرشادات الاستخدام", "Counseling") to p.counseling,
                ar("تحذير صندوقي / تحذير رئيسي", "Boxed warning / major warning") to p.blackBoxWarning)
            sections.forEach { (h,v) -> l.addView(t("$h\n$v",16f)) }
            l.addView(t(ar("📚 المرجع\n${p.reference}\nآخر مراجعة: ${p.lastReviewed}", "📚 Reference\n${p.reference}\nLast reviewed: ${p.lastReviewed}"),14f))
            l.addView(button("🧠 دراسة هذا الدواء"){ lifecycleScope.launch { repo.logSession("drug_master", drugId); Toast.makeText(this@MainActivity,tr("تم تسجيل جلسة دراسة ${p.genericName}"),Toast.LENGTH_SHORT).show() } })
            l.addView(button("⚕️ التداخلات المرتبطة"){interactionsForDrug(p.genericName)})
        }
        l.addView(button("رجوع"){ lifecycleScope.launch { if(back=="results") showDrugResults(repo.allDrugs()) else drugLibrary() } }); l.addView(button("الرئيسية"){home()}); setScreen(l)
    } }

    private fun interactionsForDrug(name:String){ lifecycleScope.launch {
        val items=repo.searchInteractions(name); val l=base(); l.addView(t(ar("⚕️ التداخلات: $name", "⚕️ Interactions: $name"),26f,true));
        if(items.isEmpty()) l.addView(t("لا توجد نتيجة في قاعدة التداخلات الحالية.")) else items.forEach { x -> l.addView(t(ar("${x.drugA} + ${x.drugB}\nالخطورة: ${x.severity}\nآلية التداخل: ${x.mechanism}\nالتدبير: ${x.management}\nالمرجع: ${x.reference}", "${x.drugA} + ${x.drugB}\nSeverity: ${x.severity}\nMechanism: ${x.mechanism}\nManagement: ${x.management}\nReference: ${x.reference}"),15f)) }
        l.addView(button("رجوع"){ lifecycleScope.launch { showDrugMasterProfile(repo.allDrugs().firstOrNull { it.name.equals(name,true) || it.name.contains(name,true) }?.id ?: "", "library") } }); setScreen(l)
    } }

    private fun clinicalTutor(){
        lifecycleScope.launch {
            val ids = repo.tutorCases()
            val cases = repo.allCases().filter { ids.contains(it.id) }
            val l = base()
            l.addView(t(ar("🧠 المدرّب السريري الذكي", "🧠 AI-like Clinical Tutor"),27f,true))
            l.addView(t("تعلّم الحالة خطوة بخطوة. لن تظهر الإجابة مباشرة؛ سيطلب منك المحرك تحديد المشكلة، اختيار القرار، ثم يشرح سبب صحة أو خطأ إجابتك."))
            l.addView(t("Educational mode • Rule-based offline tutor",13f,true))
            if(cases.isEmpty()) l.addView(t("لا توجد حالات مهيأة للمحرك بعد."))
            cases.forEach { c ->
                l.addView(button("🩺 ${c.title}"){ startTutor(c.id) })
            }
            l.addView(button("الرئيسية"){home()})
            setScreen(l)
        }
    }

    private fun startTutor(caseId:String){
        lifecycleScope.launch {
            val c = repo.allCases().firstOrNull { it.id == caseId }
            val steps = repo.tutorSteps(caseId)
            if(c == null || steps.isEmpty()) { clinicalTutor(); return@launch }
            var index = 0
            var score = 0
            var answered = false
            fun render(){
                val l = base()
                l.addView(t("🧠 Clinical Tutor",26f,true))
                l.addView(t(c.title,21f,true))
                l.addView(t(ar("الحالة\n${c.scenario}", "Case\n${c.scenario}"),16f))
                if(index >= steps.size){
                    val pct = if(steps.isEmpty()) 0 else score * 100 / steps.size
                    l.addView(section("🎯 النتيجة"))
                    l.addView(t("$score/${steps.size} صحيحة — $pct%",23f,true))
                    val level = when { pct >= 90 -> "Excellent"; pct >= 70 -> "Good"; pct >= 50 -> "Needs review"; else -> "High-priority review" }
                    l.addView(t(ar("التقييم: $level", "Assessment: $level"),18f,true))
                    l.addView(t("الأخطاء التي حدثت في هذه الجلسة تُسجل للتعلم التكيفي، ويمكن تحويلها إلى مراجعة لاحقة."))
                    l.addView(button("🔄 إعادة الحالة"){startTutor(caseId)})
                    l.addView(button("🧠 حالات أخرى"){clinicalTutor()})
                    l.addView(button("الرئيسية"){home()})
                    setScreen(l)
                    return
                }
                val step = steps[index]
                l.addView(t("الخطوة ${index+1} من ${steps.size}",14f,true))
                l.addView(t(step.prompt,20f,true))
                if(!answered){
                    step.options.split("|").forEach { option ->
                        l.addView(button(option){
                            val correct = option.trim() == step.correctOption.trim()
                            if(correct) score++
                            answered = true
                            lifecycleScope.launch {
                                repo.recordTutorAttempt(caseId,index,option,correct)
                                repo.logLearningEvent("${caseId}_tutor_$index","clinical_tutor",c.title,correct)
                                render()
                            }
                        })
                    }
                } else {
                    // tutorAttempts is a suspend repository call; never call it directly
                    // from the synchronous UI renderer. Load it inside lifecycleScope.
                    lifecycleScope.launch {
                        val selected = repo.tutorAttempts(caseId)
                            .firstOrNull { it.stepIndex == index }
                            ?.selectedOption ?: ""
                        val lastCorrect = selected.trim() == step.correctOption.trim()
                        l.addView(t(if(lastCorrect) "✅ إجابتك صحيحة" else "❌ إجابتك تحتاج مراجعة",19f,true))
                        l.addView(t("إجابتك: $selected\nالإجابة الأفضل: ${step.correctOption}",16f))
                        l.addView(t("💡 لماذا؟\n${step.explanation}",16f))
                        l.addView(t("📌 نقطة الحفظ\n${step.teachingPoint}",16f,true))
                        l.addView(t("📚 ${step.reference}",13f))
                        l.addView(button(if(index+1 < steps.size) "الخطوة التالية →" else "عرض النتيجة") {
                            index++
                            answered=false
                            render()
                        })
                        setScreen(l)
                    }
                    return
                }
                l.addView(button("إيقاف الجلسة"){clinicalTutor()})
                setScreen(l)
            }
            render()
        }
    }

    private fun cases(){ lifecycleScope.launch { val items=repo.allCases(); val l=base(); l.addView(t(ar("🩺 الحالات السريرية", "🩺 Clinical Cases"),26f,true)); l.addView(t("اقرأ الحالة أولًا، ثم حاول بناء القرار الدوائي قبل إظهار الإجابة.")); items.forEach { c -> l.addView(button(c.title){ lifecycleScope.launch { val links=repo.caseLinks(c.id); val x=base(); x.addView(t(c.title,24f,true)); x.addView(t(c.scenario)); x.addView(button("إظهار الإجابة"){Toast.makeText(this@MainActivity,c.answer,Toast.LENGTH_LONG).show()}); if(links.isNotEmpty()){ x.addView(t("🔗 الأدوية المرتبطة بالحالة",19f,true)); links.forEach { link -> x.addView(t("${link.drugId}: ${link.rationale}")) } }; x.addView(t(ar("المرجع: ${c.reference}", "Reference: ${c.reference}"),14f)); x.addView(button("رجوع"){cases()}); setScreen(x) } }) }; l.addView(button("⚕️ التداخلات الدوائية"){interactions()}); l.addView(button("🧠 Clinical Tutor"){clinicalTutor()}); l.addView(button("الرئيسية"){home()}); setScreen(l) } }

    private fun interactions(){ lifecycleScope.launch { val all=repo.allInteractions(); val l=base(); l.addView(t(ar("⚕️ التداخلات الدوائية", "⚕️ Drug Interactions"),26f,true)); l.addView(t("ابحث عن اسم أحد الدواءين. هذه معلومات تعليمية وليست بديلًا عن مراجعة وصفة أو مرجع دوائي محدث.")); val input=EditText(this@MainActivity).apply { hint=tr("مثال: warfarin / digoxin"); setSingleLine(true) }; l.addView(input); l.addView(button("🔎 بحث"){ lifecycleScope.launch { val q=input.text.toString().trim(); showInteractions(if(q.isEmpty()) all else repo.searchInteractions(q)) } }); l.addView(t("التداخلات المحفوظة: ${all.size}",14f)); all.forEach { i -> l.addView(t("${i.drugA} + ${i.drugB}",19f,true)); l.addView(t("Severity: ${i.severity}\nMechanism: ${i.mechanism}\nManagement: ${i.management}\nReference: ${i.reference}",14f)) }; l.addView(button("رجوع"){home()}); setScreen(l) } }

    private fun showInteractions(items: List<DrugInteractionEntity>){ val l=base(); l.addView(t("🔎 نتائج التداخلات",25f,true)); if(items.isEmpty()) l.addView(t("لا توجد نتائج.")); items.forEach { i -> l.addView(t("${i.drugA} + ${i.drugB}",19f,true)); l.addView(t("Severity: ${i.severity}\n${i.mechanism}\nManagement: ${i.management}\nReference: ${i.reference}")) }; l.addView(button("رجوع للتداخلات"){interactions()}); setScreen(l) }

    private fun mcqs(){
        lifecycleScope.launch {
            val all = repo.allMcqs()
            val l = base()
            l.addView(t("📝 Advanced Quiz Engine",27f,true))
            l.addView(t("اختبار متكيف: اختر عدد الأسئلة، الصعوبة، والمؤقت الاختياري. بعد كل إجابة ستحصل على تفسير، وفي النهاية ستظهر الدقة والتوصية التالية."))
            val countInput = EditText(this@MainActivity).apply { hint=tr("عدد الأسئلة (مثال: 10)"); setSingleLine(true); inputType=2 }
            l.addView(countInput)
            val difficulty = Spinner(this@MainActivity).apply { adapter=ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Mixed","Easy","Medium","Hard")) }
            l.addView(difficulty)
            val timed = CheckBox(this@MainActivity).apply { text="⏱️ مؤقت اختياري (60 ثانية لكل سؤال)" }
            l.addView(timed)
            l.addView(button("🚀 بدء الاختبار"){ 
                val count=countInput.text.toString().toIntOrNull()?.coerceIn(1,all.size.coerceAtLeast(1)) ?: 10.coerceAtMost(all.size.coerceAtLeast(1))
                val level=difficulty.selectedItemPosition
                startAdvancedQuiz(all, AdvancedQuizEngine.Config(count,level,timed.isChecked))
            })
            l.addView(section("📊 دقة المحاولات حسب الصعوبة"))
            for(level in 1..3) l.addView(t("${AdvancedQuizEngine.difficultyLabel(level)}: ${repo.quizAccuracyAtDifficulty(level)}%"))
            l.addView(t("💡 الصعوبة تُقدّر تلقائيًا من محتوى السؤال. يمكن توسيع بنك الأسئلة لاحقًا لإضافة مستويات أدق."))
            l.addView(button("رجوع"){home()})
            setScreen(l)
        }
    }

    private fun startAdvancedQuiz(all:List<McqEntity>, config:AdvancedQuizEngine.Config){
        val questions=AdvancedQuizEngine.chooseQuestions(all,config)
        if(questions.isEmpty()){ Toast.makeText(this,tr("لا توجد أسئلة كافية."),Toast.LENGTH_SHORT).show(); return }
        val quizId="quiz-${System.currentTimeMillis()}"
        val started=System.currentTimeMillis()
        lifecycleScope.launch { repo.saveQuizSession(QuizSessionEntity(quizId,started,total=questions.size,difficulty=config.difficulty,timed=config.timed)) }
        var index=0; var correctCount=0; var answered=false; var selected=""; var startedQuestion=System.currentTimeMillis()
        fun render(){
            val l=base()
            if(index>=questions.size){
                val pct=AdvancedQuizEngine.scorePercent(correctCount,questions.size)
                l.addView(t("🏁 نتيجة الاختبار",27f,true))
                l.addView(t("$correctCount/${questions.size} صحيحة — $pct%",24f,true))
                l.addView(t(AdvancedQuizEngine.recommendation(pct),17f,true))
                l.addView(t("الأخطاء سُجلت في التحليل التكيفي لتوجيه المراجعة القادمة."))
                lifecycleScope.launch { repo.updateQuizSession(QuizSessionEntity(quizId,started,System.currentTimeMillis(),questions.size,questions.size,correctCount,config.difficulty,config.timed)); repo.logSession("advanced_quiz",quizId,correctCount) }
                l.addView(button("🔄 اختبار جديد"){mcqs()}); l.addView(button(ar("📊 نقاط الضعف", "📊 Weaknesses")){weaknesses()}); l.addView(button("الرئيسية"){home()}); setScreen(l); return
            }
            val q=questions[index]
            if(!answered) startedQuestion=System.currentTimeMillis()
            val qLevel=AdvancedQuizEngine.difficultyOf(q)
            l.addView(t("📝 سؤال ${index+1} من ${questions.size}",14f,true))
            l.addView(t("الصعوبة: ${AdvancedQuizEngine.difficultyLabel(qLevel)}",13f))
            l.addView(t(q.question,20f,true))
            if(!answered){
                q.options.split("|").forEach { opt ->
                    l.addView(button(opt){
                        selected=opt
                        val ok=opt.startsWith(q.correct.substringBefore('.'))
                        if(ok) correctCount++
                        answered=true
                        lifecycleScope.launch {
                            val elapsed=((System.currentTimeMillis()-startedQuestion)/1000L).toInt()
                            repo.saveQuizAttempt(QuizAttemptEntity("$quizId-${q.id}-$index",quizId,q.id,opt,ok,qLevel,q.topic,elapsed,System.currentTimeMillis()))
                            repo.logLearningEvent(q.id,"advanced_mcq",q.topic,ok)
                            render()
                        }
                    })
                }
                l.addView(t(if(config.timed) "⏱️ لديك 60 ثانية تقريبًا لهذا السؤال." else "اختر أفضل إجابة."))
            } else {
                val ok=selected.startsWith(q.correct.substringBefore('.'))
                l.addView(t(if(ok) "✅ إجابتك صحيحة" else "❌ إجابتك غير صحيحة",19f,true))
                l.addView(t("إجابتك: $selected\nالإجابة الصحيحة: ${q.correct}",16f))
                l.addView(t("💡 الشرح\n${q.explanation}",16f))
                l.addView(t("📚 ${q.reference}\nTopic: ${q.topic}",13f))
                l.addView(button(if(index+1<questions.size) "السؤال التالي →" else "عرض النتيجة"){index++;answered=false;selected="";render()})
            }
            l.addView(button("⏹️ إنهاء الاختبار"){home()})
            setScreen(l)
        }
        render()
    }

    private fun weaknesses(){ lifecycleScope.launch { val rows=repo.weaknesses(); val answered=repo.totalAnswered(); val wrong=repo.totalWrong(); val l=base(); l.addView(t("📊 تحليل نقاط الضعف",26f,true)); l.addView(t("إجابات مسجلة: $answered\nإجابات خاطئة: $wrong")); if(rows.isEmpty()) l.addView(t("لا توجد بيانات كافية بعد. ابدأ بحل بعض الأسئلة.")); else rows.take(10).forEach { r -> val rate=if(r.total==0) 0 else (r.wrong*100/r.total); l.addView(t("${r.topic}\nأخطاء: ${r.wrong}/${r.total} ($rate%)",18f,true)); if(rate>=40) l.addView(t("⚠️ أولوية مراجعة عالية")) else if(rate>=20) l.addView(t("🔄 تحتاج مراجعة إضافية")) else l.addView(t("✅ أداء جيد")) }; l.addView(t("الخطة القادمة ستعطي الأولوية للمجالات ذات معدل الخطأ الأعلى.")); l.addView(button("رجوع"){home()}); setScreen(l) } }

    private fun paths(){ lifecycleScope.launch {
        val items=repo.allPaths(); val l=base(); l.addView(t(ar("📚 المسارات الدراسية", "📚 Study Paths"),26f,true));
        l.addView(t("اختر مسارًا لبناء خطة تعلم مناسبة لمستواك."));
        items.forEach { p -> l.addView(button(p.title){
            val x=base(); x.addView(t(p.title,25f,true)); x.addView(t(p.description));
            x.addView(t("المسار مصمم تدريجيًا من الأساسيات إلى التطبيق السريري."));
            x.addView(button("اختبار تحديد المستوى"){placement(p.id)}); x.addView(button("رجوع"){paths()}); setScreen(x)
        }) }; l.addView(button("الرئيسية"){home()}); setScreen(l)
    } }

    private fun weeklyReport(){
        lifecycleScope.launch {
            val answered=repo.weeklyAnswered(); val wrong=repo.weeklyWrong(); val rows=repo.weeklyWeaknesses()
            val accuracy=if(answered==0) 0 else ((answered-wrong)*100/answered)
            val l=base(); l.addView(t(ar("📈 التقرير الأسبوعي", "📈 Weekly Report"),27f,true))
            l.addView(t("آخر 7 أيام",14f)); l.addView(t("إجابات: $answered\nصحيحة: ${answered-wrong}\nخاطئة: $wrong\nالدقة: $accuracy%",19f,true))
            l.addView(t("توزيع الأداء",20f,true))
            val filled=(accuracy/10).coerceIn(0,10); l.addView(t("[${"█".repeat(filled)}${"░".repeat(10-filled)}] $accuracy%"))
            l.addView(t("أكثر المجالات احتياجًا للمراجعة",20f,true))
            if(rows.isEmpty()) l.addView(t("حل بعض الأسئلة أولًا لإنشاء تقرير مفصل."))
            rows.take(5).forEach { r -> val rate=if(r.total==0)0 else r.wrong*100/r.total; l.addView(t("${r.topic}: $rate% أخطاء (${r.wrong}/${r.total})")) }
            l.addView(t("⚙️ المراجعة التكيفية ستزيد أولوية المجالات الضعيفة تلقائيًا في الخطط القادمة."))
            l.addView(button("رجوع"){home()}); setScreen(l)
        }
    }

    private fun placement(pathId:String?=null){
        val qs=listOf(
            Triple("أي مستقبل يرتبط أساسًا بزيادة معدل وقوة انقباض القلب؟","β1","β2"),
            Triple("ما التأثير المتوقع لمنبه β2 على البوتاسيوم المصلي؟","انخفاض","ارتفاع"),
            Triple("ما الهدف العام لضغط الدم المذكور في إرشاد AHA/ACC 2025؟","<130/80 mmHg","<150/100 mmHg")
        ); var score=0; var i=0; val l=base(); l.addView(t("🎯 Placement Test",26f,true)); l.addView(t("3 أسئلة قصيرة لتقدير المستوى. لا يوجد خصم على الخطأ."));
        fun render(){ if(i>=qs.size){ val level=when{score==3->"Expert"; score==2->"Advanced"; score==1->"Intermediate"; else->"Starter"}; lifecycleScope.launch { repo.savePlacement(PlacementResultEntity("placement-${System.currentTimeMillis()}",pathId?:"general",score,qs.size,level,System.currentTimeMillis())) }; l.removeAllViews(); l.addView(t(ar("النتيجة: $score/${qs.size}", "Result: $score/${qs.size}"),26f,true)); l.addView(t(ar("مستواك المبدئي: $level", "Initial level: $level"),21f,true)); l.addView(t("سيُستخدم هذا المستوى لتوجيه المراجعة والخطة الدراسية.")); l.addView(button("العودة للرئيسية"){home()}); setScreen(l); return }; val q=qs[i]; l.removeAllViews(); l.addView(t(ar("السؤال ${i+1} من ${qs.size}", "Question ${i+1} of ${qs.size}"),14f)); l.addView(t(q.first,20f,true)); listOf(q.second,q.third).forEach { a-> l.addView(button(a){ if((i==0&&a=="β1")||(i==1&&a=="انخفاض")||(i==2&&a=="<130/80 mmHg")) score++; i++; render() }) }; l.addView(button("إلغاء"){home()}); setScreen(l) }
        render()
    }

    private fun smartPlan(){
        lifecycleScope.launch {
            val plan = SmartPlanner(repo).today()
            val l=base(); l.addView(t(ar("🗓️ خطة اليوم الذكية", "🗓️ Smart Plan"),27f,true))
            l.addView(t("المستوى: ${plan.level}",19f,true))
            l.addView(t("التركيز: ${plan.focus}"))
            l.addView(t("📌 المهام المقترحة اليوم",20f,true))
            l.addView(t("🧠 مراجعة ذكية: ${plan.reviewCount} بطاقة"))
            l.addView(t("📚 مواضيع: ${plan.topicCount}"))
            l.addView(t("📝 أسئلة: ${plan.questionCount}"))
            l.addView(t("الخطة تتكيف مع مستوى الاختبار وعدد البطاقات المستحقة. إذا أخطأت في موضوع، ستزداد أولوية مراجعته."))
            l.addView(button("ابدأ المراجعة الآن"){review()})
            l.addView(button("موضوع اليوم"){topic()})
            l.addView(button("بنك الأسئلة"){mcqs()})
            l.addView(button("تم إنجاز الخطة اليوم"){ lifecycleScope.launch { repo.completeSmartPlan(plan.id); Toast.makeText(this@MainActivity,tr("أحسنت! تم تسجيل إنجاز اليوم 🏆"),Toast.LENGTH_SHORT).show(); home() } })
            l.addView(button("رجوع"){home()}); setScreen(l)
        }
    }

    private fun achievements(){
        lifecycleScope.launch {
            val xp=repo.xp(); val streak=repo.streakDays(); val unlocked=repo.unlockedAchievements().map{it.key}.toSet()
            val defs=listOf(
                Triple("first_review","First Review","أكمل أول مراجعة ذكية."),
                Triple("ten_answers","10 Answers","أجب عن 10 أسئلة."),
                Triple("week_streak","7-Day Streak","تعلم 7 أيام متتالية."),
                Triple("five_hundred_xp","500 XP","اجمع 500 نقطة خبرة."))
            val l=base(); l.addView(t("🏆 الإنجازات",27f,true)); l.addView(t("🔥 Streak: $streak يوم\n⭐ XP: $xp",21f,true));
            defs.forEach{ d-> val ok=unlocked.contains(d.first); l.addView(t("${if(ok)"🏆" else "🔒"} ${d.second}\n${d.third}")) }
            if(streak>=7) repo.recordAchievement("week_streak")
            if(xp>=500) repo.recordAchievement("five_hundred_xp")
            if(repo.totalAnswered()>=10) repo.recordAchievement("ten_answers")
            l.addView(button("🔥 افتح التحدي اليومي"){dailyChallenge()}); l.addView(button("رجوع"){home()}); setScreen(l)
        }
    }

    private fun dailyChallenge(){
        lifecycleScope.launch {
            var c=repo.todayChallenge(); val l=base(); l.addView(t(ar("🔥 التحدي اليومي", "🔥 Daily Challenge"),27f,true)); l.addView(t("أجب عن ${c.target} أسئلة اليوم.\nالتقدم: ${c.completed}/${c.target}",19f,true));
            val progress=(c.completed*100/c.target).coerceIn(0,100); l.addView(t("$progress% مكتمل"));
            if(c.completed>=c.target){ l.addView(t("🎉 اكتمل التحدي! ستحصل على XP إضافي.")); }
            else l.addView(button("حل سؤال الآن"){
                lifecycleScope.launch {
                    c=repo.incrementChallenge(); repo.recordAchievement("first_review");
                    if(c.completed>=c.target) { repo.awardChallengeXpIfNeeded(); repo.recordAchievement("ten_answers") }
                    dailyChallenge()
                }
            })
            l.addView(button("رجوع"){home()}); setScreen(l)
        }
    }

    private fun reminders(){ val l=base(); l.addView(t(ar("🔔 التذكيرات", "🔔 Reminders"),26f,true)); l.addView(t("08:00 — موضوع اليوم\n19:00 — المراجعة الذكية")); l.addView(button("إعادة جدولة"){ReminderScheduler.scheduleAll(this);Toast.makeText(this,tr("تمت جدولة التذكيرات."),Toast.LENGTH_SHORT).show()}); l.addView(button("رجوع"){home()});setScreen(l) }
}
