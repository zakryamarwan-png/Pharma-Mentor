# Pharma Mentor — Unified Drug Library

This release uses `ComprehensiveDrugSeed` as the single canonical in-app drug library.

- Total unique drug entries: **212**
- Previous 95-entry catalog: **fully retained**
- Additional entries merged: **117**
- Duplicate drug IDs in canonical catalog: **0**
- Legacy `atropine` entry is now included in the canonical catalog. `salbutamol` is represented as the international alias of the canonical `albuterol` entry to avoid duplicate pharmacologic records.
- Legacy `LibrarySeed` and `DrugProfileSeed` are retained for application compatibility; the Comprehensive Drug Library is the unified catalog used by the comprehensive-library screens.

The comprehensive library is educational content. Verify current official product labeling and local clinical guidelines before clinical use.
