# Pharma Mentor — Final Clinical Library (632)

## Scope
- 632 unique comprehensive drug records are retained.
- DrugProfileEntity now mirrors the full clinical fields already present in the comprehensive catalog, including mechanism, indications, adverse effects, contraindications, interactions, toxicity and antidote.
- Room database version: 20, with migration 19 -> 20.

## Evidence status
This build does **not** claim that every one of the 632 records has been individually verified against a current official label. The existing catalog contains 94 records with drug-specific mechanism/indication content and 538 records that still require drug-specific clinical verification.

## Required verification fields
Mechanism; approved indications; adult dose by indication/formulation; pediatric dose; renal/hepatic adjustment; adverse effects; contraindications; interactions; monitoring; pregnancy; lactation; toxicity/overdose; antidote; counseling; on-label/off-label status; primary references; review date.

## Reference hierarchy
1. Current official prescribing information / regulator labeling (FDA USPI/DailyMed or applicable national regulator).
2. WHO Model List of Essential Medicines 2025 and EMLc 2025 where relevant.
3. Current specialty guidelines and high-quality evidence for indication-specific recommendations.

## Safety rule
Educational use only. Exact dose, formulation, indication, contraindication, interaction, pregnancy/lactation status and boxed-warning status must be checked against the current product label and applicable local guidance before clinical use.


## Final release gate
- Catalog target: 632 unique drugs.
- No duplicate drugId values are permitted.
- Every catalog record receives a linked DrugProfileEntity.
- All clinical fields are stored in the offline database.
- The app must not present a generic class-level statement as a verified drug-specific dose; exact label-dependent data is explicitly marked for verification where not individually verified.
- GitHub Actions Gradle setup is the source of Gradle in CI; the project no longer attempts an internet download from the wrapper.
