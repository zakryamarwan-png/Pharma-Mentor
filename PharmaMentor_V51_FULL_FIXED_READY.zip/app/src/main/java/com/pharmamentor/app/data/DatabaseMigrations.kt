package com.pharmamentor.app.data

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

object DatabaseMigrations {
    val MIGRATION_18_19 = object : Migration(18, 19) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS comprehensive_drug_library (
                    drugId TEXT NOT NULL PRIMARY KEY,
                    genericName TEXT NOT NULL,
                    brandExamples TEXT NOT NULL,
                    therapeuticGroup TEXT NOT NULL,
                    drugClass TEXT NOT NULL,
                    mechanism TEXT NOT NULL,
                    indications TEXT NOT NULL,
                    adultDose TEXT NOT NULL,
                    pediatricDose TEXT NOT NULL,
                    renalConsiderations TEXT NOT NULL,
                    hepaticConsiderations TEXT NOT NULL,
                    adverseEffects TEXT NOT NULL,
                    contraindications TEXT NOT NULL,
                    interactions TEXT NOT NULL,
                    monitoring TEXT NOT NULL,
                    pregnancy TEXT NOT NULL,
                    lactation TEXT NOT NULL,
                    toxicity TEXT NOT NULL,
                    antidote TEXT NOT NULL,
                    counseling TEXT NOT NULL,
                    onLabel TEXT NOT NULL,
                    offLabel TEXT NOT NULL,
                    reference TEXT NOT NULL,
                    lastReviewed TEXT NOT NULL
                )
            """.trimIndent())
        }
    }
}
