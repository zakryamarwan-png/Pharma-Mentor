package com.pharmamentor.app.data

import com.pharmamentor.app.Rating

/** Decides the next step during a live study session from the learner's immediate result. */
object AdaptiveSessionEngine {
    data class Decision(val action: String, val reason: String)

    fun afterQuiz(correct: Boolean, topic: String): Decision =
        if (correct) Decision("CONTINUE", "إجابة صحيحة في $topic؛ انتقل للتطبيق أو للمفهوم التالي.")
        else Decision("REVIEW", "إجابة غير صحيحة في $topic؛ أضف مراجعة فورية قبل الاستمرار.")

    fun afterReview(rating: Rating, topic: String): Decision = when (rating) {
        Rating.AGAIN -> Decision("QUIZ", "تذكّر غير كافٍ في $topic؛ اختبر الاستدعاء مرة أخرى بعد المراجعة.")
        Rating.HARD -> Decision("CONTINUE", "تذكّر صعب في $topic؛ واصل مع خطوة تطبيقية.")
        Rating.GOOD, Rating.EASY -> Decision("CONTINUE", "تذكّر جيد في $topic؛ واصل إلى الخطوة التالية.")
    }

    fun insertPriorityStage(stages: MutableList<UnifiedStudySession.Stage>, index: Int, stage: UnifiedStudySession.Stage) {
        val safe = (index + 1).coerceIn(0, stages.size)
        stages.add(safe, stage)
    }
}
