package com.pharmamentor.app.data


/** Decides the next step during a live study session from the learner's immediate result. */
object AdaptiveSessionEngine {
    data class Decision(val action: String, val reason: String)

    fun afterQuiz(correct: Boolean, topic: String): Decision =
        if (correct) Decision("CONTINUE", "إجابة صحيحة في $topic؛ انتقل للتطبيق أو للمفهوم التالي.")
        else Decision("REVIEW", "إجابة غير صحيحة في $topic؛ أضف مراجعة فورية قبل الاستمرار.")

    fun afterReview(rating: com.pharmamentor.app.Rating, topic: String): Decision = when (rating) {
        com.pharmamentor.app.Rating.AGAIN -> Decision("QUIZ", "تذكّر غير كافٍ في $topic؛ اختبر الاستدعاء مرة أخرى بعد المراجعة.")
        com.pharmamentor.app.Rating.HARD -> Decision("CONTINUE", "تذكّر صعب في $topic؛ واصل مع خطوة تطبيقية.")
        com.pharmamentor.app.Rating.GOOD, com.pharmamentor.app.Rating.EASY -> Decision("CONTINUE", "تذكّر جيد في $topic؛ واصل إلى الخطوة التالية.")
    }

    fun insertPriorityStage(stages: MutableList<UnifiedStudySession.Stage>, index: Int, stage: UnifiedStudySession.Stage) {
        val safe = (index + 1).coerceIn(0, stages.size)
        stages.add(safe, stage)
    }
}
