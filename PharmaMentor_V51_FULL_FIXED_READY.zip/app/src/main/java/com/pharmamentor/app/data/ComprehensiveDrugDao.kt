package com.pharmamentor.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ComprehensiveDrugDao {
    @Query("SELECT * FROM comprehensive_drug_library ORDER BY therapeuticGroup, genericName")
    suspend fun all(): List<ComprehensiveDrugEntity>

    @Query("SELECT DISTINCT therapeuticGroup FROM comprehensive_drug_library ORDER BY therapeuticGroup")
    suspend fun groups(): List<String>

    @Query("SELECT * FROM comprehensive_drug_library WHERE therapeuticGroup = :group ORDER BY genericName")
    suspend fun byGroup(group: String): List<ComprehensiveDrugEntity>

    @Query("SELECT * FROM comprehensive_drug_library WHERE drugId = :drugId LIMIT 1")
    suspend fun byId(drugId: String): ComprehensiveDrugEntity?

    @Query("SELECT * FROM comprehensive_drug_library WHERE genericName LIKE '%' || :term || '%' OR brandExamples LIKE '%' || :term || '%' OR therapeuticGroup LIKE '%' || :term || '%' OR drugClass LIKE '%' || :term || '%' ORDER BY genericName")
    suspend fun search(term: String): List<ComprehensiveDrugEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<ComprehensiveDrugEntity>)
}
