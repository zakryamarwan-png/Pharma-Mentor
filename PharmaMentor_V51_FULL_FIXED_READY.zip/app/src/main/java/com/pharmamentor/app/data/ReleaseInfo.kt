package com.pharmamentor.app.data

/** Single source of truth for the release label shown by local QA screens. */
object ReleaseInfo {
    const val VERSION_NAME = "52.0"
    const val VERSION_CODE = 52
    const val ROOM_SCHEMA = 19
    const val RELEASE_TITLE = "Comprehensive Drug Library"
}
