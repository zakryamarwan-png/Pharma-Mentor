package com.pharmamentor.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "comprehensive_drug_library")
data class ComprehensiveDrugEntity(
    @PrimaryKey val drugId: String,
    val genericName: String,
    val brandExamples: String,
    val therapeuticGroup: String,
    val drugClass: String,
    val mechanism: String,
    val indications: String,
    val adultDose: String,
    val pediatricDose: String,
    val renalConsiderations: String,
    val hepaticConsiderations: String,
    val adverseEffects: String,
    val contraindications: String,
    val interactions: String,
    val monitoring: String,
    val pregnancy: String,
    val lactation: String,
    val toxicity: String,
    val antidote: String,
    val counseling: String,
    val onLabel: String,
    val offLabel: String,
    val reference: String,
    val lastReviewed: String
)
