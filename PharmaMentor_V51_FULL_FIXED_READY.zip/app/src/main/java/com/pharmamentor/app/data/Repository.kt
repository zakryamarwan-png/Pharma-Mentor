package com.pharmamentor.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PharmaRepository(context: Context) {
    private val db = AppDatabase.get(context)
    private val cards = db.reviewCards(); private val topics = db.topics(); private val drugs = db.drugs()
    private val cases = db.cases(); private val mcqs = db.mcqs(); private val paths = db.learningPaths()
    private val placement = db.placement(); private val smartPlans = db.smartPlans(); private val analytics = db.analytics(); private val achievements = db.achievements(); private val clinical = db.clinicalIntelligence(); private val drugProfiles = db.drugProfiles(); private val offline = db.offlineKnowledge(); private val personalStudy = db.personalStudy(); private val tutor = db.clinicalTutor(); private val graph = db.knowledgeGraph(); private val advancedQuiz = db.advancedQuiz(); private val srs = db.spacedRepetition(); private val mastery = db.mastery(); private val dailyMissions = db.dailyMissions(); private val comprehensiveDrugs = db.comprehensiveDrugs()

    suspend fun seedIfNeeded() = withContext(Dispatchers.IO) {
        if (cards.all().isEmpty()) cards.upsertAll(SeedData.cards(System.currentTimeMillis()))
        if (topics.latest() == null) topics.upsert(DailyTopicEntity("hypertension-2026-09-14", "Hypertension — 2025 guideline update", "Review BP classification, treatment goals, risk-based decisions, home BP monitoring, and special populations. Educational content should be checked against the current guideline before clinical use.", "2025 AHA/ACC High Blood Pressure Guideline", SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())))
        if (drugs.all().isEmpty()) drugs.upsertAll(LibrarySeed.drugs())
        if (cases.all().isEmpty()) cases.upsertAll(LibrarySeed.cases())
        if (mcqs.all().isEmpty()) mcqs.upsertAll(LibrarySeed.mcqs())
        if (paths.all().isEmpty()) paths.upsertAll(LearningSeed.paths())
        if (clinical.interactions().isEmpty()) clinical.upsertInteractions(ClinicalIntelligenceSeed.interactions)
        if (ClinicalIntelligenceSeed.links.isNotEmpty()) clinical.upsertLinks(ClinicalIntelligenceSeed.links)
        if (drugProfiles.all().isEmpty()) drugProfiles.upsertAll(DrugProfileSeed.profiles)
        if (comprehensiveDrugs.all().isEmpty()) comprehensiveDrugs.upsertAll(ComprehensiveDrugSeed.profiles)
        if (offline.all().isEmpty()) offline.upsertAll(OfflineKnowledgeSeed.items)
        if (tutor.caseIds().isEmpty()) tutor.upsertSteps(ClinicalTutorSeed.steps)
        if (graph.nodes().isEmpty()) { graph.upsertNodes(KnowledgeGraphSeed.nodes); graph.upsertEdges(KnowledgeGraphSeed.edges) }
        val todayKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (dailyMissions.forDate(todayKey).isEmpty()) dailyMissions.upsertAll(DailyMissionEngine.build(todayKey, LearningRoadmapEngine.build(mastery.all()), cards.due(System.currentTimeMillis()).size))
    }
    suspend fun dueCards() = withContext(Dispatchers.IO) { cards.due(System.currentTimeMillis()) }
    suspend fun latestTopic() = withContext(Dispatchers.IO) { topics.latest() }
    suspend fun allTopics() = withContext(Dispatchers.IO) { topics.latest()?.let { listOf(it) } ?: emptyList() }
    suspend fun allDrugs() = withContext(Dispatchers.IO) { drugs.all() }
    suspend fun searchDrugs(q:String) = withContext(Dispatchers.IO) { drugs.search(q) }
    suspend fun drugProfile(drugId:String) = withContext(Dispatchers.IO) { drugProfiles.byDrugId(drugId) }
    suspend fun allDrugProfiles() = withContext(Dispatchers.IO) { drugProfiles.all() }
    suspend fun searchDrugProfiles(q:String) = withContext(Dispatchers.IO) { drugProfiles.search(q) }
    suspend fun allComprehensiveDrugs() = withContext(Dispatchers.IO) { comprehensiveDrugs.all() }
    suspend fun comprehensiveDrugGroups() = withContext(Dispatchers.IO) { comprehensiveDrugs.groups() }
    suspend fun comprehensiveDrugsByGroup(group:String) = withContext(Dispatchers.IO) { comprehensiveDrugs.byGroup(group) }
    suspend fun searchComprehensiveDrugs(q:String) = withContext(Dispatchers.IO) { comprehensiveDrugs.search(q) }
    suspend fun comprehensiveDrug(drugId:String) = withContext(Dispatchers.IO) { comprehensiveDrugs.byId(drugId) }
    suspend fun allCases() = withContext(Dispatchers.IO) { cases.all() }
    suspend fun allMcqs() = withContext(Dispatchers.IO) { mcqs.all() }
    suspend fun allInteractions() = withContext(Dispatchers.IO) { clinical.interactions() }
    suspend fun searchInteractions(q:String) = withContext(Dispatchers.IO) { clinical.searchInteractions(q) }
    suspend fun caseLinks(caseId:String) = withContext(Dispatchers.IO) { clinical.linksForCase(caseId) }
    suspend fun allPaths() = withContext(Dispatchers.IO) { paths.all() }
    suspend fun latestPlacement() = withContext(Dispatchers.IO) { placement.all().firstOrNull() }
    suspend fun getSmartPlan(dateKey:String) = withContext(Dispatchers.IO) { smartPlans.forDate(dateKey) }
    suspend fun insertSmartPlan(plan:SmartPlanEntity) = withContext(Dispatchers.IO) { smartPlans.insert(plan) }
    suspend fun completeSmartPlan(id:String) = withContext(Dispatchers.IO) { smartPlans.complete(id) }
    suspend fun logSession(type:String,itemId:String,score:Int=0) = withContext(Dispatchers.IO) { db.progress().insert(StudySessionEntity(type=type,itemId=itemId,completedAt=System.currentTimeMillis(),score=score)) }
    suspend fun savePlacement(x:PlacementResultEntity) = withContext(Dispatchers.IO) { placement.insert(x) }
    suspend fun save(card:ReviewCardEntity) = withContext(Dispatchers.IO) { cards.upsert(card) }
    suspend fun srsState(cardId:String) = withContext(Dispatchers.IO) { srs.byCardId(cardId) }
    suspend fun saveSrsState(state:SpacedRepetitionStateEntity) = withContext(Dispatchers.IO) { srs.upsert(state) }
    suspend fun allSrsStates() = withContext(Dispatchers.IO) { srs.all() }
    suspend fun dueSrsStates() = withContext(Dispatchers.IO) { srs.due(System.currentTimeMillis()) }
    suspend fun logLearningEvent(itemId:String,itemType:String,topic:String,correct:Boolean) = withContext(Dispatchers.IO) {
        analytics.insert(LearningEventEntity(itemId=itemId,itemType=itemType,topic=topic,correct=correct,timestamp=System.currentTimeMillis()))
        val previous = mastery.byTopic(topic)
        mastery.upsert(MasteryEngine.update(topic, previous, correct))
    }
    suspend fun weaknesses() = withContext(Dispatchers.IO) { analytics.weaknessRows() }
    suspend fun totalWrong() = withContext(Dispatchers.IO) { analytics.totalWrong() }
    suspend fun totalAnswered() = withContext(Dispatchers.IO) { analytics.totalAnswered() }
    suspend fun weeklyAnswered() = withContext(Dispatchers.IO) { analytics.answeredSince(System.currentTimeMillis() - 7L*24*60*60*1000) }
    suspend fun weeklyWrong() = withContext(Dispatchers.IO) { analytics.wrongSince(System.currentTimeMillis() - 7L*24*60*60*1000) }
    suspend fun recordAchievement(key:String) = withContext(Dispatchers.IO) {
        if (achievements.unlockedAt(key) == null) achievements.upsert(AchievementProgressEntity(key, System.currentTimeMillis()))
    }
    suspend fun unlockedAchievements() = withContext(Dispatchers.IO) { achievements.all() }
    suspend fun todayChallenge(): DailyChallengeEntity = withContext(Dispatchers.IO) {
        val key = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        achievements.challenge(key) ?: DailyChallengeEntity(key).also { achievements.upsertChallenge(it) }
    }
    suspend fun incrementChallenge(): DailyChallengeEntity = withContext(Dispatchers.IO) {
        val key = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (achievements.challenge(key) == null) achievements.upsertChallenge(DailyChallengeEntity(key))
        achievements.incrementChallenge(key)
        achievements.challenge(key)!!
    }
    suspend fun awardChallengeXpIfNeeded(): Boolean = withContext(Dispatchers.IO) {
        val key = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val c = achievements.challenge(key) ?: return@withContext false
        if (c.completed >= c.target && !c.xpAwarded) { achievements.awardChallengeXp(key); true } else false
    }
    suspend fun streakDays(): Int = withContext(Dispatchers.IO) {
        val rows = db.progress().activeDateKeys()
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        var cursor = java.util.Calendar.getInstance()
        var count = 0
        while (true) {
            val key = fmt.format(cursor.time)
            if (!rows.contains(key)) break
            count++; cursor.add(java.util.Calendar.DAY_OF_YEAR, -1)
        }
        count
    }
    suspend fun xp(): Int = withContext(Dispatchers.IO) {
        val base = db.progress().totalScore() * 10
        val events = analytics.totalAnswered() * 5
        val correct = analytics.totalCorrect() * 5
        base + events + correct
    }

    suspend fun offlineAll() = withContext(Dispatchers.IO) { offline.all() }
    suspend fun offlineByCategory(category:String) = withContext(Dispatchers.IO) { offline.byCategory(category) }
    suspend fun searchOffline(q:String) = withContext(Dispatchers.IO) { offline.search(q) }

    suspend fun studyRecommendations(dateKey:String) = withContext(Dispatchers.IO) { personalStudy.forDate(dateKey) }
    suspend fun saveStudyRecommendations(items:List<StudyRecommendationEntity>) = withContext(Dispatchers.IO) { personalStudy.upsertAll(items) }
    suspend fun completeStudyRecommendation(id:String) = withContext(Dispatchers.IO) { personalStudy.complete(id) }
    suspend fun tutorSteps(caseId:String) = withContext(Dispatchers.IO) { tutor.steps(caseId) }
    suspend fun tutorCases() = withContext(Dispatchers.IO) { tutor.caseIds() }
    suspend fun recordTutorAttempt(caseId:String, stepIndex:Int, selected:String, correct:Boolean) = withContext(Dispatchers.IO) { tutor.recordAttempt(ClinicalTutorAttemptEntity(caseId=caseId, stepIndex=stepIndex, selectedOption=selected, correct=correct, timestamp=System.currentTimeMillis())) }
    suspend fun tutorAttempts(caseId:String) = withContext(Dispatchers.IO) { tutor.attempts(caseId) }
    suspend fun graphNodes() = withContext(Dispatchers.IO) { graph.nodes() }
    suspend fun searchGraph(q:String) = withContext(Dispatchers.IO) { graph.searchNodes(q) }
    suspend fun graphEdges(nodeId:String) = withContext(Dispatchers.IO) { graph.edgesFor(nodeId) }
    suspend fun weeklyWeaknesses() = withContext(Dispatchers.IO) { analytics.recentWeaknessRows(System.currentTimeMillis() - 7L*24*60*60*1000) }
    suspend fun saveQuizAttempt(x:QuizAttemptEntity) = withContext(Dispatchers.IO) { advancedQuiz.insertAttempt(x) }
    suspend fun saveQuizSession(x:QuizSessionEntity) = withContext(Dispatchers.IO) { advancedQuiz.insertSession(x) }
    suspend fun updateQuizSession(x:QuizSessionEntity) = withContext(Dispatchers.IO) { advancedQuiz.updateSession(x) }
    suspend fun recentQuizAttempts(limit:Int=50) = withContext(Dispatchers.IO) { advancedQuiz.recentAttempts(limit) }
    suspend fun recentQuizSessions(limit:Int=20) = withContext(Dispatchers.IO) { advancedQuiz.recentSessions(limit) }
    suspend fun quizAccuracyAtDifficulty(level:Int) = withContext(Dispatchers.IO) {
        val total=advancedQuiz.totalAtDifficulty(level); val correct=advancedQuiz.correctAtDifficulty(level);
        if(total==0) 0 else correct*100/total
    }

    suspend fun topicMastery() = withContext(Dispatchers.IO) { mastery.all() }
    suspend fun masteryForTopic(topic:String) = withContext(Dispatchers.IO) { mastery.byTopic(topic) }
    suspend fun todayMissions(): List<DailyMissionEntity> = withContext(Dispatchers.IO) {
        val key = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val existing = dailyMissions.forDate(key)
        if (existing.isNotEmpty()) existing else DailyMissionEngine.build(key, LearningRoadmapEngine.build(mastery.all()), cards.due(System.currentTimeMillis()).size).also { dailyMissions.upsertAll(it) }
    }
    suspend fun completeMission(id:String) = withContext(Dispatchers.IO) { dailyMissions.increment(id) }

    suspend fun systemAudit(): SystemAudit = withContext(Dispatchers.IO) {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        SystemAudit(
            reviewCards = cards.all().size,
            dueCards = cards.due(System.currentTimeMillis()).size,
            drugs = drugs.all().size,
            drugProfiles = drugProfiles.all().size,
            cases = cases.all().size,
            mcqs = mcqs.all().size,
            interactions = clinical.interactions().size,
            tutorCases = tutor.caseIds().size,
            graphNodes = graph.nodes().size,
            graphEdges = graph.nodes().let { graph.edgesFor(it.firstOrNull()?.id ?: "__none__").size } + graph.nodes().drop(1).sumOf { graph.edgesFor(it.id).size },
            offlineArticles = offline.all().size,
            srsStates = srs.all().size,
            learningEvents = analytics.totalAnswered(),
            recommendations = personalStudy.forDate(today).size
        )
    }

    suspend fun progressIntelligence(): ProgressIntelligence = withContext(Dispatchers.IO) {
        val total = analytics.totalAnswered()
        val correct = analytics.totalCorrect()
        val weekTotal = analytics.answeredSince(System.currentTimeMillis() - 7L*24*60*60*1000)
        val weekWrong = analytics.wrongSince(System.currentTimeMillis() - 7L*24*60*60*1000)
        val rows = analytics.weaknessRows().take(8).map { row ->
            val error = if (row.total == 0) 0 else row.wrong * 100 / row.total
            val priority = when { error >= 60 && row.total >= 3 -> "HIGH"; error >= 35 -> "MEDIUM"; else -> "LOW" }
            WeaknessInsight(row.topic, row.total, row.wrong, error, priority)
        }
        ProgressIntelligence(total, correct, if(total==0) 0 else correct*100/total, weekTotal, weekWrong, if(weekTotal==0) 0 else (weekTotal-weekWrong)*100/weekTotal, streakDays(), xp(), dueCards().size, rows)
    }

}
