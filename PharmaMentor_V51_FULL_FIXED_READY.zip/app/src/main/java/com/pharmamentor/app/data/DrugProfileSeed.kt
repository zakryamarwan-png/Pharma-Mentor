package com.pharmamentor.app.data

object DrugProfileSeed {
    private const val REF = "Educational prototype — verify current official labeling before clinical use."
    /** One DrugProfile per comprehensive-library drug.
     *  The profile is keyed by the exact drugId so the Room relation is deterministic.
     *  Clinical text remains conservative where an exact formulation/indication changes the dose.
     */
    val profiles: List<DrugProfileEntity> by lazy {
        ComprehensiveDrugSeed.profiles.map { d ->
            val ref = "Primary: current official product labeling (FDA/DailyMed or national regulator) where available; secondary: WHO Model List/EML and current evidence-based guidelines. Verify local guidance before clinical use."
            DrugProfileEntity(
                drugId = d.drugId,
                genericName = d.genericName,
                brandExamples = d.brandExamples,
                dosageForms = "Verify current product formulation(s) and strength(s) for this active ingredient.",
                route = "Route is formulation-specific; verify the current official label.",
                adultDose = d.adultDose,
                pediatricDose = d.pediatricDose,
                renalConsiderations = d.renalConsiderations,
                hepaticConsiderations = d.hepaticConsiderations,
                monitoring = d.monitoring,
                pregnancy = d.pregnancy,
                lactation = d.lactation,
                onLabel = d.onLabel,
                offLabel = d.offLabel,
                counseling = d.counseling,
                blackBoxWarning = "Check the current official label for this specific product and indication; boxed-warning status can differ by formulation and jurisdiction.",
                reference = ref,
                lastReviewed = "2026-10"
            )
        }.distinctBy { it.drugId }
    }
}
