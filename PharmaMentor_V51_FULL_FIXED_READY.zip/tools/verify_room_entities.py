#!/usr/bin/env python3
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'app/src/main/java/com/pharmamentor/app/data'
DB = DATA / 'AppDatabase.kt'
MIG = DATA / 'DatabaseMigrations.kt'
errors = []

if not DB.exists(): errors.append('AppDatabase.kt missing')
if not MIG.exists(): errors.append('DatabaseMigrations.kt missing')

if DB.exists():
    db = DB.read_text(encoding='utf-8')
    if not re.search(r'\bversion\s*=\s*19\b', db): errors.append('Room database version is not 19')
    if 'ComprehensiveDrugEntity::class' not in db: errors.append('ComprehensiveDrugEntity is not registered in AppDatabase')
    if 'MIGRATION_18_19' not in db: errors.append('MIGRATION_18_19 is not registered in AppDatabase')
else:
    db = ''

if MIG.exists():
    mig = MIG.read_text(encoding='utf-8')
    if 'CREATE TABLE IF NOT EXISTS comprehensive_drug_library' not in mig:
        errors.append('18->19 migration does not create comprehensive_drug_library')

entities = []
for path in sorted(DATA.glob('*.kt')):
    text = path.read_text(encoding='utf-8')
    # Capture each @Entity annotation and the class immediately following it.
    for m in re.finditer(r'@Entity\s*(?:\([^)]*\))?\s*(?:public\s+|internal\s+)?(?:data\s+)?class\s+(\w+)\s*([\s\S]*?)(?=\n@Entity|\Z)', text):
        name = m.group(1)
        block = m.group(0)
        entities.append((name, path, block))

if not entities:
    errors.append('No Room @Entity declarations found')

for name, path, block in entities:
    if not re.search(r'@(?:androidx\.room\.)?PrimaryKey\b', block) and not re.search(r'primaryKeys\s*=\s*\[', block):
        errors.append(f'{name} in {path.name} has no @PrimaryKey or composite primaryKeys')
    if f'{name}::class' not in db:
        errors.append(f'{name} is not registered in AppDatabase')

# Explicitly verify the new comprehensive entity schema.
comp = DATA / 'ComprehensiveDrugEntities.kt'
if comp.exists():
    c = comp.read_text(encoding='utf-8')
    required = ['drugId','genericName','brandExamples','therapeuticGroup','drugClass','mechanism','indications','adultDose','pediatricDose','renalConsiderations','hepaticConsiderations','adverseEffects','contraindications','interactions','monitoring','pregnancy','lactation','toxicity','antidote','counseling','onLabel','offLabel','reference','lastReviewed']
    for field in required:
        if not re.search(rf'\b{re.escape(field)}\s*:', c):
            errors.append(f'ComprehensiveDrugEntity missing field: {field}')
else:
    errors.append('ComprehensiveDrugEntities.kt missing')

print(f'ROOM ENTITY COUNT: {len(entities)}')
if errors:
    for e in errors:
        print(f'FAIL: {e}')
    print('VERIFY ROOM ENTITIES: FAIL')
    sys.exit(1)
print('VERIFY ROOM ENTITIES: PASS')
