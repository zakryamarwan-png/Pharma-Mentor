#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
fail=0
for f in settings.gradle.kts build.gradle.kts gradle.properties app/build.gradle.kts app/src/main/AndroidManifest.xml; do
  [[ -f "$ROOT/$f" ]] || { echo "MISSING: $f"; fail=1; }
done
grep -q 'versionCode = 52' "$ROOT/app/build.gradle.kts" || { echo "BAD VERSION CODE"; fail=1; }
grep -q 'versionName = "52.0"' "$ROOT/app/build.gradle.kts" || { echo "BAD VERSION NAME"; fail=1; }
grep -q 'android:name=".MainActivity"' "$ROOT/app/src/main/AndroidManifest.xml" || { echo "MAIN ACTIVITY MISSING"; fail=1; }
grep -q 'android.permission.POST_NOTIFICATIONS' "$ROOT/app/src/main/AndroidManifest.xml" || { echo "NOTIFICATION PERMISSION MISSING"; fail=1; }
[[ -x "$ROOT/tools/bootstrap_gradle.sh" ]] || { echo "GRADLE BOOTSTRAP MISSING"; fail=1; }
[[ -x "$ROOT/tools/build_apk.sh" ]] || { echo "BUILD SCRIPT MISSING"; fail=1; }
[[ -x "$ROOT/tools/verify_room_entities.sh" ]] || { echo "ROOM VERIFY SCRIPT MISSING"; fail=1; }
if [[ -x "$ROOT/tools/verify_room_entities.sh" ]]; then bash "$ROOT/tools/verify_room_entities.sh" || fail=1; fi
if [[ $fail -eq 0 ]]; then echo "PREFLIGHT: PASS"; else echo "PREFLIGHT: FAIL"; fi
exit $fail
