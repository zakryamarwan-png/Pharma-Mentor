#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
GRADLE_VERSION="8.10.2"
CACHE_DIR="$ROOT/.build-tools"
DIST="$CACHE_DIR/gradle-${GRADLE_VERSION}-bin.zip"
HOME_DIR="$CACHE_DIR/gradle-${GRADLE_VERSION}"
URL="https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip"
mkdir -p "$CACHE_DIR"
# GitHub Actions setup-gradle provides Gradle on PATH. Prefer it in CI to avoid
# depending on a private bootstrap download.
if command -v gradle >/dev/null 2>&1; then
  exec "$(command -v gradle)" "$@"
fi
if [[ ! -x "$HOME_DIR/bin/gradle" ]]; then
  echo "BOOTSTRAP FAILED: Gradle is not available on PATH and no cached Gradle distribution is present."
  echo "GitHub Actions should run actions/setup-gradle before invoking ./gradlew."
  exit 2
fi
exec "$HOME_DIR/bin/gradle" "$@"
