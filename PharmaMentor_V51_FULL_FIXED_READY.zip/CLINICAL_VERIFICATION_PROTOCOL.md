# Pharma Mentor — Clinical Verification Protocol

This release contains 632 unique drug records. It must distinguish drug-specific evidence from class-level educational guidance.

## Verification hierarchy
1. Current official prescribing information / regulator labeling (FDA/DailyMed or applicable national regulator). FDA states that approved prescribing information reflects the Agency finding on safety and effectiveness under labeled conditions.
2. WHO Model List of Essential Medicines 2025 / EMLc 2025 when relevant.
3. Current specialty guidelines and high-quality evidence for indication-specific recommendations.

## Required drug-level fields
Mechanism; approved indications; adult dose by indication/formulation; pediatric dose; renal adjustment; hepatic adjustment; adverse effects; contraindications; interactions; monitoring; pregnancy; lactation; toxicity/overdose; antidote; counseling; on-label/off-label status; primary references; review date.

## Safety rule
No class-level text is to be presented as a verified drug-specific dose or contraindication. When a field has not been individually checked against a current source, the app must label it as requiring verification.

## Current release status
The source project has 632 records and a complete profile schema, but this build does NOT claim external source verification for every field of every drug. A clinically responsible release cannot manufacture missing label data.
