# Pharma Mentor — Comprehensive Drug Library

- Unified catalog entries: 588
- Unique drug IDs: 588
- Source: existing LibrarySeed + DrugProfileSeed + ComprehensiveDrugSeed, with expanded catalog entries.
- ComprehensiveDrugSeed is the unified catalog source for the comprehensive library.
- Educational reference only. Drug availability, labeling, indications, doses, contraindications and local guidance vary by jurisdiction and formulation.
- This is a large clinical-education catalog, not a literal list of every medicinal product worldwide; the catalog is designed to be expandable.
