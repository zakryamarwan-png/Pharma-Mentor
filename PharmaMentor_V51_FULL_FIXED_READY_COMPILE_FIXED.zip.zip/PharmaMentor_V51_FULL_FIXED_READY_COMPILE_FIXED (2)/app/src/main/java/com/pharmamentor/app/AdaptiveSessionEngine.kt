package com.pharmamentor.app.data

/**
 * Rating used by the spaced-repetition and adaptive study engines.
 */
enum class Rating {
    AGAIN,
    HARD,
    GOOD,
    EASY
}

/**
 * Small deterministic controller used by the adaptive study session.
 * It intentionally contains no database/network calls, so every method is synchronous.
 */
object AdaptiveSessionEngine {

    data class Decision(
        val action: String,
        val reason: String = ""
    )

    fun afterReview(rating: Rating, category: String): Decision {
        return when (rating) {
            Rating.AGAIN -> Decision("QUIZ", "المراجعة لم تثبت التذكر؛ أضف سؤالًا تطبيقيًا للموضوع.")
            Rating.HARD -> Decision("QUIZ", "التذكر كان صعبًا؛ أضف سؤالًا تطبيقيًا قصيرًا.")
            Rating.GOOD -> Decision("CONTINUE", "التذكر جيد؛ انتقل للمرحلة التالية.")
            Rating.EASY -> Decision("CONTINUE", "التذكر سهل؛ انتقل للمرحلة التالية.")
        }
    }

    fun afterQuiz(correct: Boolean, topic: String): Decision {
        return if (correct) {
            Decision("CONTINUE", "إجابة صحيحة؛ تابع الجلسة.")
        } else {
            Decision("REVIEW", "إجابة خاطئة؛ أضف مراجعة قصيرة للموضوع.")
        }
    }

    fun <T> insertPriorityStage(
        stages: MutableList<T>,
        currentIndex: Int,
        stage: T
    ) {
        val insertAt = (currentIndex + 1).coerceIn(0, stages.size)
        stages.add(insertAt, stage)
    }
}
