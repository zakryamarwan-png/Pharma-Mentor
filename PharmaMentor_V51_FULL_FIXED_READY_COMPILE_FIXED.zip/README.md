# Pharma Mentor V48

Pharma Mentor is an offline-first pharmacy learning assistant with adaptive review, clinical cases, drug profiles, interactions, knowledge graph, mastery tracking, personalized roadmap, daily missions, reminders, and release QA tooling.

## V48 — Reproducible Build Preparation
- Version 47.0 / versionCode 47
- Room schema 17
- Added deterministic Gradle bootstrap (8.10.2)
- Unified APK build script for local/CI environments
- Preflight checks for core Android project files, launcher, notifications, and build tooling
- GitHub Actions debug APK artifact workflow

## Build

Run `bash tools/project_preflight.sh`, then `bash tools/build_apk.sh` from the project root. A full Android SDK is required for the APK build.

## Important

No APK is claimed as built unless a real Gradle/Android build produces the artifact. Release signing must use a user-controlled keystore and secrets.
