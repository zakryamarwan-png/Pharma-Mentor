#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [[ -x ./gradlew ]]; then
  ./gradlew :app:assembleDebug
  exit $?
fi
if command -v gradle >/dev/null 2>&1; then
  gradle :app:assembleDebug
  exit $?
fi
if command -v curl >/dev/null 2>&1 && command -v unzip >/dev/null 2>&1; then
  ./tools/bootstrap_gradle.sh :app:assembleDebug
  exit $?
fi
echo "BUILD BLOCKED: Gradle, curl, or unzip is unavailable."
exit 127
