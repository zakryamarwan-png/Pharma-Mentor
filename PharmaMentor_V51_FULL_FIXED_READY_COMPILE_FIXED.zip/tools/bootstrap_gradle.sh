#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
GRADLE_VERSION="8.10.2"
CACHE_DIR="$ROOT/.build-tools"
DIST="$CACHE_DIR/gradle-${GRADLE_VERSION}-bin.zip"
HOME_DIR="$CACHE_DIR/gradle-${GRADLE_VERSION}"
URL="https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip"
mkdir -p "$CACHE_DIR"
if [[ ! -x "$HOME_DIR/bin/gradle" ]]; then
  command -v curl >/dev/null 2>&1 || { echo "BOOTSTRAP FAILED: curl is required."; exit 2; }
  command -v unzip >/dev/null 2>&1 || { echo "BOOTSTRAP FAILED: unzip is required."; exit 2; }
  echo "Downloading Gradle ${GRADLE_VERSION}..."
  curl -fL --retry 3 --retry-delay 2 "$URL" -o "$DIST"
  rm -rf "$HOME_DIR"
  unzip -q "$DIST" -d "$CACHE_DIR"
fi
exec "$HOME_DIR/bin/gradle" "$@"
