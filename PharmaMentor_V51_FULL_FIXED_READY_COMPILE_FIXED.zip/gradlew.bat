@echo off
set ROOT=%~dp0
bash "%ROOT%tools\bootstrap_gradle.sh" %*
if errorlevel 1 exit /b %errorlevel%
