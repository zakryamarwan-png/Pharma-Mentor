# Pharma Mentor V50 — Release Signing

V50 connects the release build to the user-owned Pharma Mentor keystore without storing passwords in source control.

Environment variables:
- `PHARMA_KEYSTORE`
- `PHARMA_KEY_ALIAS`
- `PHARMA_STORE_PASSWORD`
- `PHARMA_KEY_PASSWORD`

Example:
```bash
export PHARMA_KEYSTORE=/path/to/PharmaMentor-release.jks
export PHARMA_KEY_ALIAS=pharma_mentor_release
export PHARMA_STORE_PASSWORD='***'
export PHARMA_KEY_PASSWORD='***'
./gradlew :app:assembleRelease
```

Do not commit the keystore or passwords to Git.
