# Pharma Mentor V48 — Build Guide

V48 is the build-readiness handoff version. It includes a `gradlew` launcher that bootstraps Gradle 8.10.2 when a system Gradle installation is unavailable.

## Local Android build

1. Install Android Studio with Android SDK Platform 35 and Build Tools 35.0.0.
2. Ensure Java 17 is available.
3. Open this project in Android Studio and allow Gradle sync.
4. Run `./gradlew :app:assembleDebug` (Windows: use `gradlew.bat`).
5. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## CI build

The included GitHub Actions workflow installs Android SDK 35 and runs the same build script, then uploads the debug APK as an artifact.

## Important

This repository does not contain a release keystore. Release signing must be configured with the owner's private keystore/secrets.
