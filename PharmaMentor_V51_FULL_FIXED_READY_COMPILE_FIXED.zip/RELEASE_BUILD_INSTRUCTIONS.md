# Pharma Mentor V51 — Release Build

1. Open this project in Android Studio.
2. Install Android SDK Platform 35 and matching Build Tools.
3. Configure signing secrets without committing them.
4. Set:
   - PHARMA_KEYSTORE
   - PHARMA_KEY_ALIAS
   - PHARMA_STORE_PASSWORD
   - PHARMA_KEY_PASSWORD
5. Run `./gradlew clean assembleRelease`.
6. Expected output: `app/build/outputs/apk/release/app-release.apk`.
7. Verify the APK signature with Android Studio's APK Analyzer or `apksigner verify --verbose`.
