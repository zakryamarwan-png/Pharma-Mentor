package com.pharmamentor.app.data
object LearningSeed {
 fun paths()=listOf(
  LearningPathEntity("pharmacology","Pharmacology","Core mechanisms, receptors and drug classes",1),
  LearningPathEntity("cardio","Cardiovascular","Hypertension, heart failure and antiarrhythmics",2),
  LearningPathEntity("endocrine","Endocrine","Diabetes, thyroid and adrenal pharmacotherapy",3),
  LearningPathEntity("antibiotics","Antibiotics","Antibacterial classes, spectrum and stewardship",4),
  LearningPathEntity("cns","CNS","Seizures, mood, psychosis and neurologic drugs",5)
 )
}
