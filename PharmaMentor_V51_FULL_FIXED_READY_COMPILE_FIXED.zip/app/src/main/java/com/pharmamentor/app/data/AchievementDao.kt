package com.pharmamentor.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface AchievementDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(x: AchievementProgressEntity)

    @Query("SELECT * FROM achievement_progress")
    suspend fun all(): List<AchievementProgressEntity>

    @Query("SELECT unlockedAt FROM achievement_progress WHERE `key`=:key LIMIT 1")
    suspend fun unlockedAt(key: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertChallenge(x: DailyChallengeEntity)

    @Query("SELECT * FROM daily_challenges WHERE dateKey=:dateKey LIMIT 1")
    suspend fun challenge(dateKey: String): DailyChallengeEntity?

    @Query("UPDATE daily_challenges SET completed = completed + 1 WHERE dateKey=:dateKey AND completed < target")
    suspend fun incrementChallenge(dateKey: String): Int

    @Query("UPDATE daily_challenges SET xpAwarded=1 WHERE dateKey=:dateKey")
    suspend fun awardChallengeXp(dateKey: String)
}
