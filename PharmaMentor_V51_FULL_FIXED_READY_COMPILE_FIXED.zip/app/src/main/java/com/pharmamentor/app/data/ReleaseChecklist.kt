package com.pharmamentor.app.data

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

/** Local release preflight. It checks wiring/configuration, not clinical correctness or APK signing. */
data class ReleaseCheck(val name: String, val ok: Boolean, val detail: String)

data class ReleasePreflight(val checks: List<ReleaseCheck>) {
    val passed: Int get() = checks.count { it.ok }
    val total: Int get() = checks.size
    val allPassed: Boolean get() = checks.all { it.ok }
}

object ReleaseChecklist {
    fun run(context: Context, audit: SystemAudit, missionCount: Int): ReleasePreflight {
        val pm = context.packageManager
        val pkg = context.packageName
        val appInfo = runCatching { pm.getApplicationInfo(pkg, 0) }.getOrNull()
        val mainActivity = runCatching { pm.getActivityInfo(android.content.ComponentName(context, com.pharmamentor.app.MainActivity::class.java), 0) }.getOrNull()
        val bootReceiver = runCatching { pm.getReceiverInfo(android.content.ComponentName(context, com.pharmamentor.app.BootReceiver::class.java), 0) }.getOrNull()
        val notificationReady = Build.VERSION.SDK_INT < 33 || context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED

        return ReleasePreflight(listOf(
            ReleaseCheck("Application manifest", appInfo != null, "Pharma Mentor application is discoverable"),
            ReleaseCheck("Launcher activity", mainActivity?.exported == true, "MainActivity is exported as the launcher"),
            ReleaseCheck("Boot reminder receiver", bootReceiver != null, "Boot receiver is registered"),
            ReleaseCheck("Notification permission", notificationReady, if (Build.VERSION.SDK_INT >= 33) "Permission granted on this device" else "Not required below Android 13"),
            ReleaseCheck("Content seed", audit.drugs > 0 && audit.mcqs > 0 && audit.cases > 0, "Drug/MCQ/case content present"),
            ReleaseCheck("Clinical modules", audit.interactions > 0 && audit.tutorCases > 0, "Interactions and tutor cases present"),
            ReleaseCheck("Learning engine", audit.reviewCards > 0 && audit.srsStates >= 0, "Review cards and SRS storage present"),
            ReleaseCheck("Analytics + mastery", audit.learningEvents >= 0, "Learning event storage connected"),
            ReleaseCheck("Knowledge graph", audit.graphNodes > 0 && audit.graphEdges > 0, "Nodes and edges present"),
            ReleaseCheck("Offline knowledge", audit.offlineArticles > 0, "Offline articles present"),
            ReleaseCheck("Daily missions", missionCount > 0, "Today missions initialized"),
            ReleaseCheck("APK build/signing", false, "Requires Android SDK/Gradle build and signing outside this runtime")
        ))
    }
}
