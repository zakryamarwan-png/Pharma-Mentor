package com.pharmamentor.app.data

/** V39 explainable roadmap: converts mastery data into a prioritized next-step path. */
data class RoadmapItem(
    val topic: String,
    val mastery: Int,
    val status: String,
    val action: String,
    val reason: String,
    val rank: Int
)

object LearningRoadmapEngine {
    fun build(items: List<TopicMasteryEntity>): List<RoadmapItem> {
        return items.sortedWith(compareBy<TopicMasteryEntity> {
            when {
                it.masteryPercent < 50 -> 0
                it.masteryPercent < 70 -> 1
                it.masteryPercent < 85 -> 2
                else -> 3
            }
        }.thenByDescending { it.attempts })
            .mapIndexed { index, m ->
                val action = MasteryEngine.nextAction(m.masteryPercent)
                val reason = when {
                    m.masteryPercent < 50 -> "أولوية عالية: الأساسيات تحتاج تثبيتًا."
                    m.masteryPercent < 70 -> "أنت في مرحلة البناء؛ المراجعة ثم التطبيق أفضل خطوة."
                    m.masteryPercent < 85 -> "اقتربت من الإتقان؛ التدريب المنتظم سيرفع الثبات."
                    else -> "مستوى قوي؛ انتقل إلى أسئلة وتطبيقات أصعب."
                }
                RoadmapItem(m.topic, m.masteryPercent, MasteryEngine.status(m.masteryPercent), action, reason, index + 1)
            }
    }
}
