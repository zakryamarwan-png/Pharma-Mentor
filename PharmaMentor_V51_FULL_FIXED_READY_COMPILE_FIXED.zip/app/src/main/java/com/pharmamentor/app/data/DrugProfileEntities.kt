package com.pharmamentor.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "drug_profiles")
data class DrugProfileEntity(
    @PrimaryKey val drugId: String,
    val genericName: String,
    val brandExamples: String,
    val dosageForms: String,
    val route: String,
    val adultDose: String,
    val pediatricDose: String,
    val renalConsiderations: String,
    val hepaticConsiderations: String,
    val monitoring: String,
    val pregnancy: String,
    val lactation: String,
    val onLabel: String,
    val offLabel: String,
    val counseling: String,
    val blackBoxWarning: String,
    val reference: String,
    val lastReviewed: String
)
