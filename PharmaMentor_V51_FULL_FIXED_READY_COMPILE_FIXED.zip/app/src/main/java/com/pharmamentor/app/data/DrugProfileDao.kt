package com.pharmamentor.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface DrugProfileDao {
    @Query("SELECT * FROM drug_profiles WHERE drugId = :drugId LIMIT 1")
    suspend fun byDrugId(drugId: String): DrugProfileEntity?
    @Query("SELECT * FROM drug_profiles ORDER BY genericName")
    suspend fun all(): List<DrugProfileEntity>
    @Query("SELECT * FROM drug_profiles WHERE genericName LIKE '%' || :term || '%' OR brandExamples LIKE '%' || :term || '%' ORDER BY genericName")
    suspend fun search(term: String): List<DrugProfileEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<DrugProfileEntity>)
}
