package com.pharmamentor.app
import android.app.*;import android.content.*;import java.util.*
object ReminderScheduler{
 private fun set(c:Context,h:Int,m:Int,id:Int,title:String,text:String){
  val am=c.getSystemService(AlarmManager::class.java);val cal=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,h);set(Calendar.MINUTE,m);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);if(timeInMillis<=System.currentTimeMillis())add(Calendar.DAY_OF_YEAR,1)}
  val pi=PendingIntent.getBroadcast(c,id,Intent(c,ReminderReceiver::class.java).apply{putExtra("title",title);putExtra("text",text)},PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  am.setRepeating(AlarmManager.RTC_WAKEUP,cal.timeInMillis,AlarmManager.INTERVAL_DAY,pi)
 }
 fun scheduleAll(c:Context){set(c,8,0,801,"موضوع اليوم","موضوعك الصيدلاني اليوم جاهز 📚");set(c,19,0,802,"المراجعة الذكية","لديك بطاقات حان موعد مراجعتها 🧠")}
}
