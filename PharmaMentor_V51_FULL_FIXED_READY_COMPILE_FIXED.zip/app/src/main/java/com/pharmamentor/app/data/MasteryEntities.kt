package com.pharmamentor.app.data

import androidx.room.Entity

@Entity(tableName = "topic_mastery", primaryKeys = ["topic"])
data class TopicMasteryEntity(
    val topic: String,
    val masteryPercent: Int,
    val confidencePercent: Int,
    val attempts: Int,
    val correct: Int,
    val streak: Int,
    val lastUpdatedAt: Long
)
