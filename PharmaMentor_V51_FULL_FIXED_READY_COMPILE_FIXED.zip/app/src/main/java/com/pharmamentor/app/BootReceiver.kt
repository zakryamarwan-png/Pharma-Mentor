package com.pharmamentor.app
import android.content.*
class BootReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){if(i.action==Intent.ACTION_BOOT_COMPLETED)ReminderScheduler.scheduleAll(c)}}
