package com.pharmamentor.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface KnowledgeGraphDao {
    @Query("SELECT * FROM knowledge_graph_nodes ORDER BY type, label") suspend fun nodes(): List<KnowledgeGraphNodeEntity>
    @Query("SELECT * FROM knowledge_graph_nodes WHERE label LIKE '%' || :term || '%' OR description LIKE '%' || :term || '%' ORDER BY label") suspend fun searchNodes(term: String): List<KnowledgeGraphNodeEntity>
    @Query("SELECT * FROM knowledge_graph_edges WHERE fromId = :nodeId OR toId = :nodeId") suspend fun edgesFor(nodeId: String): List<KnowledgeGraphEdgeEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertNodes(items: List<KnowledgeGraphNodeEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertEdges(items: List<KnowledgeGraphEdgeEntity>)
}
