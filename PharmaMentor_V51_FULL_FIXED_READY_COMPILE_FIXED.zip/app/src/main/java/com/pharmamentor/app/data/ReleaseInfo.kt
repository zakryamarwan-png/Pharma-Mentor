package com.pharmamentor.app.data

/** Single source of truth for the release label shown by local QA screens. */
object ReleaseInfo {
    const val VERSION_NAME = "44.0"
    const val VERSION_CODE = 44
    const val ROOM_SCHEMA = 17
    const val RELEASE_TITLE = "APK Build Preparation"
}
