package com.pharmamentor.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "srs_states")
data class SpacedRepetitionStateEntity(
    @PrimaryKey val cardId: String,
    val stability: Double = 1.0,
    val difficulty: Double = 5.0,
    val repetitions: Int = 0,
    val lapses: Int = 0,
    val lastRating: String = "NEW",
    val lastReviewedAt: Long? = null,
    val dueAt: Long = System.currentTimeMillis()
)
