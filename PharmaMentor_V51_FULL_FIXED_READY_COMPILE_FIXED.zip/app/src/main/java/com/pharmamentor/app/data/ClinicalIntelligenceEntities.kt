package com.pharmamentor.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "drug_interactions")
data class DrugInteractionEntity(
    @PrimaryKey val id: String,
    val drugA: String,
    val drugB: String,
    val severity: String,
    val mechanism: String,
    val management: String,
    val reference: String
)

@Entity(tableName = "clinical_links")
data class ClinicalLinkEntity(
    @PrimaryKey val id: String,
    val caseId: String,
    val drugId: String,
    val rationale: String
)
