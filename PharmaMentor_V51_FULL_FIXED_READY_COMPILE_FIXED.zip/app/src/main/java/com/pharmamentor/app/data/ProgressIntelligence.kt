package com.pharmamentor.app.data

/** Derived learning intelligence; calculated locally from persisted learning telemetry. */
data class ProgressIntelligence(
    val totalAnswered: Int,
    val totalCorrect: Int,
    val accuracyPercent: Int,
    val weeklyAnswered: Int,
    val weeklyWrong: Int,
    val weeklyAccuracyPercent: Int,
    val currentStreak: Int,
    val xp: Int,
    val dueCards: Int,
    val weakTopics: List<WeaknessInsight>
)

data class WeaknessInsight(
    val topic: String,
    val total: Int,
    val wrong: Int,
    val errorPercent: Int,
    val priority: String
)
