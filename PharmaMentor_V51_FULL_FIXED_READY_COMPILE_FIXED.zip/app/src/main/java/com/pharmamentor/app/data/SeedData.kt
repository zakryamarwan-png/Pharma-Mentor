package com.pharmamentor.app.data

object SeedData {
    fun cards(now: Long) = listOf(
        ReviewCardEntity("beta1", "Which receptor mainly mediates cardiac rate and contractility?", "β1", "Beta receptors", "Standard pharmacology references", now),
        ReviewCardEntity("labetalol", "What is labetalol's receptor profile?", "α1 antagonist + β1/β2 antagonist", "Adrenergic blockers", "DailyMed/FDA labeling", now),
        ReviewCardEntity("ccb", "Dihydropyridine calcium-channel blockers mainly relax which tissue?", "Vascular smooth muscle", "Cardiovascular pharmacology", "Standard pharmacology references", now),
        ReviewCardEntity("beta2-k", "What is the typical acute effect of β2 stimulation on serum potassium?", "Shift of potassium into cells → lower serum K+", "Beta agonists", "Standard pharmacology references", now),
        ReviewCardEntity("ace-cough", "Why can ACE inhibitors cause cough?", "Increased bradykinin and related mediators can contribute to cough.", "RAAS", "ACE-inhibitor labeling; pharmacology references", now),
        ReviewCardEntity("loop-site", "Where do loop diuretics inhibit NKCC2?", "Thick ascending limb of the loop of Henle", "Diuretics", "Standard pharmacology references", now),
        ReviewCardEntity("spirono", "What endocrine adverse effect is classically associated with spironolactone?", "Gynecomastia and other antiandrogenic effects", "Diuretics", "DailyMed/FDA labeling", now),
        ReviewCardEntity("warfarin", "Which vitamin-K-dependent factors are reduced by warfarin?", "II, VII, IX and X", "Anticoagulants", "DailyMed/FDA labeling", now)
    )
}
