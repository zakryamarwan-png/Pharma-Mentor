package com.pharmamentor.app

import java.util.Calendar

enum class Rating { AGAIN, HARD, GOOD, EASY }

data class ReviewCard(
    val id:String, val question:String, val answer:String,
    var dueAt:Long=System.currentTimeMillis(), var intervalDays:Int=0,
    var ease:Double=2.5, var reps:Int=0, var lapses:Int=0
)

object ReviewEngine {
    fun review(card:ReviewCard, rating:Rating):ReviewCard {
        val now=System.currentTimeMillis()
        when(rating){
            Rating.AGAIN -> { card.intervalDays=0; card.ease=maxOf(1.3,card.ease-0.2); card.lapses++; card.dueAt=now+10*60*1000 }
            Rating.HARD -> { card.intervalDays=if(card.intervalDays==0) 1 else maxOf(1,(card.intervalDays*1.2).toInt()); card.ease=maxOf(1.3,card.ease-0.15); card.dueAt=plusDays(now,card.intervalDays) }
            Rating.GOOD -> { card.intervalDays=when(card.intervalDays){0->1;1->3;else->maxOf(card.intervalDays+1,(card.intervalDays*card.ease).toInt())}; card.reps++; card.dueAt=plusDays(now,card.intervalDays) }
            Rating.EASY -> { card.intervalDays=when(card.intervalDays){0->4;else->maxOf(card.intervalDays+2,(card.intervalDays*(card.ease+0.25)).toInt())}; card.ease+=0.15; card.reps++; card.dueAt=plusDays(now,card.intervalDays) }
        }
        return card
    }
    private fun plusDays(t:Long,d:Int):Long=Calendar.getInstance().apply{timeInMillis=t;add(Calendar.DAY_OF_YEAR,d)}.timeInMillis
}
