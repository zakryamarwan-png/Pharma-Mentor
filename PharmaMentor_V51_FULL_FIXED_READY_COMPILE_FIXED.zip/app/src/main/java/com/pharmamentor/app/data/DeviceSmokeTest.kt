package com.pharmamentor.app.data

/** Device-side checklist. It reports what still requires a real emulator/device run. */
data class SmokeCheck(val name: String, val status: String, val detail: String)

object DeviceSmokeTest {
    fun checklist(): List<SmokeCheck> = listOf(
        SmokeCheck("Cold start", "PENDING", "Open the app after a force-stop and verify Home loads."),
        SmokeCheck("Notification permission", "PENDING", "On Android 13+, grant notification permission and verify reminders can post."),
        SmokeCheck("Reminder scheduling", "PENDING", "Schedule a reminder and verify it fires at the selected time."),
        SmokeCheck("Boot persistence", "PENDING", "Reboot the device and verify reminder scheduling is restored."),
        SmokeCheck("Room migration", "PENDING", "Install over the previous release and verify existing data survives migration."),
        SmokeCheck("Study flow", "PENDING", "Home → Review → Quiz → Case → Analytics should complete without crashes."),
        SmokeCheck("Offline mode", "PENDING", "Disable network and verify core learning content remains usable."),
        SmokeCheck("Release signing", "EXTERNAL", "Requires Android SDK/Gradle and a signing key outside this runtime.")
    )
}
