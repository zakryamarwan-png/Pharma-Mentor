package com.pharmamentor.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface SmartPlanDao {
    @Query("SELECT * FROM smart_plans WHERE dateKey = :dateKey LIMIT 1") suspend fun forDate(dateKey: String): SmartPlanEntity?
    @Insert suspend fun insert(plan: SmartPlanEntity)
    @Query("UPDATE smart_plans SET completed = 1 WHERE id = :id") suspend fun complete(id: String)
}
