package com.pharmamentor.app.data

import androidx.room.*

@Dao interface DrugDao {
    @Query("SELECT * FROM drugs ORDER BY name") suspend fun all(): List<DrugEntity>
    @Query("SELECT * FROM drugs WHERE name LIKE '%' || :q || '%' OR className LIKE '%' || :q || '%' ORDER BY name") suspend fun search(q:String): List<DrugEntity>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAll(items:List<DrugEntity>)
}
@Dao interface CaseDao {
    @Query("SELECT * FROM clinical_cases ORDER BY title") suspend fun all(): List<ClinicalCaseEntity>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAll(items:List<ClinicalCaseEntity>)
}
@Dao interface McqDao {
    @Query("SELECT * FROM mcqs ORDER BY id") suspend fun all(): List<McqEntity>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAll(items:List<McqEntity>)
}
