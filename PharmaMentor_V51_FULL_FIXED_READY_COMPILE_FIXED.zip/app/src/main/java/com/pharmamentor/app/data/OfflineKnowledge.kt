package com.pharmamentor.app.data

import androidx.room.*

@Entity(tableName = "offline_knowledge")
data class OfflineKnowledgeEntity(
    @PrimaryKey val id: String,
    val category: String,
    val title: String,
    val content: String,
    val keywords: String,
    val reference: String,
    val reviewed: String
)

@Dao
interface OfflineKnowledgeDao {
    @Query("SELECT * FROM offline_knowledge ORDER BY category, title") suspend fun all(): List<OfflineKnowledgeEntity>
    @Query("SELECT * FROM offline_knowledge WHERE category=:category ORDER BY title") suspend fun byCategory(category:String): List<OfflineKnowledgeEntity>
    @Query("SELECT * FROM offline_knowledge WHERE title LIKE '%' || :q || '%' OR content LIKE '%' || :q || '%' OR keywords LIKE '%' || :q || '%' ORDER BY category, title") suspend fun search(q:String): List<OfflineKnowledgeEntity>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAll(items:List<OfflineKnowledgeEntity>)
}

object OfflineKnowledgeSeed {
    val items = listOf(
        OfflineKnowledgeEntity("pharm-001","Pharmacology","Autonomic Nervous System","Sympathetic activity is dominated by adrenergic receptors; parasympathetic activity by muscarinic receptors. Receptor selectivity helps predict effects, adverse effects, and contraindications.","ANS sympathetic parasympathetic alpha beta muscarinic","Standard pharmacology reference; verify against current labeling/guidelines.","2026-09"),
        OfflineKnowledgeEntity("cardio-001","Cardiology","Hypertension Basics","Confirm blood pressure with proper technique and repeated measurements. Drug selection depends on BP level, cardiovascular risk, kidney disease, diabetes, comorbidities, and tolerability.","hypertension BP ACE ARB calcium channel diuretic","2025 AHA/ACC High Blood Pressure Guideline","2026-09"),
        OfflineKnowledgeEntity("cardio-002","Cardiology","ACE Inhibitors","ACE inhibitors reduce angiotensin II formation and aldosterone signaling. Important adverse effects include cough, hyperkalemia, hypotension, and angioedema; monitor renal function and potassium when clinically appropriate.","ACE inhibitor enalapril cough potassium angioedema kidney","Current official labeling and hypertension guideline should be checked.","2026-09"),
        OfflineKnowledgeEntity("antibiotics-001","Antibiotics","Antibiotic Stewardship","Choose antibiotics according to likely pathogens, site of infection, patient factors, local resistance patterns, culture data when available, and guideline recommendations. Avoid unnecessary antibiotic exposure.","antibiotic stewardship resistance culture spectrum","Current antimicrobial guideline/local protocol.","2026-09"),
        OfflineKnowledgeEntity("endocrine-001","Endocrinology","Diabetes Medication Principles","Medication choice in diabetes should consider glycemic goals, cardiovascular and kidney status, hypoglycemia risk, weight effects, adverse effects, cost, and patient preferences.","diabetes glucose insulin metformin SGLT2 GLP1","Current diabetes standards should be checked before clinical use.","2026-09"),
        OfflineKnowledgeEntity("resp-001","Respiratory","Beta-2 Agonists","Beta-2 agonists relax bronchial smooth muscle. They can cause tremor, tachycardia, and a shift of potassium into cells; excessive use may signal poor disease control.","beta2 salbutamol albuterol asthma potassium bronchodilator","Current asthma/COPD guidance and official labeling.","2026-09"),
        OfflineKnowledgeEntity("renal-001","Clinical Pharmacology","Renal Dose Adjustment","Renal impairment can alter clearance of many medicines. Dose adjustment may involve reducing the dose, extending the interval, or choosing an alternative. Use the drug-specific label and validated renal function method.","renal kidney dose adjustment clearance eGFR","Drug-specific official labeling.","2026-09"),
        OfflineKnowledgeEntity("safety-001","Medication Safety","High-Alert Medication Check","Before dispensing or administering a high-alert medicine, verify patient, drug, dose, route, timing, indication, allergies, interactions, monitoring requirements, and relevant laboratory data.","medication safety high alert verification monitoring","Institutional medication-safety policy and official labeling.","2026-09")
    )
}
