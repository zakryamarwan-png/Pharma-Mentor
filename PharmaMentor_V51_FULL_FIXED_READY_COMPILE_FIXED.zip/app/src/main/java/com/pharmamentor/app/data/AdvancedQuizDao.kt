package com.pharmamentor.app.data

import androidx.room.*

@Dao
interface AdvancedQuizDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttempt(x: QuizAttemptEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(x: QuizSessionEntity)

    @Update
    suspend fun updateSession(x: QuizSessionEntity)

    @Query("SELECT * FROM quiz_attempts ORDER BY timestamp DESC LIMIT :limit")
    suspend fun recentAttempts(limit: Int): List<QuizAttemptEntity>

    @Query("SELECT * FROM quiz_sessions ORDER BY startedAt DESC LIMIT :limit")
    suspend fun recentSessions(limit: Int): List<QuizSessionEntity>

    @Query("SELECT COUNT(*) FROM quiz_attempts WHERE correct = 1 AND difficulty = :difficulty")
    suspend fun correctAtDifficulty(difficulty: Int): Int

    @Query("SELECT COUNT(*) FROM quiz_attempts WHERE difficulty = :difficulty")
    suspend fun totalAtDifficulty(difficulty: Int): Int
}
