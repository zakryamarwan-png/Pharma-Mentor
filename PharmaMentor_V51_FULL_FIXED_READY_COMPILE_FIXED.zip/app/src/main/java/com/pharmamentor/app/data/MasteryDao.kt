package com.pharmamentor.app.data

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Insert
import androidx.room.OnConflictStrategy

@Dao
interface MasteryDao {
    @Query("SELECT * FROM topic_mastery ORDER BY masteryPercent ASC, attempts DESC")
    suspend fun all(): List<TopicMasteryEntity>
    @Query("SELECT * FROM topic_mastery WHERE topic = :topic LIMIT 1")
    suspend fun byTopic(topic: String): TopicMasteryEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: TopicMasteryEntity)
}
