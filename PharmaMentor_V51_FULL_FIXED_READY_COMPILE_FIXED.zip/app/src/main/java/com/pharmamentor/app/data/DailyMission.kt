package com.pharmamentor.app.data

import androidx.room.Entity
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Entity(tableName = "daily_missions", primaryKeys = ["id"])
data class DailyMissionEntity(
    val id: String,
    val dateKey: String,
    val title: String,
    val type: String,
    val target: Int,
    val completed: Int = 0,
    val priority: Int = 1,
    val reason: String = ""
)

@Dao
interface DailyMissionDao {
    @Query("SELECT * FROM daily_missions WHERE dateKey = :dateKey ORDER BY priority ASC, id ASC")
    suspend fun forDate(dateKey: String): List<DailyMissionEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<DailyMissionEntity>)
    @Query("UPDATE daily_missions SET completed = CASE WHEN completed < target THEN completed + 1 ELSE completed END WHERE id = :id")
    suspend fun increment(id: String)
}

object DailyMissionEngine {
    fun build(dateKey: String, roadmap: List<RoadmapItem>, dueCount: Int): List<DailyMissionEntity> {
        val result = mutableListOf<DailyMissionEntity>()
        val focus = roadmap.firstOrNull()
        if (dueCount > 0) {
            result += DailyMissionEntity("$dateKey-review", dateKey, "مراجعة البطاقات المستحقة", "review", minOf(dueCount, 10), 0, 1,
                "لديك $dueCount بطاقة مستحقة؛ المراجعة الآن تحافظ على الذاكرة طويلة المدى.")
        } else {
            result += DailyMissionEntity("$dateKey-review", dateKey, "مراجعة 5 بطاقات", "review", 5, 0, 1,
                "لا توجد بطاقات مستحقة الآن؛ نفّذ مراجعة قصيرة للحفاظ على الاستمرارية.")
        }
        if (focus != null) {
            result += DailyMissionEntity("$dateKey-weakness", dateKey, "تقوية: ${focus.topic}", "weakness", 3, 0, 2,
                focus.reason)
        }
        result += DailyMissionEntity("$dateKey-quiz", dateKey, "حل 5 أسئلة MCQ", "quiz", 5, 0, 3,
            "اختبار قصير يثبت الاستدعاء النشط ويكشف ما يحتاج مراجعة.")
        return result
    }
}
