package com.pharmamentor.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "clinical_tutor_steps", primaryKeys = ["caseId", "stepIndex"])
data class ClinicalTutorStepEntity(
    val caseId: String,
    val stepIndex: Int,
    val prompt: String,
    val options: String,
    val correctOption: String,
    val explanation: String,
    val teachingPoint: String,
    val reference: String
)

@Entity(tableName = "clinical_tutor_attempts")
data class ClinicalTutorAttemptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val caseId: String,
    val stepIndex: Int,
    val selectedOption: String,
    val correct: Boolean,
    val timestamp: Long
)
