package com.pharmamentor.app.data

import androidx.room.*

@Dao
interface ReviewCardDao {
    @Query("SELECT * FROM review_cards WHERE dueAt <= :now ORDER BY dueAt ASC")
    suspend fun due(now: Long): List<ReviewCardEntity>

    @Query("SELECT * FROM review_cards ORDER BY dueAt ASC")
    suspend fun all(): List<ReviewCardEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(card: ReviewCardEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(cards: List<ReviewCardEntity>)
}

@Dao
interface DailyTopicDao {
    @Query("SELECT * FROM daily_topics ORDER BY dateKey DESC LIMIT 1")
    suspend fun latest(): DailyTopicEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(topic: DailyTopicEntity)
}
