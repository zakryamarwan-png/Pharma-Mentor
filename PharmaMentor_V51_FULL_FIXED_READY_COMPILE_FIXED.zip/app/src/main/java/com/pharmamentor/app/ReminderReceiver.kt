package com.pharmamentor.app
import android.app.*;import android.content.*;import androidx.core.app.NotificationCompat
class ReminderReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){
 val ch="pharma_reminders";val nm=c.getSystemService(NotificationManager::class.java)
 if(android.os.Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel(ch,"Pharma Mentor",NotificationManager.IMPORTANCE_DEFAULT))
 nm.notify((System.currentTimeMillis()%100000).toInt(),NotificationCompat.Builder(c,ch)
 .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(i.getStringExtra("title")?:"Pharma Mentor")
 .setContentText(i.getStringExtra("text")?:"حان وقت التعلم").setAutoCancel(true).build())}}
