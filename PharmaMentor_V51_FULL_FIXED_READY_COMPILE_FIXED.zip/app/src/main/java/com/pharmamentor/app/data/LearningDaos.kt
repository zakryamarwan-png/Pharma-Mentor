package com.pharmamentor.app.data
import androidx.room.*
@Dao interface LearningPathDao { @Query("SELECT * FROM learning_paths ORDER BY orderIndex") suspend fun all():List<LearningPathEntity>; @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAll(x:List<LearningPathEntity>) }
@Dao interface PlacementDao { @Query("SELECT * FROM placement_results ORDER BY createdAt DESC") suspend fun all():List<PlacementResultEntity>; @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun insert(x:PlacementResultEntity) }
