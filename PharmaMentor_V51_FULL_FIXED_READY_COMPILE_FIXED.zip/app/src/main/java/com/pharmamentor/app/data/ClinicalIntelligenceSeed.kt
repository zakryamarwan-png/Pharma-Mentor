package com.pharmamentor.app.data

object ClinicalIntelligenceSeed {
    val interactions = listOf(
        DrugInteractionEntity("int1", "Warfarin", "Trimethoprim/sulfamethoxazole", "High", "Can increase anticoagulant effect and bleeding risk through pharmacokinetic and pharmacodynamic mechanisms.", "Avoid when suitable alternatives exist or intensify INR/bleeding monitoring according to clinical context.", "Warfarin labeling; antimicrobial labeling"),
        DrugInteractionEntity("int2", "ACE inhibitor", "Potassium-sparing diuretic", "High", "Additive reduction in renal potassium excretion can increase hyperkalemia risk.", "Review indication, renal function and potassium; monitor after initiation or dose changes.", "ACE-inhibitor labeling; diuretic labeling"),
        DrugInteractionEntity("int3", "Nitrate", "PDE-5 inhibitor", "High", "Additive vasodilation can cause profound hypotension.", "Concomitant use is contraindicated for organic nitrates with PDE-5 inhibitors.", "FDA-approved prescribing information"),
        DrugInteractionEntity("int4", "Beta-blocker", "Albuterol", "Moderate", "Nonselective beta blockade can antagonize beta-2 bronchodilation and may precipitate bronchospasm.", "Assess necessity and selectivity; monitor respiratory response.", "Beta-blocker and albuterol labeling"),
        DrugInteractionEntity("int5", "Digoxin", "Amiodarone", "Moderate", "Amiodarone can increase digoxin exposure and toxicity risk.", "Review digoxin dose and serum concentration and monitor for toxicity when combined.", "Digoxin and amiodarone labeling")
    )
    val links = listOf(
        ClinicalLinkEntity("link1", "case1", "labetalol", "Beta blockade lowers blood pressure; clinical selection depends on patient factors and guideline context."),
        ClinicalLinkEntity("link2", "case2", "salbutamol", "Beta-2 stimulation promotes intracellular potassium shift."),
        ClinicalLinkEntity("link3", "case3", "enalapril", "ACE inhibition requires attention to potassium and renal function."),
        ClinicalLinkEntity("link4", "case4", "furosemide", "Loop diuresis can cause potassium and magnesium losses."),
        ClinicalLinkEntity("link5", "case5", "metoprolol", "Beta-1 selectivity is dose-dependent and does not eliminate bronchospasm risk.")
    )
}
