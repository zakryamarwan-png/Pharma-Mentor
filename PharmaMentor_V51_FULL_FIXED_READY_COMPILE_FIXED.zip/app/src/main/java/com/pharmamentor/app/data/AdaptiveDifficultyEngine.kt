package com.pharmamentor.app.data

/** Offline difficulty controller for adaptive quiz sessions (V36 streak-aware). */
object AdaptiveDifficultyEngine {
    data class Decision(
        val nextLevel: Int,
        val label: String,
        val reason: String
    )

    fun initialLevel(intelligence: ProgressIntelligence): Int {
        val accuracy = intelligence.accuracyPercent
        return when {
            accuracy >= 85 -> 3
            accuracy >= 65 -> 2
            else -> 1
        }
    }

    fun afterAnswer(currentLevel: Int, correct: Boolean): Decision =
        afterAnswer(currentLevel, correct, 0, 0)

    /** V36: uses short-term streaks so one lucky/careless answer does not swing difficulty too aggressively. */
    fun afterAnswer(
        currentLevel: Int,
        correct: Boolean,
        consecutiveCorrect: Int,
        consecutiveWrong: Int
    ): Decision {
        val next = when {
            !correct && consecutiveWrong >= 2 -> (currentLevel - 1).coerceAtLeast(1)
            correct && consecutiveCorrect >= 2 -> (currentLevel + 1).coerceAtMost(3)
            else -> currentLevel.coerceIn(1, 3)
        }
        val reason = when {
            !correct && consecutiveWrong >= 2 -> "연속 2회 오답: 난이도를 낮춰 핵심 개념을 다시 تثبيت합니다."
            correct && consecutiveCorrect >= 2 -> "연속 2회 정답: 이해도가 안정적이므로 난이도를 높입니다."
            correct -> "정답 확인: 현재 난이도를 유지해 이해도를 더 확인합니다."
            else -> "오답 확인: 현재 난이도를 유지하고 다음 문제에서 다시 확인합니다."
        }
        return Decision(next, AdvancedQuizEngine.difficultyLabel(next), reason)
    }
}
