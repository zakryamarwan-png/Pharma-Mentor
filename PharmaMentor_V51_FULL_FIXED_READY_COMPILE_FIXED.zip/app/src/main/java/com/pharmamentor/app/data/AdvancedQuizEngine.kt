package com.pharmamentor.app.data

import kotlin.math.roundToInt

object AdvancedQuizEngine {
    data class Config(val count: Int = 10, val difficulty: Int = 0, val timed: Boolean = false)

    fun chooseQuestions(all: List<McqEntity>, config: Config, seed: Long = System.currentTimeMillis()): List<McqEntity> {
        val pool = all.filter { config.difficulty == 0 || difficultyOf(it) == config.difficulty }
        val source = if (pool.size >= config.count) pool else all
        return source.shuffled(kotlin.random.Random(seed)).take(config.count.coerceAtLeast(1))
    }

    fun difficultyOf(q: McqEntity): Int {
        val text = (q.question + " " + q.explanation).lowercase()
        return when {
            listOf("contraindication", "interaction", "mechanism", "guideline", "renal", "hepatic", "toxicity").any(text::contains) -> 3
            listOf("dose", "adverse", "side effect", "monitor", "receptor", "treatment").any(text::contains) -> 2
            else -> 1
        }
    }

    fun difficultyLabel(level: Int) = when(level) { 1 -> "Easy"; 2 -> "Medium"; 3 -> "Hard"; else -> "Mixed" }
    fun scorePercent(correct: Int, total: Int) = if (total == 0) 0 else (correct * 100.0 / total).roundToInt()
    fun recommendation(percent: Int) = when {
        percent >= 90 -> "ارفع الصعوبة أو انتقل إلى الحالات السريرية."
        percent >= 75 -> "حافظ على المستوى وأضف مراجعة قصيرة للأخطاء."
        percent >= 50 -> "أعد الموضوعات التي أخطأت فيها ثم جرّب الاختبار مرة أخرى."
        else -> "ابدأ بمستوى أسهل وركّز على أساسيات الموضوع قبل التقدم."
    }
}
