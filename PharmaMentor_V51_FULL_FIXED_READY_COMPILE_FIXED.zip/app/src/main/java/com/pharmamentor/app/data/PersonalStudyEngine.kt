package com.pharmamentor.app.data

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PersonalStudyEngine(private val repo: PharmaRepository) {
    private val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    suspend fun recommendations(): List<StudyRecommendationEntity> {
        val key = fmt.format(Date())
        val existing = repo.studyRecommendations(key)
        if (existing.isNotEmpty()) return existing
        val weak = repo.weaknesses().filter { it.total > 0 }
        val due = repo.dueCards()
        val level = repo.latestPlacement()?.level ?: "Starter"
        val out = mutableListOf<StudyRecommendationEntity>()
        var rank = 100
        weak.take(3).forEach { w ->
            val rate = w.wrong * 100 / w.total
            if (rate >= 30) out += rec(key, rank--, "weakness", "تقوية: ${w.topic}", "نسبة الخطأ ${rate}% (${w.wrong}/${w.total})", w.topic)
        }
        if (due.isNotEmpty()) out += rec(key, rank--, "review", "المراجعة المستحقة", "لديك ${due.size} بطاقة تحتاج إلى مراجعة الآن.", "review")
        val questionCount = when(level) { "Expert" -> 10; "Advanced" -> 8; "Intermediate" -> 6; else -> 5 }
        out += rec(key, rank--, "quiz", "اختبار نشط", "حل $questionCount أسئلة لاسترجاع المعلومات وقياس الدقة.", "mcq")
        out += rec(key, rank--, "topic", "موضوع جديد", "أضف معلومة جديدة اليوم بدل الاعتماد على المراجعة فقط.", "daily-topic")
        if (out.size < 5) out += rec(key, rank--, "case", "حالة سريرية", "طبّق المعرفة الدوائية على حالة واقعية.", "clinical-case")
        repo.saveStudyRecommendations(out)
        return out
    }

    private fun rec(date:String, priority:Int, type:String, title:String, reason:String, target:String) =
        StudyRecommendationEntity("$date-$type-$priority", date, priority, type, title, reason, target, false, System.currentTimeMillis())
}
