package com.pharmamentor.app.data

/** V37 topic mastery model. Scores are intentionally explainable and fully offline. */
object MasteryEngine {
    fun update(topic: String, previous: TopicMasteryEntity?, correct: Boolean, now: Long = System.currentTimeMillis()): TopicMasteryEntity {
        val attempts = (previous?.attempts ?: 0) + 1
        val correctCount = (previous?.correct ?: 0) + if (correct) 1 else 0
        val accuracy = correctCount * 100 / attempts
        val oldMastery = previous?.masteryPercent ?: 0
        val target = when {
            accuracy >= 90 -> 95
            accuracy >= 75 -> 82
            accuracy >= 60 -> 68
            accuracy >= 40 -> 50
            else -> 30
        }
        val mastery = if (previous == null) target else ((oldMastery * 3 + target) / 4).coerceIn(0,100)
        val streak = if (correct) (previous?.streak ?: 0) + 1 else 0
        val confidence = ((accuracy * 0.7) + (mastery * 0.3)).toInt().coerceIn(0,100)
        return TopicMasteryEntity(topic, mastery, confidence, attempts, correctCount, streak, now)
    }

    fun status(percent: Int): String = when {
        percent >= 85 -> "MASTERED"
        percent >= 70 -> "STRONG"
        percent >= 50 -> "DEVELOPING"
        else -> "NEEDS_REVIEW"
    }

    fun nextMilestone(percent: Int): String = when {
        percent >= 90 -> "🏆 وصلت إلى 90%+ — الهدف التالي: الحفاظ على Mastered."
        percent >= 80 -> "🎯 بقي ${90 - percent}% للوصول إلى 90%."
        percent >= 70 -> "📈 بقي ${80 - percent}% للوصول إلى 80%."
        else -> "🧱 بقي ${70 - percent.coerceAtMost(69)}% للوصول إلى 70%."
    }

    fun nextAction(percent: Int): String = when {
        percent >= 85 -> "Challenge: استخدم أسئلة أصعب وحالة سريرية."
        percent >= 70 -> "Practice: حل MCQs للحفاظ على الإتقان."
        percent >= 50 -> "Review + Practice: راجع المفاهيم ثم طبّق بسؤال."
        else -> "Rebuild: راجع الأساسيات ثم أعد الاختبار."
    }
}
