package com.pharmamentor.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ProgressDao {
    @Insert suspend fun insert(session: StudySessionEntity)
    @Query("SELECT COUNT(*) FROM study_sessions") suspend fun totalSessions(): Int
    @Query("SELECT COUNT(*) FROM study_sessions WHERE type = 'review'") suspend fun reviewSessions(): Int
    @Query("SELECT COUNT(*) FROM study_sessions WHERE type = 'topic'") suspend fun topicSessions(): Int
    @Query("SELECT COUNT(*) FROM study_sessions WHERE type = 'mcq'") suspend fun mcqSessions(): Int
    @Query("SELECT DISTINCT date(completedAt/1000,'unixepoch') FROM study_sessions") suspend fun activeDateKeys(): List<String>
    @Query("SELECT COALESCE(SUM(score),0) FROM study_sessions") suspend fun totalScore(): Int
    @Query("SELECT COUNT(DISTINCT date(completedAt/1000,'unixepoch')) FROM study_sessions") suspend fun activeDays(): Int
}
