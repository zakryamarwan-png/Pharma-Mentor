package com.pharmamentor.app.data

object KnowledgeGraphSeed {
    val nodes = listOf(
        KnowledgeGraphNodeEntity("drug-labetalol","Labetalol","Drug","Alpha/beta blocker used in hypertension and selected acute settings."),
        KnowledgeGraphNodeEntity("drug-amlodipine","Amlodipine","Drug","Dihydropyridine calcium-channel blocker."),
        KnowledgeGraphNodeEntity("drug-metoprolol","Metoprolol","Drug","Beta-1 selective blocker."),
        KnowledgeGraphNodeEntity("drug-enalapril","Enalapril","Drug","ACE inhibitor."),
        KnowledgeGraphNodeEntity("drug-losartan","Losartan","Drug","Angiotensin II receptor blocker."),
        KnowledgeGraphNodeEntity("drug-furosemide","Furosemide","Drug","Loop diuretic."),
        KnowledgeGraphNodeEntity("drug-spironolactone","Spironolactone","Drug","Aldosterone receptor antagonist / potassium-sparing diuretic."),
        KnowledgeGraphNodeEntity("drug-salbutamol","Salbutamol","Drug","Short-acting beta-2 agonist."),
        KnowledgeGraphNodeEntity("drug-atropine","Atropine","Drug","Muscarinic receptor antagonist."),
        KnowledgeGraphNodeEntity("drug-warfarin","Warfarin","Drug","Vitamin K antagonist anticoagulant."),
        KnowledgeGraphNodeEntity("receptor-beta1","β1 receptor","Receptor","Primarily cardiac beta-1 adrenergic receptor."),
        KnowledgeGraphNodeEntity("receptor-beta2","β2 receptor","Receptor","Adrenergic receptor associated with bronchodilation and potassium shift into cells."),
        KnowledgeGraphNodeEntity("receptor-alpha1","α1 receptor","Receptor","Adrenergic receptor associated with vascular smooth-muscle contraction."),
        KnowledgeGraphNodeEntity("target-ace","ACE","Target","Enzyme involved in angiotensin II formation and bradykinin metabolism."),
        KnowledgeGraphNodeEntity("target-at1","AT1 receptor","Target","Angiotensin II receptor target of ARBs."),
        KnowledgeGraphNodeEntity("target-aldosterone","Mineralocorticoid receptor","Target","Aldosterone receptor in renal and cardiovascular tissues."),
        KnowledgeGraphNodeEntity("disease-htn","Hypertension","Disease","Persistently elevated blood pressure requiring risk-based management."),
        KnowledgeGraphNodeEntity("disease-asthma","Asthma","Disease","Chronic airway disease with variable airflow limitation."),
        KnowledgeGraphNodeEntity("disease-edema","Edema","Condition","Excess interstitial fluid accumulation."),
        KnowledgeGraphNodeEntity("adverse-hypokalemia","Hypokalemia","Adverse effect","Low serum potassium; can occur with loop diuretics."),
        KnowledgeGraphNodeEntity("adverse-hyperkalemia","Hyperkalemia","Adverse effect","Elevated serum potassium; risk with potassium-sparing therapies."),
        KnowledgeGraphNodeEntity("interaction-warfarin-tmp","Warfarin + TMP-SMX","Interaction","High-severity interaction requiring careful management."),
        KnowledgeGraphNodeEntity("case-htn","Hypertension case","Clinical case","Case-based application of antihypertensive selection."),
        KnowledgeGraphNodeEntity("case-asthma","Asthma case","Clinical case","Case-based application of bronchodilator therapy.")
    )
    val edges = listOf(
        KnowledgeGraphEdgeEntity("drug-labetalol","receptor-alpha1","blocks", "Drug label / pharmacology reference"),
        KnowledgeGraphEdgeEntity("drug-labetalol","receptor-beta1","blocks", "Drug label / pharmacology reference"),
        KnowledgeGraphEdgeEntity("drug-labetalol","disease-htn","used-for", "Drug labeling"),
        KnowledgeGraphEdgeEntity("drug-amlodipine","disease-htn","used-for", "Drug labeling"),
        KnowledgeGraphEdgeEntity("drug-metoprolol","receptor-beta1","blocks", "Drug labeling"),
        KnowledgeGraphEdgeEntity("drug-metoprolol","disease-htn","used-for", "Drug labeling"),
        KnowledgeGraphEdgeEntity("drug-enalapril","target-ace","inhibits", "Drug labeling"),
        KnowledgeGraphEdgeEntity("drug-enalapril","disease-htn","used-for", "Drug labeling"),
        KnowledgeGraphEdgeEntity("drug-losartan","target-at1","blocks", "Drug labeling"),
        KnowledgeGraphEdgeEntity("drug-losartan","disease-htn","used-for", "Drug labeling"),
        KnowledgeGraphEdgeEntity("drug-furosemide","disease-edema","used-for", "Drug labeling"),
        KnowledgeGraphEdgeEntity("drug-furosemide","adverse-hypokalemia","may-cause", "Drug labeling"),
        KnowledgeGraphEdgeEntity("drug-spironolactone","target-aldosterone","blocks", "Drug labeling"),
        KnowledgeGraphEdgeEntity("drug-spironolactone","adverse-hyperkalemia","may-cause", "Drug labeling"),
        KnowledgeGraphEdgeEntity("drug-salbutamol","receptor-beta2","activates", "Drug labeling"),
        KnowledgeGraphEdgeEntity("drug-salbutamol","disease-asthma","used-for", "Drug labeling"),
        KnowledgeGraphEdgeEntity("drug-atropine","receptor-beta2","does-not-target", "Pharmacology distinction"),
        KnowledgeGraphEdgeEntity("drug-warfarin","interaction-warfarin-tmp","interacts", "Safety reference"),
        KnowledgeGraphEdgeEntity("case-htn","disease-htn","illustrates", "Clinical case bank"),
        KnowledgeGraphEdgeEntity("case-asthma","disease-asthma","illustrates", "Clinical case bank"),
        KnowledgeGraphEdgeEntity("case-htn","drug-labetalol","links-to", "Clinical intelligence"),
        KnowledgeGraphEdgeEntity("case-asthma","drug-salbutamol","links-to", "Clinical intelligence")
    )
}
