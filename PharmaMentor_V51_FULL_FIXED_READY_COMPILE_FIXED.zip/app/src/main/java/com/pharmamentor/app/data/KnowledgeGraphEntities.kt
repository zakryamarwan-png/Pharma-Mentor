package com.pharmamentor.app.data

import androidx.room.Entity

@Entity(tableName = "knowledge_graph_nodes")
data class KnowledgeGraphNodeEntity(
    @androidx.room.PrimaryKey val id: String,
    val label: String,
    val type: String,
    val description: String = ""
)

@Entity(tableName = "knowledge_graph_edges", primaryKeys = ["fromId", "toId", "relation"])
data class KnowledgeGraphEdgeEntity(
    val fromId: String,
    val toId: String,
    val relation: String,
    val reference: String = ""
)
