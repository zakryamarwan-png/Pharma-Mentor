package com.pharmamentor.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="learning_paths")
data class LearningPathEntity(@PrimaryKey val id:String,val title:String,val description:String,val orderIndex:Int)

@Entity(tableName="path_topics", primaryKeys=["pathId","topicId"])
data class PathTopicEntity(val pathId:String,val topicId:String,val orderIndex:Int)

@Entity(tableName="placement_results")
data class PlacementResultEntity(@PrimaryKey val id:String,val pathId:String,val score:Int,val total:Int,val level:String,val createdAt:Long)
