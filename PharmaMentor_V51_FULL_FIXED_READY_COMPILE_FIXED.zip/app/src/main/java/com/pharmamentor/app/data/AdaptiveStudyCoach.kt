package com.pharmamentor.app.data

/** Offline adaptive coach. Chooses the next learning action from local performance signals. */
object AdaptiveStudyCoach {
    data class Recommendation(
        val stage: UnifiedStudySession.Stage,
        val reason: String,
        val focusTopic: String? = null
    )

    fun buildPlan(
        intelligence: ProgressIntelligence,
        hasTopic: Boolean,
        dueCards: Int,
        hasQuiz: Boolean,
        hasCase: Boolean,
        maxStages: Int = 4
    ): List<Recommendation> {
        val out = mutableListOf<Recommendation>()
        val weak = intelligence.weakTopics.firstOrNull()
        if (dueCards > 0) out += Recommendation(UnifiedStudySession.Stage.REVIEW, "هناك $dueCards بطاقة مستحقة للمراجعة المتباعدة.", weak?.topic)
        if (weak != null && hasQuiz) out += Recommendation(UnifiedStudySession.Stage.QUIZ, "نقطة الضعف الأعلى: ${weak.topic} (${weak.errorPercent}% أخطاء).", weak.topic)
        if (hasTopic) out += Recommendation(UnifiedStudySession.Stage.TOPIC, "ابدأ بمحتوى اليوم لبناء المعرفة قبل التطبيق.")
        if (hasCase) out += Recommendation(UnifiedStudySession.Stage.CASE, "طبّق المعرفة في حالة سريرية.", weak?.topic)
        if (hasQuiz && out.none { it.stage == UnifiedStudySession.Stage.QUIZ }) out += Recommendation(UnifiedStudySession.Stage.QUIZ, "اختبر الاستدعاء النشط بعد الدراسة.")
        return out.distinctBy { it.stage }.take(maxStages)
    }
}
