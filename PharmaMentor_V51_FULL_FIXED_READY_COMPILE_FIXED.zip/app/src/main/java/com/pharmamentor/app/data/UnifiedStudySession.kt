package com.pharmamentor.app.data

/** Offline planner for a short guided study session. */
object UnifiedStudySession {
    enum class Stage { TOPIC, REVIEW, QUIZ, CASE }

    data class Plan(
        val stages: List<Stage>,
        val title: String = "Today's Guided Study"
    )

    fun buildPlan(
        hasTopic: Boolean,
        dueCards: Int,
        hasQuiz: Boolean,
        hasCase: Boolean,
        maxStages: Int = 4
    ): Plan {
        val result = mutableListOf<Stage>()
        if (hasTopic) result += Stage.TOPIC
        if (dueCards > 0) result += Stage.REVIEW
        if (hasQuiz) result += Stage.QUIZ
        if (hasCase) result += Stage.CASE
        return Plan(result.take(maxStages))
    }

    fun label(stage: Stage): String = when (stage) {
        Stage.TOPIC -> "📚 موضوع اليوم"
        Stage.REVIEW -> "🧠 مراجعة متباعدة"
        Stage.QUIZ -> "📝 سؤال تطبيقي"
        Stage.CASE -> "🩺 حالة سريرية"
    }
}
