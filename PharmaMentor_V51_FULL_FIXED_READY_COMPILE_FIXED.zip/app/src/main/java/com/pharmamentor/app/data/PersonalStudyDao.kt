package com.pharmamentor.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface PersonalStudyDao {
    @Query("SELECT * FROM study_recommendations WHERE dateKey = :dateKey ORDER BY priority DESC")
    suspend fun forDate(dateKey: String): List<StudyRecommendationEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<StudyRecommendationEntity>)
    @Query("UPDATE study_recommendations SET completed = 1 WHERE id = :id")
    suspend fun complete(id: String)
}
