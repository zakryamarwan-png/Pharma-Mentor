package com.pharmamentor.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "smart_plans")
data class SmartPlanEntity(
    @PrimaryKey val id: String,
    val dateKey: String,
    val title: String,
    val level: String,
    val focus: String,
    val reviewCount: Int,
    val topicCount: Int,
    val questionCount: Int,
    val createdAt: Long,
    val completed: Boolean = false
)
