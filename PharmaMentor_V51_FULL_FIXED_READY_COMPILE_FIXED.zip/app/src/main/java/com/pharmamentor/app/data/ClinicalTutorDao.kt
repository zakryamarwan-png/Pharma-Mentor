package com.pharmamentor.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ClinicalTutorDao {
    @Query("SELECT * FROM clinical_tutor_steps WHERE caseId = :caseId ORDER BY stepIndex")
    suspend fun steps(caseId: String): List<ClinicalTutorStepEntity>

    @Query("SELECT DISTINCT caseId FROM clinical_tutor_steps ORDER BY caseId")
    suspend fun caseIds(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSteps(items: List<ClinicalTutorStepEntity>)

    @Insert
    suspend fun recordAttempt(item: ClinicalTutorAttemptEntity)

    @Query("SELECT * FROM clinical_tutor_attempts WHERE caseId = :caseId ORDER BY timestamp DESC")
    suspend fun attempts(caseId: String): List<ClinicalTutorAttemptEntity>
}
