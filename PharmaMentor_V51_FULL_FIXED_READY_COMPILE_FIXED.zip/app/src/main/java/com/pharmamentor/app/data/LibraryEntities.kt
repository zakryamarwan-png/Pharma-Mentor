package com.pharmamentor.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "drugs")
data class DrugEntity(
    @PrimaryKey val id: String, val name: String, val className: String, val mechanism: String,
    val uses: String, val adverseEffects: String, val contraindications: String, val reference: String
)
@Entity(tableName = "clinical_cases")
data class ClinicalCaseEntity(
    @PrimaryKey val id: String, val title: String, val scenario: String, val answer: String, val reference: String
)
@Entity(tableName = "mcqs")
data class McqEntity(
    @PrimaryKey val id: String, val question: String, val options: String, val correct: String,
    val explanation: String, val reference: String, val topic: String = "General Pharmacology"
)
