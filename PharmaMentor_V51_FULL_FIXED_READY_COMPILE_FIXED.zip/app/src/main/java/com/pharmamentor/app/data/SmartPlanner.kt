package com.pharmamentor.app.data

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SmartPlanner(private val repo: PharmaRepository) {
    suspend fun today(): SmartPlanEntity {
        val dateKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        repo.getSmartPlan(dateKey)?.let { return it }
        val due = repo.dueCards()
        val placement = repo.latestPlacement()
        val weak = repo.weaknesses().firstOrNull()
        val level = placement?.level ?: "Starter"
        val baseFocus = when (level) {
            "Expert" -> "Clinical application + weak-area review"
            "Advanced" -> "Mechanism + clinical decision making"
            "Intermediate" -> "Core pharmacology + active recall"
            else -> "Foundations + high-yield recall"
        }
        val focus = if (weak != null && weak.total > 0 && weak.wrong * 100 / weak.total >= 30) "Priority: ${weak.topic} + $baseFocus" else baseFocus
        val reviewCount = minOf(maxOf(due.size, 5), when(level) { "Expert" -> 25; "Advanced" -> 20; "Intermediate" -> 15; else -> 10 })
        val topicCount = when(level) { "Expert", "Advanced" -> 2; else -> 1 }
        val questionCount = when(level) { "Expert" -> 10; "Advanced" -> 8; "Intermediate" -> 6; else -> 5 }
        val plan = SmartPlanEntity(
            id = "plan-$dateKey",
            dateKey = dateKey,
            title = "Today's Smart Plan",
            level = level,
            focus = focus,
            reviewCount = reviewCount,
            topicCount = topicCount,
            questionCount = questionCount,
            createdAt = System.currentTimeMillis()
        )
        repo.insertSmartPlan(plan)
        return plan
    }
}
