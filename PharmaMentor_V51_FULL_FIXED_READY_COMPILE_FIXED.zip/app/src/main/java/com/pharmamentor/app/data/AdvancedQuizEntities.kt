package com.pharmamentor.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "quiz_attempts")
data class QuizAttemptEntity(
    @PrimaryKey val id: String,
    val quizId: String,
    val questionId: String,
    val selected: String,
    val correct: Boolean,
    val difficulty: Int,
    val topic: String,
    val elapsedSeconds: Int,
    val timestamp: Long
)

@Entity(tableName = "quiz_sessions")
data class QuizSessionEntity(
    @PrimaryKey val id: String,
    val startedAt: Long,
    val finishedAt: Long? = null,
    val total: Int,
    val answered: Int = 0,
    val correct: Int = 0,
    val difficulty: Int = 0,
    val timed: Boolean = false
)
