package com.pharmamentor.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "study_recommendations")
data class StudyRecommendationEntity(
    @PrimaryKey val id: String,
    val dateKey: String,
    val priority: Int,
    val type: String,
    val title: String,
    val reason: String,
    val targetId: String,
    val completed: Boolean = false,
    val createdAt: Long
)
