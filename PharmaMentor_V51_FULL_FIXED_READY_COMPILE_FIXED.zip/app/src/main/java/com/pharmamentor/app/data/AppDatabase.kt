package com.pharmamentor.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [ReviewCardEntity::class, DailyTopicEntity::class, DrugEntity::class, ClinicalCaseEntity::class, McqEntity::class, StudySessionEntity::class, LearningPathEntity::class, PathTopicEntity::class, PlacementResultEntity::class, SmartPlanEntity::class, LearningEventEntity::class, DrugInteractionEntity::class, ClinicalLinkEntity::class, DrugProfileEntity::class, OfflineKnowledgeEntity::class, StudyRecommendationEntity::class, ClinicalTutorStepEntity::class, ClinicalTutorAttemptEntity::class, KnowledgeGraphNodeEntity::class, KnowledgeGraphEdgeEntity::class, QuizAttemptEntity::class, QuizSessionEntity::class, SpacedRepetitionStateEntity::class, TopicMasteryEntity::class, DailyMissionEntity::class, AchievementProgressEntity::class, DailyChallengeEntity::class], version = 17, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun reviewCards(): ReviewCardDao
    abstract fun topics(): DailyTopicDao
    abstract fun drugs(): DrugDao
    abstract fun cases(): CaseDao
    abstract fun mcqs(): McqDao
    abstract fun learningPaths(): LearningPathDao
    abstract fun placement(): PlacementDao
    abstract fun progress(): ProgressDao
    abstract fun smartPlans(): SmartPlanDao
    abstract fun analytics(): AnalyticsDao
    abstract fun achievements(): AchievementDao
    abstract fun clinicalIntelligence(): ClinicalIntelligenceDao
    abstract fun drugProfiles(): DrugProfileDao
    abstract fun offlineKnowledge(): OfflineKnowledgeDao
    abstract fun personalStudy(): PersonalStudyDao
    abstract fun clinicalTutor(): ClinicalTutorDao
    abstract fun knowledgeGraph(): KnowledgeGraphDao
    abstract fun advancedQuiz(): AdvancedQuizDao
    abstract fun spacedRepetition(): SpacedRepetitionDao
    abstract fun mastery(): MasteryDao
    abstract fun dailyMissions(): DailyMissionDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "pharma_mentor.db")
                .fallbackToDestructiveMigration().build().also { INSTANCE = it }
        }
    }
}
