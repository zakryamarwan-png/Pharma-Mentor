package com.pharmamentor.app

import com.pharmamentor.app.data.SpacedRepetitionStateEntity
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/** Offline adaptive scheduler. It combines recall rating with stability/difficulty signals. */
object AdvancedSpacedRepetitionEngine {
    data class Result(val state: SpacedRepetitionStateEntity, val intervalDays: Int)

    fun schedule(
        state: SpacedRepetitionStateEntity,
        rating: Rating,
        now: Long = System.currentTimeMillis()
    ): Result {
        var stability = state.stability
        var difficulty = state.difficulty
        var reps = state.repetitions
        var lapses = state.lapses

        when (rating) {
            Rating.AGAIN -> {
                stability = max(0.5, stability * 0.35)
                difficulty = min(10.0, difficulty + 0.8)
                lapses++
            }
            Rating.HARD -> {
                stability = max(1.0, stability * (0.90 + 0.02 * (10.0 - difficulty)))
                difficulty = min(10.0, difficulty + 0.25)
                reps++
            }
            Rating.GOOD -> {
                val growth = 1.65 + (10.0 - difficulty) * 0.06
                stability = max(1.5, stability * growth)
                difficulty = max(1.0, difficulty - 0.15)
                reps++
            }
            Rating.EASY -> {
                val growth = 2.10 + (10.0 - difficulty) * 0.08
                stability = max(2.0, stability * growth)
                difficulty = max(1.0, difficulty - 0.45)
                reps++
            }
        }

        val interval = when (rating) {
            Rating.AGAIN -> 0
            Rating.HARD -> max(1, min(14, stability.pow(0.85).toInt()))
            Rating.GOOD -> max(1, min(180, stability.pow(0.92).toInt()))
            Rating.EASY -> max(2, min(365, stability.pow(0.95).toInt()))
        }
        val due = if (rating == Rating.AGAIN) now + 10 * 60 * 1000L
                  else now + interval * 24 * 60 * 60 * 1000L

        return Result(
            SpacedRepetitionStateEntity(
                cardId = state.cardId,
                stability = stability,
                difficulty = difficulty,
                repetitions = reps,
                lapses = lapses,
                lastRating = rating.name,
                lastReviewedAt = now,
                dueAt = due
            ), interval
        )
    }

    fun initial(cardId: String, dueAt: Long = System.currentTimeMillis()) =
        SpacedRepetitionStateEntity(cardId = cardId, dueAt = dueAt)
}
