package com.pharmamentor.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface AnalyticsDao {
    @Insert suspend fun insert(event: LearningEventEntity)
    @Query("SELECT topic, COUNT(*) AS total, SUM(CASE WHEN correct = 0 THEN 1 ELSE 0 END) AS wrong FROM learning_events GROUP BY topic ORDER BY wrong DESC, total DESC")
    suspend fun weaknessRows(): List<WeaknessRow>
    @Query("SELECT COUNT(*) FROM learning_events WHERE correct = 0") suspend fun totalWrong(): Int
    @Query("SELECT COUNT(*) FROM learning_events") suspend fun totalAnswered(): Int
    @Query("SELECT COUNT(*) FROM learning_events WHERE correct = 1") suspend fun totalCorrect(): Int
    @Query("SELECT COUNT(*) FROM learning_events WHERE timestamp >= :since") suspend fun answeredSince(since: Long): Int
    @Query("SELECT COUNT(*) FROM learning_events WHERE timestamp >= :since AND correct = 0") suspend fun wrongSince(since: Long): Int
    @Query("SELECT topic, COUNT(*) AS total, SUM(CASE WHEN correct = 0 THEN 1 ELSE 0 END) AS wrong FROM learning_events WHERE timestamp >= :since GROUP BY topic ORDER BY wrong DESC, total DESC") suspend fun recentWeaknessRows(since: Long): List<WeaknessRow>
}

data class WeaknessRow(val topic: String, val total: Int, val wrong: Int)
