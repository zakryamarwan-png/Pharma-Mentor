package com.pharmamentor.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "review_cards")
data class ReviewCardEntity(
    @PrimaryKey val id: String,
    val question: String,
    val answer: String,
    val category: String,
    val reference: String,
    val dueAt: Long,
    val intervalDays: Int = 0,
    val ease: Double = 2.5,
    val reps: Int = 0,
    val lapses: Int = 0
)

@Entity(tableName = "daily_topics")
data class DailyTopicEntity(
    @PrimaryKey val id: String,
    val title: String,
    val body: String,
    val reference: String,
    val dateKey: String,
    val completed: Boolean = false
)
