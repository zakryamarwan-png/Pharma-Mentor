package com.pharmamentor.app.data

import androidx.room.*

@Dao
interface ClinicalIntelligenceDao {
    @Query("SELECT * FROM drug_interactions ORDER BY severity DESC, drugA")
    suspend fun interactions(): List<DrugInteractionEntity>

    @Query("SELECT * FROM drug_interactions WHERE drugA LIKE '%' || :term || '%' OR drugB LIKE '%' || :term || '%' ORDER BY severity DESC")
    suspend fun searchInteractions(term: String): List<DrugInteractionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertInteractions(items: List<DrugInteractionEntity>)

    @Query("SELECT * FROM clinical_links WHERE caseId = :caseId")
    suspend fun linksForCase(caseId: String): List<ClinicalLinkEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertLinks(items: List<ClinicalLinkEntity>)
}
