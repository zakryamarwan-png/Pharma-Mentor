package com.pharmamentor.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "achievement_progress")
data class AchievementProgressEntity(
    @PrimaryKey val key: String,
    val unlockedAt: Long? = null
)

@Entity(tableName = "daily_challenges")
data class DailyChallengeEntity(
    @PrimaryKey val dateKey: String,
    val target: Int = 10,
    val completed: Int = 0,
    val xpAwarded: Boolean = false
)

data class AchievementRow(val key: String, val title: String, val description: String, val unlocked: Boolean)
