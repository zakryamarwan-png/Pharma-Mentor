package com.pharmamentor.app.data

/** Local, read-only health snapshot used to verify that major Pharma Mentor modules are connected. */
data class SystemAudit(
    val reviewCards: Int,
    val dueCards: Int,
    val drugs: Int,
    val drugProfiles: Int,
    val cases: Int,
    val mcqs: Int,
    val interactions: Int,
    val tutorCases: Int,
    val graphNodes: Int,
    val graphEdges: Int,
    val offlineArticles: Int,
    val srsStates: Int,
    val learningEvents: Int,
    val recommendations: Int
) {
    val healthyModules: Int get() = listOf(
        reviewCards > 0, drugs > 0, drugProfiles > 0, cases > 0, mcqs > 0,
        interactions > 0, tutorCases > 0, graphNodes > 0, graphEdges > 0,
        offlineArticles > 0, srsStates >= 0, learningEvents >= 0, recommendations >= 0
    ).count { it }
}
