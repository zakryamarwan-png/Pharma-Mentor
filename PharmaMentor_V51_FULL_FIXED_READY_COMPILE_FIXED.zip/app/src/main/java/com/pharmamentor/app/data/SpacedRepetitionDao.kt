package com.pharmamentor.app.data

import androidx.room.*

@Dao
interface SpacedRepetitionDao {
    @Query("SELECT * FROM srs_states WHERE cardId = :cardId LIMIT 1")
    suspend fun byCardId(cardId: String): SpacedRepetitionStateEntity?

    @Query("SELECT * FROM srs_states ORDER BY dueAt ASC")
    suspend fun all(): List<SpacedRepetitionStateEntity>

    @Query("SELECT * FROM srs_states WHERE dueAt <= :now ORDER BY dueAt ASC")
    suspend fun due(now: Long): List<SpacedRepetitionStateEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(state: SpacedRepetitionStateEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(states: List<SpacedRepetitionStateEntity>)
}
