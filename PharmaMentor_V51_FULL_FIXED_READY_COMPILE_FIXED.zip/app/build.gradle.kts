plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.kapt")
}

android {
    namespace = "com.pharmamentor.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.pharmamentor.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 51
        versionName = "51.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    signingConfigs {
        create("release") {
            val ks = project.findProperty("PHARMA_KEYSTORE") as String?
                ?: System.getenv("PHARMA_KEYSTORE")
            val alias = project.findProperty("PHARMA_KEY_ALIAS") as String?
                ?: System.getenv("PHARMA_KEY_ALIAS")
            val storePass = project.findProperty("PHARMA_STORE_PASSWORD") as String?
                ?: System.getenv("PHARMA_STORE_PASSWORD")
            val keyPass = project.findProperty("PHARMA_KEY_PASSWORD") as String?
                ?: System.getenv("PHARMA_KEY_PASSWORD")

            if (!ks.isNullOrBlank() && !alias.isNullOrBlank() &&
                !storePass.isNullOrBlank() && !keyPass.isNullOrBlank()) {
                storeFile = file(ks)
                this.storePassword = storePass
                keyAlias = alias
                this.keyPassword = keyPass
            }
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("androidx.room:room-runtime:2.7.0")
    implementation("androidx.room:room-ktx:2.7.0")
    kapt("androidx.room:room-compiler:2.7.0")
}
